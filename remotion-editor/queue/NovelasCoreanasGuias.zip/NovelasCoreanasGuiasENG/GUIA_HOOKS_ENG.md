# GUÍA DE HOOKS Y TITULACIÓN — FORMATO INGLÉS (`novelas-coreanas-eng`)
### Compañera del MANUAL ENG. La psicología es la de GUIA_HOOKS_V2 (STOP→ORIENT→CONTRACT→PROVE→REWARD→SPREAD); aquí está la EJECUCIÓN en inglés.

Todo lo estructural de la guía española sigue vigente: brecha de información + emoción de alta activación (indignación/asombro comparten; la tristeza no) · el hook decide el STOP, el cuerpo el HOLD, el pago el SATISFY · re-hooks solo con delta informativo · cliffhanger que paga algo y abre algo · nunca cerrar una Parte en tristeza pura. Este documento da: fórmulas de gancho EN INGLÉS, la fórmula de titulación del mercado anglo con patrones REALES, y el banco de frases.

---

## 1. LA PRIMERA LÍNEA (escena 1) — el molde en inglés

Patrón: **[sacrificio/agravio brutal, concreto, ejecutado] → herida abierta.** Un solo nombre propio máximo. Sin explicar. Sin spoilear el giro.

Moldes probados (crear uno original por historia; no reciclar literal):

- `"I paid for my husband's degree and my best friend's pregnancy."`
- `"I donated my kidney to save my mother-in-law. A month later she threw me out for being 'barren'."`
- `"I signed the divorce the same day I found out whose daughter I really was."`
- `"My husband and my sister killed me for the inheritance. I woke up on my wedding day, remembering everything."`
- `"They sat me with the waiters at my son's wedding."`
- `"I raised that girl for twenty years. Her mother came back two months before the wedding."`
- `"My son chose his rich father. I signed the papers that same day."`

**Test de 3 segundos:** léela en voz alta. Si no puedes responder "¿quién le hizo qué a quién?", reescribe.

## 2. LA PROMESA (escenas 2-3) — por motor, en inglés

- Injusticia/heredera: persona de poder física. `"A week later, the man my father-in-law bowed to asked for my name."`
- Regresión: `"I woke up eight hours earlier. On my wedding day."`
- Identidad/dueña oculta: `"What they didn't know is that I owned that hotel."`
- Madre/abandono: `"And the woman who left her at five came back to collect."`
- Romance-contrato: `"Three nights later, the husband who hated me slept outside my door."`
- Misterio de lugar: `"That night, my mother's portrait appeared in the forbidden hall."`

## 3. REENTRADAS (Partes 2+) — sin recap, mostrando consecuencia

- Consecuencia inmediata: `"I got my name back. That same night, the police came for me."`
- Falsa victoria: `"The mansion opened its doors again — but my room already had a new owner."`
- Nueva amenaza: `"The man who called me his granddaughter forbade me from saying my real name."`
- Contradicción: `"The husband who bought me by contract was the only one who cried for me."`
- Deadline: `"The wedding was six days away when the first wife appeared."`
- Pago envenenado: `"We won the trial. Then my mother confessed she'd lied."`
- Entrada de villana: `"Na-ri didn't scream when she lost the inheritance. She smiled."`

## 4. CLIFFHANGERS (última línea de cada Parte) — en inglés, tipo ROTADO

- Revelación: `"That blood type doesn't exist. Only my daughter had it."`
- Reversal: `"I already took the test, Dad. I'm a match. What do you have — a card?"`
- Intrusión: `"And she didn't say 'Chairman'. She said his first name."`
- Deadline: `"Nine days. And they sign the merger."`

Regla dura: el cliffhanger corta EN el pico, no resuelve, y la Parte ya pagó algo antes. Nunca dos del mismo tipo seguidos.

---

## 5. TITULACIÓN PARA EL MERCADO ANGLO — la fórmula triple + los patrones reales

### 5.1 La fórmula triple (idéntica al español, ejecutada en inglés)

```
[GRIEVANCE in first person + public witness] … [HINGE] [UNRESOLVED PAYBACK]
```

- `They sat me with the waiters at my son's wedding… What they didn't know is that I owned the hotel.`
- `My son chose his rich father… So I signed the papers that same day.`
- `My sister drowned me in the bathtub… I woke up on my wedding day, remembering everything.`
- `I raised her for twenty years… Her "real" mom came back two months before the wedding.`

**Verbos de agravio** (pasado simple): `humiliated · threw me out · left me · chose · locked me away · erased · laughed at me · sold · abandoned`.
**Testigo público:** `in front of everyone · at my son's wedding · in front of three hundred guests · at the family dinner`.
**Bisagras que funcionan:** `…What they didn't know` · `…So I did something they'll never forget` · `…Then the bank changed everything` · `…Two years later they learned the truth` · `…And I chose too.`
**Sello de veracidad opcional:** prefijo `TRUE STORY:` (equivalente al "HISTORIA REAL:" del nicho hispano).

### 5.2 Patrones REALES del mercado (de la investigación, títulos verificados en plataformas)

El microdrama anglo titula LITERAL y con la promesa desnuda — el CEO de ReelShort declaró que evitan títulos "literarios" porque nadie los entiende. Referencias reales del género:

- Dueña/madre oculta: `The Extraordinary Mother of a Billionaire` · `Think Again! I'm the Hidden Boss Mom` · `Divorce Me? Bow to My Billionaire Daughter!`
- Heredera: `The Long-lost Heiress's Return` · `True Heiress vs. Fake Queen Bee` · `Never Divorce a Secret Billionaire Heiress`
- **Regla del niño como palanca (validada en 4 plataformas): titula EN LA VOZ DEL NIÑO dirigiéndose al adulto** → `Mommy, It Hurts… Where's Daddy?` · `Daddy Don't Go, Please Save Mommy` · `Mama Sing Me a Lullaby`.

Traducción operativa: para portadas ENG, marca de 2 palabras arriba (igual que HEREDERA OCULTA → p.ej. `HIDDEN HEIRESS`, `TABLE TWELVE`, `THREAD & BLOOD`) + `PART N` abajo; el gancho largo solo en la Part 1.

### 5.3 Captions de publicación (copy-paste, formato del canal)

```
<Title with hook> | Part 1

<2-3 frases de descripción con las palabras clave, en inglés, terminando con la promesa abierta. "Part 1 of 5.">

#koreandrama #<tema> #<marca-serie> #part1 #reels
```
5 hashtags en minúsculas: 3 fijos (`#koreandrama`, `#<marca>`, `#reels`) + 1 temático + `#partN`.

---

## 6. TTS EN INGLÉS (Fish) — lo que cambia al actuar la voz

- Misma matriz mecanismo→actuación de la guía española (curiosidad = cercanía; conflicto = tensión contenida → determinación; confesión = íntimo → quiebre mínimo). El melodrama en inglés se sobreactúa MENOS: bajar una marcha respecto al instinto.
- **Tags: máximo 2-3 por Parte** (regla del canal), compuestos, solo gancho/giro/cierre.
- Números, horas y cifras EN PALABRAS. Sin abreviaturas. Contracciones sí.
- Nombres coreanos: probar la romanización en la voz elegida ANTES de producir la serie; fijar una forma y no cambiarla.
- QA por Parte: duración real de la línea del gancho, pronunciación de los 4 nombres, énfasis del cliffhanger, consistencia de la voz entre Partes.

## 7. CHECKLIST EXPRÉS DE HOOK ENG

- [ ] Primera línea: agravio ejecutado, ≤1 nombre, se entiende sin contexto, no spoilea el giro.
- [ ] Promesa esc. 2-3 según motor, mítica, en inglés.
- [ ] Título público con la fórmula triple (agravio + bisagra + pago abierto) o marca de 2 palabras + PART N.
- [ ] Cliffhanger de tipo rotado que paga algo.
- [ ] ≤3 tags Fish por Parte. Números en palabras. Una sola romanización por nombre.
- [ ] Nada de "Previously…" en Partes 2+.
