# NovelasCoreanasGuiasENG — preset `novelas-coreanas-eng`

Carpeta espejo de `NovelasCoreanasGuias`, para producir las MISMAS series K-drama pero con **toda la salida en inglés**. Las historias se cuentan igual; cambia el idioma hablado/visible y se amplía el lenguaje de cámara.

## Archivos

| Archivo | Qué es |
|---|---|
| `MANUAL_novelas-coreanas-eng_v1.md` | **La fuente de verdad técnica.** Contrato JSON v2 con `preset: "novelas-coreanas-eng"`, `language: "en"`, salida hablada en inglés, y el §6-bis de **cámara ampliada** (extreme wides, oclusión, reflejos, siluetas, crane/orbit/rack focus, distribución nueva). |
| `GUIA_HOOKS_ENG.md` | Ganchos, reentradas, cliffhangers y titulación **en inglés**, con los patrones reales del mercado anglo (ReelShort/DramaBox) y el formato de captions de publicación. |
| `InvestigacionNovelas.md` | Copia sin cambios. Los ~40 arquetipos aplican igual; solo se ejecutan en inglés. |
| `InvestigacionNovelas_MADRES.md` | Copia sin cambios. Catálogo madre/hijo (M1-M12) con cifras verificadas; los ganchos EN están en la guía de hooks. |

## Jerarquía de mando (igual que en español)

1. **MANUAL ENG** → manda el formato y el JSON.
2. **GUIA_HOOKS_ENG** → manda el gancho, el ritmo y los cierres.
3. **Investigaciones** → materia prima de arquetipos (solo se ADAPTA, nunca se copia texto con copyright).

## Diferencias clave vs el preset español (chuleta)

- `preset`: `novelas-coreanas-eng` · `language`: `"en"` · archivos `<slug>_part01.json`.
- Voiceover, captions, hook, title, cards → inglés. Diálogo con comillas dobles, no raya.
- Normalización TTS: números/horas en palabras, sin abreviaturas, UNA romanización por nombre coreano en toda la serie.
- Cards: `TO BE CONTINUED` / `PART N: …` / `PART N?` / `END OF SEASON ONE`.
- **Cámara ampliada (§6-bis):** por cada 10 escenas → ≥1 toma realmente LEJANA (extreme wide / across-the-street / balcony / overhead), ≥1 encuadre con oclusión-reflejo-silueta, ≤2 movimientos de riesgo (slow crane / slow orbit a few degrees / rack focus). El resto de reglas de Grok no cambia.
- **Escenarios x2 (anti-monotonía):** 8-10 escenarios por serie (3-4 principales con ≥3 views + 4-6 de transición); ≥4-5 escenarios por Parte, ninguno >50% de las escenas, máx 3-4 seguidas en el mismo set.
- **Views derivadas: "New camera position: …" PRIMERO** y el "Keep the exact same…" al final — nunca empezar con "Same <escenario>" (Grok repite la referencia).
- **Picos emocionales (§6-ter):** 2-4 por Parte con actuación física real (colapso al piso, golpe en la mesa, súplica) y ancla `raw, intense emotional performance`; el resto del tiempo, contención.
- **Describir, no solo nombrar:** cada personaje lleva descriptor de 4-8 palabras (`Soo-yeon (a Korean woman in her late twenties, long dark hair down, black gala dress)`) la primera vez, y después se le menciona POR DESCRIPCIÓN, no por nombre. El nombre solo no lleva información visual. Aplica también al `animation_prompt` y a la fórmula D de bocas.
- **Cuerpo entero real:** `full body shot` SIEMPRE con "head to feet in frame" + "both feet on the floor/ground" (sin eso Grok recorta a medio cuerpo). Confrontaciones de pie en `cowboy shot, from the knees up`; `medium shot, waist up` solo sentados tras mueble.
- **Anti-repetición de cara (§6-bis C-bis):** descentrar al personaje, romper los tramos emocionales con insert de objeto / silueta lejana / reflejo / de espaldas, ≥3 ángulos no frontales por cada 10 escenas, ≤3 primeros planos frontales de la misma cara, y **la misma expresión nunca se muestra dos veces de frente en la misma Parte**.
- Tags Fish: máximo 2-3 por Parte (regla del canal).

> Estas siete reglas también están en el manual ESPAÑOL (`NovelasCoreanasGuias/MANUAL_novela-coreana_completo_v3 (1).md`): ambos presets las comparten y se editan en paralelo.

## ⚠️ PENDIENTE ANTES DE LA PRIMERA SERIE ENG

**Elegir la voz.** Todos los JSON llevan el placeholder `"voice_id": "REEMPLAZAR_voice_id_narradora_ingles"`. Hay que:
1. Elegir en Fish Audio una narradora femenina EN INGLÉS (registro contenido, tipo audiolibro dramático).
2. Probar el gancho de la serie con y sin tags, y los nombres coreanos ("Ji-woo" vs "Jiwoo") en esa voz.
3. Reemplazar el placeholder por el ID real y anotarlo aquí:

```
VOICE_ID_INGLES = ____________________  (voz elegida: ____________, fecha: ________)
```

El voice_id español (`bfed5c0810a347dbb62e8ccce7f59c48`) NO sirve para este preset.

## Qué NO cambia

Motor de deuda emocional, MOTOR+MUNDO, mapa de temporada, estado de historia, filtro de viralidad, prueba del ciego (en inglés), contrato de assets (poses/views/ingredients), cupo de 3 referencias, regla de postura, colocación con oclusión, luz por secuencia, N/D bocas, densidad D por motor, `voice_speed 1.25`, `music_volume 0`, una sola voz femenina, 30-50 escenas, cliffhangers rotados, máximo 3 loops.
