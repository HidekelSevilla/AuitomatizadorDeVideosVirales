# Manual completo: preset `novelas-coreanas-eng` v1 — GUÍA ENG
### Adaptación del MANUAL novela-coreana v2/GUIA v5 al formato COMPLETAMENTE EN INGLÉS
### + sección de cámara AMPLIADA (más ángulos, tomas lejanas, movimientos tipo cine)

Este manual define cómo generar JSONs del preset `novelas-coreanas-eng`: los MISMOS videos verticales 9:16 K-drama melodramáticos del preset español (personajes coreanos fotorrealistas, Grok imagen + animación, UNA sola voz femenina por Fish Audio, Partes con cliffhanger), pero con **toda la salida hablada y visible en INGLÉS** (en-US): voiceover, captions, hook, títulos, cards.

**Qué NO cambia respecto al manual español:** la arquitectura narrativa completa (motor de deuda emocional, MOTOR + MUNDO, mapa de temporada, estado de historia, filtro de viralidad, prueba del ciego), el contrato JSON v2 (`characters.<id>.poses` / `escenarios.<id>.views`), la regla de postura, el cupo de 3 referencias, la regla de oro de Grok, todo §3-§4, la continuidad de §9. Las investigaciones de arquetipos (`InvestigacionNovelas.md` e `InvestigacionNovelas_MADRES.md`, copiadas en esta carpeta) aplican IGUAL: la materia prima es la misma, solo cambia el idioma de salida.

**Qué SÍ cambia (resumen de diffs):**

1. `project.preset = "novelas-coreanas-eng"` (exacto, siempre).
2. `project.language = "en"`.
3. `voiceover.text`, `captions.text`, `project.hook`, `project.title`, `capcut_export.title_cards` y `cliffhanger_card` → **en inglés**.
4. La regla de "ortografía para Fish" (tildes/eñes) se sustituye por la de **normalización inglesa** (§5-bis).
5. `tts_export.voice_id` → **voz femenina EN INGLÉS de Fish Audio**. ⚠️ PENDIENTE DEL USUARIO: elegir la voz en Fish y reemplazar el placeholder `REEMPLAZAR_voice_id_narradora_ingles` en todos los JSON. NO usar el voice_id español (`bfed5c...`): esa voz narra en español.
6. §6 de cámara **AMPLIADO**: nuevos tamaños de plano, nuevas posiciones lejanas y con oclusión, y nuevos movimientos de cámara tipo cine para el `animation_prompt` (ver §6-bis, LO NUEVO de esta versión).
7. Nombres de archivo: `<slug>_part01.json`, `<slug>_part02.json`… (en vez de `_parte01`).

> **LA VIRALIDAD NO SALE DE TENER UN GIRO. SALE DE ABRIR UNA DEUDA EMOCIONAL QUE EL ESPECTADOR NECESITA VER PAGADA.** (Idéntico al manual español. Antes del secreto, debe DOLER. Cada parte PAGA algo y abre algo más peligroso.)

---

## 0. Qué produce este preset

- Formato: vertical 9:16, `fps: 30` (número). Imagen y animación: **Grok**. Voz: **Fish Audio, una sola narradora femenina EN INGLÉS** para narración y todos los diálogos (incluidos los masculinos). Sin multivoz.
- Duración de escena: 3-4 s (máx 5). Clips Grok de 6 s → el editor RECORTA, no acelera.
- Duración de la parte: **30-50 escenas** (~1:30-2:30).
- Estilo: mismo K-drama melodramático fotorrealista. Por defecto realista; místico/histórico OPT-IN igual que en español (`allow_supernatural` / `allow_historical`).
- Los personajes SIGUEN siendo coreanos con nombres coreanos (es K-drama en inglés, como los originales de ReelShort/DramaBox: `The Extraordinary Mother of a Billionaire`, `Think Again! I'm the Hidden Boss Mom`). La narradora habla inglés; los nombres se pronuncian romanizados.
- La retención se decide en los primeros 3 segundos: la escena 1 es la más importante de toda la parte.

---

## 1. Flujo de trabajo por parte

Idéntico al manual español:

1. Serie nueva → biblia (título EN, `serie` snake_case, MOTOR + MUNDO, máx 2-3 personajes centrales + antagonista, **8-10 escenarios por serie** — 3-4 principales con ≥3 views de posición cada uno + 4-6 secundarios/de transición (alley, rooftop, hallway, stairwell, building exterior, bus stop) con 1-2 views —, conflicto, EL RELOJ con fecha concreta, arco de 5-8 partes).
1b. **MAPA DE TEMPORADA obligatorio** antes de la Parte 1 (tabla: función, pago parcial, pregunta dominante, consecuencia ejecutada, tipo de cliffhanger por parte).
2. Parte 1: todos los assets iniciales `mode:"generate"` EN EL MISMO JSON.
2b. **ESTADO DE HISTORIA (ledger) al final de cada parte.** Máximo 3 preguntas grandes abiertas.
3. Partes siguientes: assets existentes `mode:"existing"` con la MISMA ruta; solo lo nuevo `generate`.
4. Cada parte = UN JSON completo. **No existe `_ASSETS.json`.**
5. Al final de cada parte: "ASSETS DE LA SERIE" actualizado (con ropa por pose, reloj, tipo de cliffhanger usado).

---

## 2. Contrato JSON v2 (versión ENG)

Secciones en este orden: `project → pipeline → characters → escenarios → ingredients → scenes → capcut_export → audio → tts_export`

```json
{
  "project": {
    "preset": "novelas-coreanas-eng",
    "title": "The Hidden Heiress - Part 1",
    "subtitle": "The Forbidden Name",
    "serie": "hidden_heiress",
    "slug": "hidden_heiress_part_01",
    "series": { "id": "hidden_heiress", "part": 1, "is_cliffhanger": true },
    "language": "en",
    "aspect_ratio": "9:16",
    "fps": 30,
    "reuse_ingredients": true,
    "grok_clip_seconds": "6",
    "scene_target_seconds": 4,
    "voice_target_seconds": [3, 4],
    "voice_ceiling_seconds": "5",
    "hook": "That night, everyone found out my real last name."
  },
  "pipeline": {
    "image_generation": { "tool": "grok" },
    "animation": { "tool": "grok" },
    "tts": { "tool": "fish" }
  },
  "characters": { "...igual que el manual español (prompts ya en inglés)..." : {} },
  "escenarios": { "...igual..." : {} },
  "ingredients": [],
  "scenes": [],
  "capcut_export": {
    "clip_order": ["scene_01", "scene_02"],
    "caption_style": { "font": "bold sans-serif", "position": "lower-third", "color": "white", "stroke": "black" },
    "title_cards": ["TO BE CONTINUED", "PART 2: THE SIGNATURE"],
    "cliffhanger_card": "PART 2?",
    "music_notes": ["Soft dramatic piano"],
    "sfx_notes": ["Murmuring guests, a glass set down hard, camera flashes"]
  },
  "audio": { "voice_speed": 1.25, "voice_rate": 1, "music_volume": 0 },
  "tts_export": {
    "mode": "per_scene",
    "voice_id": "REEMPLAZAR_voice_id_narradora_ingles",
    "note": "One single female English voice narrates every scene, including all dialogue. Fish Audio per scene."
  }
}
```

Reglas duras del contrato (idénticas): `fps` número · sin `opening` · sin `narrative_card` · sin `static` · el campo es **`voice_id`** (nunca `voice`) · `voice_speed: 1.25` SIEMPRE · `music_volume: 0` (música y SFX solo como notas) · `speaker: "narrador"` en cada escena.

---

## 3. Assets: personajes, poses, escenarios y views

**Idéntico al manual español.** Los prompts de assets ya se escriben en inglés en ambos presets. Recordatorios duros:

- `characters.<id>.poses`: `base` limpia (rostro claro, edad, manos vacías), derivadas con `reference_pose`, reutilización `mode:"existing"` con la misma ruta. Ruta: `assets/characters/<serie>/<personaje>_<pose>.png`.
- **REGLA DE POSTURA:** escena sentada → pose sentada; escena arrodillada → pose arrodillada. Nunca una pose de pie para una escena sentada (origen del defecto "personaje encima de la mesa").
- `escenarios.<id>.views`: una view nueva = OTRA posición física de cámara (desde la puerta, desde el fondo, cenital, close de mobiliario). Cambiar solo la luz NO es una view nueva. Views close de mobiliario = SOLO inserts sin cuerpo entero. Para diálogos importantes: par plano/contraplano (`lado_a`/`lado_b`).
- **CAMBIO PRIMERO, ANCLA DESPUÉS (regla dura de views derivadas):** Grok pesa más lo primero que lee — si el prompt empieza con "Same ballroom…", repite la imagen de referencia e ignora el ángulo nuevo. **PROHIBIDO empezar con "Same <escenario>".** Patrón obligatorio: `"New camera position: <desde dónde + qué se ve + primer plano>. Keep the exact same <escenario> architecture, furniture and lighting as the reference. Empty set, no people, no text."` (En POSES de personaje sí se mantiene "Same character X, same face…" PRIMERO: ahí lo crítico es la identidad facial.)
- **REGLA ANTI-MONOTONÍA:** mínimo 4-5 escenarios distintos por Parte; ninguno concentra más del 50% de las escenas; máximo 3-4 escenas seguidas en el mismo escenario (aunque cambie la view — intercala un insert o un exterior); cada escenario principal con ≥3 views de posición; cada Parte introduce ≥1 escenario nuevo o 2 views nuevas. Las transiciones (llegar, salir, esperar) van en sets secundarios, no otra vez en el principal.
- Props recurrentes en `ingredients[]` como `entity`, SIEMPRE con su `generation_prompt` aunque ya existan (el pipeline lo exige; se recopia el bloque con el mismo `output_file`).
- **CUPO DURO: máximo 3 imágenes de referencia por escena** (personajes + escenario view + ingredientes). 2 personajes + escenario = 3 → ya no cabe prop.

---

## 4. Escenas

Idéntico: todas animadas (`render_mode:"animated"` u omitido), cada escena ≥1 referencia válida, toda persona recurrente en `references.characters`, multitudes = extras anónimos coreanos desenfocados, inserts sin cuerpo entero, dos personajes = declarar lados y eyelines (regla de 180°).

```json
{
  "id": "scene_01",
  "render_mode": "animated",
  "references": {
    "characters": [{ "id": "soo_yeon", "pose": "base" }],
    "escenario": { "id": "gran_salon", "view": "base" },
    "ingredients": [], "scenes": []
  },
  "visual": { "image_prompt": "...", "animation_prompt": "..." },
  "voiceover": { "text": "[low, cold, tense] That night, everyone found out my real last name.", "speaker": "narrador" },
  "captions": { "text": "MY REAL NAME", "highlight_words": ["name"] }
}
```

---

## 5. Guion (salida EN INGLÉS)

Toda la arquitectura del §5 español aplica sin cambios: FILTRO UNIVERSAL DE VIRALIDAD (hook sin explicación, promesa según motor en esc. 2-3, daño ejecutado antes de la esc. 6, UNA pregunta dominante, escalera de consecuencias, víctima antes de icónica, objeto ancla, anti-abstracción, pago antes del cliffhanger, motor consistente) · Selector de MOTOR (A-R con sus densidades D y reversals) · Selector de MUNDO (A-J con sus packs) · plantillas de Parte 1 y Parte N · regla anti-valle · taxonomía de 4 cliffhangers ROTADOS (revelación, reversal, intrusión, deadline; nunca repetir tipo consecutivo) · MAPA DE TEMPORADA · ESTADO DE HISTORIA · máximo 3 loops abiertos.

**Diferencias de idioma:**

- Idioma hablado: **inglés**. Prompts visuales: inglés (igual que siempre).
- Voz narrativa: primera persona de la protagonista, frases cortas, emoción contenida. Longitud por escena: **3-16 palabras, promedio 8-11**, con VARIANZA obligatoria (≥1 golpe de ≤5 palabras por cada 5 escenas: *"First, my bedroom."*). El inglés es más compacto que el español: si una línea suena larga, córtala.
- **Máximo 4 nombres propios HABLADOS por parte**, presentados con su relación la primera vez: *"Tae-sung, my husband's brother, stood up."* El resto por rol: "my mother-in-law", "the lawyer", "the old waiter". Un solo apodo por persona en TODA la serie.
- **Diálogos en estilo DIRECTO.** En inglés, la cita se marca con comillas dobles, no con raya: `Tae-sung spat: "A stranger's widow, running our company?"`. También vale la línea a pelo sin tag cuando la escena N anterior plantó al hablante: `"I'm not here to take anything from you."` PROHIBIDO el estilo indirecto ("he said that…", "she asked if…").
- **Flashbacks anclados al entrar Y al salir**: *"Three days before he died, the chairman…"* → *"Back at the boardroom, …"*.
- Repetición estratégica del dato que sostiene la parte (el plazo, la cifra) 2 veces con palabras distintas.
- **PRUEBA DEL CIEGO (obligatoria):** leyendo SOLO los `voiceover.text`, en 8 segundos debe poder decirse en voz alta: *"I am [name/role], I'm being attacked by [antagonist] who took [concrete debt] from me, and the payment coming is [promise/person]."* Si no, se reescribe la voz.

### §5-bis. Normalización para Fish (INGLÉS) — sustituye a la regla de tildes

- **Números, horas y cantidades EN PALABRAS:** "seven in the evening", "three billion won", "twenty-one years" — nunca "7pm", "3,000,000,000", "21".
- **Sin abreviaturas:** "Mister Jang", no "Mr. Jang"; "Doctor", no "Dr."; "Company" no "Co.".
- **Nombres coreanos: UNA romanización fija por serie** y la misma en todas las Partes ("Ji-woo" siempre, nunca alternar con "Jiwoo"). ⚠️ Los guiones pueden producir pausas raras según la voz: en la primera Parte de cada serie, probar el nombre en la voz elegida; si la voz corta el nombre, usar la forma pegada ("Jiwoo") de forma consistente y anotarlo en el ESTADO DE HISTORIA.
- Contracciones naturales SÍ ("didn't", "I'm"): la narradora debe sonar humana, no leída.
- Puntuación expresiva con moderación: puntos y comas mandan; los puntos suspensivos añaden pausa/peso.

### Tags Fish (igual que en español)

Compuestos en INGLÉS, 3-5 elementos, SOLO en beats fuertes (gancho, revelación, cliffhanger), al inicio de la oración. **Regla de este canal: máximo 2-3 tags por Parte** (el usuario detectó que los tags alargan los tiempos; usar los mínimos). Catálogo útil: `[low, cold, tense]` · `[soft, trembling, hurt]` · `[icy, controlled, threatening]` · `[breathless, urgent]` · `[bitter, mocking]` · `[warm, nostalgic, sad]` · `[low, resolute]` · `[low, cold, knowing]`.

### El gancho (0-3 segundos) — fórmulas en inglés

1. **Ultimátum:** `"Sign the divorce before midnight, or your mother never leaves that hospital."`
2. **Humillación en su pico:** la copa ya derramada; el gancho es la reacción.
3. **Documento que estalla:** el close del papel con la frase asesina.
4. **Reacción primero:** `"That night, everyone found out my real last name."`

Reglas duras: UN solo nombre propio en la escena 1 · el hook NO spoilea el giro del cliffhanger · la promesa (esc. 2-3) es MÍTICA (una persona de poder, un lugar que reacciona…), nunca "a lawyer called me". Partes 2+: re-dramatizar sin recap ("Previously…" PROHIBIDO). Fórmulas de reentrada en inglés: `"I got my name back. That same night, the police came for me."` · `"The mansion opened its doors again — but my room already had a new owner."` · `"We won the trial. Then my mother confessed she'd lied."`

### Cards finales (en inglés)

`title_cards`: `["TO BE CONTINUED", "PART N: <TEASER>"]` · `cliffhanger_card`: `"PART N?"` · Final de temporada: `["END OF SEASON ONE", "SEASON 2: <TEASER>"]` / `"SEASON 2?"`. Corte a negro en seco. No resolver el misterio.

---

## 6. Prompts visuales (igual que el manual español)

Todo en inglés. Reglas que NO cambian:

- **Regla de oro de Grok:** los negativos se IGNORAN; todo lo crítico en POSITIVO ("empty hands", "she sits BEHIND the desk"). Con referencias, modo EDICIÓN: patrón **"Keep [X], change [Y]"**. Lo importante PRIMERO; ~25-60 palabras descriptivas; máximo ~10 objetos.
- **Estructura obligatoria del image_prompt:** `"Using the provided <DisplayName> (<descriptor físico corto>) in the provided <escenario view>: <1 tamaño de plano> + <2 posición de cámara> + <3 COLOCACIÓN> + <4 acción/emoción + MANOS> + <5 luz>. <6 ancla de estilo>. <7 negativos>. Vertical 9:16."` — "in the provided", nunca "on" (salvo superficie real). Insert shots sin rostro para objetos/manos.

- **DESCRIBIR, NO SOLO NOMBRAR (regla dura).** Un nombre propio no lleva información visual: para el modelo "Ha-na" es un token vacío y la cara se la inventa. El `display_name` sigue siendo obligatorio (el pipeline lo usa para casar la referencia), pero SIEMPRE va con un descriptor físico corto la primera vez que aparece en el prompt, y después el personaje se menciona POR DESCRIPCIÓN:
  - ❌ `"Using the provided Ha-na in the provided kitchen: medium shot, Ha-na wipes the counter while Ha-na's mother watches."`
  - ✅ `"Using the provided Ha-na (a Korean woman in her early thirties, long dark hair tied back, grey work apron) in the provided kitchen: cowboy shot, the woman in the grey apron wipes the steel counter while an older woman in an ivory suit watches from the doorway."`
  Descriptor de 4-8 palabras (edad aproximada + pelo + prenda distintiva), **el mismo en toda la serie** (se anota junto a la pose en ASSETS DE LA SERIE). Con dos personajes en cuadro, cada uno lleva el suyo y se distinguen por prenda/edad, nunca por nombre. Aplica IGUAL al `animation_prompt`.
- **COLOCACIÓN obligatoria con mobiliario:** verbo de postura + preposición + oclusión + pies. (`seated at the long table, BEHIND the table edge, the tabletop in the foreground partially hiding her waist, feet on the floor under the table`).
- **Luz de melodrama:** lujo = `warm tungsten glow, golden practicals, soft haze`; frialdad = `cold blue-grey light, desaturated steel palette`; `window backlight` para secretos. La luz NO cambia dentro de una secuencia continua.
- **Ancla de estilo:** `cinematic Korean family melodrama, realistic East-Asian characters, elegant luxury atmosphere, emotionally restrained acting, natural skin texture, shallow depth of field, high production value, consistent facial identity, consistent wardrobe.` (en wides: sustituir `shallow depth of field` por `deep focus, the full room in sharp detail`). Packs por mundo (sageuk, C-drama, noir, survival, mythic, sci-fi) idénticos al manual español.
- **Negativos default:** `No text, no subtitles, no watermark, no logo, no deformed hands, no extra hands, no duplicated faces, no cloned characters, no Western appearance, no anime, no fantasy, no superpowers, no historical clothing. No direct eye contact with the camera. Vertical 9:16.`

### §6-bis. CÁMARA AMPLIADA — LO NUEVO DE ESTA VERSIÓN

El preset ENG pide deliberadamente **más variedad de cámara, más tomas lejanas y más lenguaje de cine**. Se amplían las tres listas del manual español:

**A) TAMAÑOS de plano (lista cerrada ampliada — declara UNO):**

- `extreme wide shot, the figure tiny against the architecture, head to feet clearly visible` ← NUEVO. Para soledad, poder aplastante, antes/después de un golpe. El entorno es el sujeto.
- `establishing wide shot, floor to ceiling visible, full body small in the lower third` (el wide clásico del preset)
- `full body shot, head to feet in frame` ← **escribe SIEMPRE "head to feet in frame" y "both feet on the floor/ground"**. Sin esas dos frases Grok recorta a medio cuerpo y el plano abierto no existe.
- `cowboy shot, from the knees up, hands and face both readable` ← NUEVO. **Sustituye al plano medio por defecto en confrontaciones de pie.** El "waist up" corta el cuerpo justo donde peor se ve y esconde las manos.
- `medium shot, waist up` ← usar SOLO en escenas sentadas tras mesa/escritorio, donde la cintura ya está ocluida por el mueble
- `medium close-up, chest up`
- `close-up` / `extreme close-up` (inserts; evitar animarlos con movimiento)

**B) POSICIONES físicas de cámara (ampliadas — obligatoria en wides, diálogos y contraplanos):**

Las del manual español siguen todas (doorway, visitor side, over-the-shoulder, table level, far end of the hallway, frontal at eye level, through the glass, high/low angle). NUEVAS:

- `camera across the street / from the far side of the market` → distancia emocional máxima, la protagonista pequeña en su mundo.
- `top-down overhead, directly above` → cuerpos en camas/tinas/mesas; geometría del poder.
- `ground-level camera at ankle height` → pies que caminan, objetos que caen, el dobladillo de un vestido. Brutal para inserts con tensión.
- `through the shelves / through the rack of garments / through a doorway, out-of-focus foreground objects framing the subject` → OCLUSIÓN: el espectador espía. Ideal para secretos y escuchas.
- `reflection framing: seen in the mirror / in the dark shop window / in a puddle` → duplicidad, identidad. (Regla: la cara reflejada cuenta como persona → va referenciada.)
- `silhouette against a bright doorway, backlit, features unreadable` → entradas de villano, decisiones.
- `from the balcony / mezzanine looking down` → juicio social, alguien observado por todos.
- `slight Dutch tilt` → SOLO 1 por parte, en el momento de quiebre.

**C) MOVIMIENTOS de cámara para `animation_prompt` (ampliados):**

La regla NO cambia: `ACTION (within 4 seconds):` + **UNA sola acción física + UN solo movimiento nombrado**, lento, sin re-describir la imagen, cerrando con `Single continuous shot. Keep face(s) EXACTLY as provided. Vertical 9:16.` Vocabulario ampliado:

Seguras (úsalas libremente):
- `static camera` · `slow dolly in` · `slow dolly out` · `slow push-in` · `handheld sway`
- `slow lateral tracking left` / `slow lateral tracking right` ← NUEVO. Caminatas, recorrer una mesa, pasar frente a una fila de personas.
- `slow tilt up from her hands to her face` ← NUEVO. Revela emoción tras la acción.
- `slow pull-back through the doorway` ← NUEVO. Cierre de escena/abandono: la cámara deja sola a la persona.

De riesgo medio (máximo 1-2 por cada 10 escenas, siempre `slow`):
- `slow crane up` / `slow crane down` ← NUEVO. Apertura o cierre de secuencia; eleva el punto de vista sobre el salón/el callejón.
- `slow orbit a few degrees around her` ← NUEVO. Momentos de revelación interior. NUNCA más de "a few degrees": una órbita amplia derrite la cara.
- `rack focus from the foreground object to her face` ← NUEVO. Solo con oclusión declarada en el image_prompt.

Prohibido igual que siempre: dos acciones, "cut to", "camera switch", movimientos rápidos, animar extreme close-ups de cara/manos, zoom brusco.

**C-bis) COMPOSICIÓN Y ANTI-REPETICIÓN DE CARA (nuevo):**

El defecto: 40 escenas de la misma cara, centrada, de frente, con la misma expresión.

- **Descentrar.** No todo al centro: `subject off-centre on the frame-left third, the empty room filling the right side` · `subject low in the bottom third, the ceiling filling the frame above` · `subject at the very edge of frame, most of the shot is the doorway she is about to cross`. El aire vacío comunica soledad y da variedad sin gastar escenarios.
- **Romper los tramos emocionales.** PROHIBIDO encadenar 3 primeros planos frontales. Cada 2-3 escenas de cara, sustituye una por: **insert del objeto** (manos, papel, taza, dobladillo) · **silueta lejana** a contraluz · **reflejo** (espejo, vidrio, charco, pantalla apagada) · **de espaldas** con la cara fuera de cuadro · **a través de** una puerta/estantería con primer plano desenfocado.
- **Si repites expresión, cambia o esconde la cara.** Dos golpes de dolor cercanos NO se resuelven con dos primeros planos frontales: el segundo va de espaldas, en perfil, en reflejo, con la cara tapada por una mano, o cortando a las manos. **La misma expresión no se muestra dos veces de frente en la misma Parte.**
- **Ángulos, no solo posiciones.** Rota entre `high angle looking down` · `low angle` · `strict profile from her left/right side` · `from behind, over her shoulder` · `top-down overhead` · `silhouette against a bright doorway, backlit, features unreadable` · `seen in the mirror / in the dark shop window / in a puddle` · `through the shelves with out-of-focus foreground objects framing her`. **Mínimo 3 ángulos distintos además del frontal por cada 10 escenas.**

**D) DISTRIBUCIÓN por cada 10 escenas (actualizada para ENG):**

- Mínimo 2 abiertas (wide/full) — **y de ellas, al menos 1 realmente LEJANA**: extreme wide, across-the-street, balcony u overhead. ← NUEVO
- Mínimo 1 encuadre con **oclusión, reflejo o silueta**. ← NUEVO
- **Mínimo 3 ángulos distintos además del frontal** (picado, contrapicado, perfil izq/der, de espaldas, cenital). ← NUEVO
- **Máximo 3 primeros planos frontales de la misma cara**; el resto de reacciones en perfil, de espaldas, reflejo o insert. ← NUEVO
- **Personaje descentrado en al menos 2 escenas.** ← NUEVO
- 2-3 planos medios (caballo de batalla del diálogo). En confrontaciones de pie: `cowboy shot, from the knees up`, no "waist up".
- Máximo 5 cerrados (close + mcu), inserts incluidos.
- Mínimo 1 over-the-shoulder o desde atrás.
- Máximo 1-2 movimientos "de riesgo medio" (crane/orbit/rack focus). ← NUEVO
- Nunca 2 escenas seguidas del mismo tamaño (EXCEPTO plano/contraplano D+D con cambio de lado). Máximo 2 seguidas con la misma view.
- Toda locación nueva se presenta con UN wide. Los reaction shots en primer plano llevan micro-expresión guionizada ("jaw tightens, eyes glisten").

**E) Escenas N vs D (bocas) — igual:** N = `mouth closed, not speaking, no direct eye contact with the camera`. D = quien habla en encuadre medio o más cerrado, rostro frontal/tres cuartos, y la fórmula lleva **nombre Y descriptor**, nunca el nombre solo: `"<Name>, the woman in the grey apron, begins speaking immediately, lips clearly moving through a short deliberate sentence; IMPORTANT: ONLY the woman in the grey apron moves her mouth; everyone else keeps their mouths closed and still."` Cuando hay dos personajes en cuadro, el descriptor es lo único que evita que Grok mueva la boca equivocada. La escena D coincide con la CITA directa en el voiceover. Densidad D según motor (injusticia 40-50% · romance/CEO/traición 35-45% · madre/culpa/identidad 30-45% · misterio/hospital/protección 25-40%), en ráfagas de 2-4.

### §6-ter. PICOS EMOCIONALES — actuación física real (obligatorio)

La contención (`emotionally restrained acting`) es el DEFAULT del género, pero en los PICOS la emoción se actúa con TODO EL CUERPO o el espectador no siente nada. **2-4 escenas de PICO por Parte** (humillación mayor, revelación, pérdida, cobro):

1. En el ancla de estilo, sustituir `emotionally restrained acting` por **`raw, intense emotional performance`**. El resto del ancla no cambia.
2. La emoción se escribe como ACCIÓN FÍSICA CONCRETA, nunca como adjetivo. Vocabulario listo:
   - **Llanto/devastación:** `collapsed on her knees on the floor, sobbing openly, face crumpled, tears streaming down her cheeks` · `slumped against the wall, sliding down to the floor` · `clutching the dress against her chest, rocking slightly` · `gripping the table edge to stay upright, head hanging, shoulders shaking`.
   - **Ira real:** `slamming her palm flat on the table` · `sweeping the dishes off the table with one arm` · `gripping his collar with both fists` · `pointing with a trembling finger, face flushed, jaw clenched, veins tense in her neck` · `tearing the document in half with both hands`.
   - **Miedo/desesperación:** `backing against the wall, both hands shaking` · `grabbing his sleeve with both hands, begging` · `one hand clutching her chest, breathing hard`.
   - **Alegría/alivio:** `laughing openly, eyes crinkled shut, both hands over her mouth` · `pulling her into a tight embrace, eyes squeezed shut` · `sinking into a chair with relief, hand over her heart`.
3. **Bocas en picos (N):** llanto con boca abierta SOLO blindado: `mouth open in a silent sob, not forming words, no speech-like lip movement`. La ira en N mantiene `jaw clenched, mouth closed`; el grito con palabras va SIEMPRE en escena D con su cita.
4. **Animación del pico:** UNA acción + UN movimiento, pero la acción es la física del pico: `her shoulders shake as she sobs` · `she slams her palm on the table once and the glasses jump` · `she slides slowly down the wall to the floor` · `she tears the paper in one motion`. Golpes/rasgados se ejecutan UNA vez (el loop se ve falso). Lágrimas y cara rota van en el IMAGE prompt; la animación aporta el temblor.
5. **REGLA DE POSTURA:** pico en el piso → pose de colapso (`llorando_piso`) generada en el mismo JSON. Nunca un colapso con pose de pie.
6. **Dosificación:** el pico pega porque el resto está contenido. Golpe-golpe-respiro → el pico ESTALLA → vuelve la contención. Colocación típica: 1 en la humillación central, 1 en la revelación/cobro, opcional 1 en el cliffhanger.

---

## 7. Captions e highlights (EN INGLÉS)

- `captions.text`: cortos (3-7 palabras), **EN MAYÚSCULAS**, selectivos (~10-15 de 50 escenas; pueden ir `""`). En inglés: `"MY REAL NAME"`, `"TWENTY YEARS"`, `"SHE CAME BACK"`.
- `highlight_words`: solo palabras que APARECEN en el `voiceover.text` de esa escena.
- Sin tildes que vigilar, pero MISMA regla de sobriedad: el caption comprime, no repite la línea entera.

---

## 8. Voz y audio

```json
"audio": { "voice_speed": 1.25, "voice_rate": 1, "music_volume": 0 },
"tts_export": { "mode": "per_scene", "voice_id": "REEMPLAZAR_voice_id_narradora_ingles" }
```

- Fish Audio, `mode:"per_scene"`, `speaker:"narrador"` en cada escena, **una sola voz femenina INGLESA** para toda la serie (todas las Partes, el MISMO voice_id).
- ⚠️ **ANTES de la primera serie ENG:** elegir en Fish Audio una narradora femenina en inglés (registro contenido, no cartoon), probar 2-3 líneas del gancho con tags y sin tags, y reemplazar `REEMPLAZAR_voice_id_narradora_ingles` en el pipeline/JSON. Anotar el ID elegido en esta guía.
- `voice_speed: 1.25` fijo. `music_volume: 0` (música/SFX como notas de capa manual).

---

## 9. Continuidad

Idéntico al manual español: ropa por pose registrada en ASSETS DE LA SERIE · continuidad física entre escenas · luz consistente por secuencia · pose = postura + ropa + emoción · view = ángulo Y distancia del prompt · eyelines consistentes en diálogo (180°) · cada asset nuevo se usa ≥1 vez · nada se regenera si ya existe · ≤3 referencias por escena.

---

## 10. Checklist (versión ENG)

- [ ] MOTOR + MUNDO elegidos y documentados antes de escribir. Opt-ins declarados si aplican.
- [ ] Serie nueva: MAPA DE TEMPORADA aprobado antes de la Parte 1. ESTADO DE HISTORIA al final de cada parte.
- [ ] `project.preset` = **`"novelas-coreanas-eng"`** · `project.language` = `"en"` · `serie`/`slug` correctos · archivo `<slug>_partNN.json`.
- [ ] `pipeline` = grok/grok/fish · `fps` número · sin `opening`/`static`/`narrative_card`.
- [ ] 30-50 escenas, todas con `image_prompt` + `animation_prompt` · densidad D según motor, en ráfagas.
- [ ] FILTRO DE VIRALIDAD: hook EN INGLÉS sin explicación, con UN nombre, sin spoilear el giro · promesa esc. 2-3 según motor · daño ejecutado antes de esc. 6 · víctima antes de icónica · objeto ancla que vuelve · pago antes del cliffhanger · cliffhanger de tipo ROTADO.
- [ ] **Voiceover EN INGLÉS**: 3-16 palabras (prom. 8-11), varianza con golpes ≤5, números en palabras, sin abreviaturas, máx 4 nombres hablados con relación, citas directas con comillas, flashbacks anclados, PRUEBA DEL CIEGO superada.
- [ ] **Tags Fish: máximo 2-3 por Parte**, compuestos, solo en beats fuertes.
- [ ] Captions EN INGLÉS, cortos, selectivos; highlights realmente hablados.
- [ ] Poses de POSTURA para escenas sentadas/arrodilladas · views close solo para inserts · ≤3 referencias/escena · assets existentes con `mode:"existing"` y ruta idéntica.
- [ ] Image prompts con los 7 slots + COLOCACIÓN con oclusión · "in the provided".
- [ ] **DESCRIBIR, NO SOLO NOMBRAR: cada personaje lleva descriptor de 4-8 palabras la primera vez y se menciona por descripción después, en image_prompt Y animation_prompt. El mismo descriptor en toda la serie.**
- [ ] **`full body shot` siempre con "head to feet in frame" + "both feet on the floor/ground". Confrontaciones de pie en `cowboy shot, from the knees up`; "waist up" SOLO sentados tras mueble.**
- [ ] **COMPOSICIÓN: ≥3 ángulos no frontales por cada 10 escenas · ≤3 primeros planos frontales de la misma cara · ≥2 escenas con el personaje descentrado · ninguna expresión repetida de frente dos veces en la misma Parte · tramos emocionales rotos con insert/silueta/reflejo/de espaldas.**
- [ ] **Distribución de cámara ENG cumplida (§6-bis D): ≥2 abiertas con ≥1 LEJANA, ≥1 oclusión/reflejo/silueta, ≥1 OTS, ≤5 cerrados, ≤2 movimientos de riesgo, sin repetir tamaño consecutivo (salvo plano/contraplano D+D), máx 2 views iguales seguidas.**
- [ ] **VARIEDAD DE ESCENARIOS: ≥4-5 escenarios por Parte, ninguno >50% de las escenas, máx 3-4 seguidas en el mismo set, principales con ≥3 views, ≥1 set nuevo o 2 views nuevas por Parte.**
- [ ] **Views derivadas empiezan con "New camera position: …" — nunca con "Same <escenario>".**
- [ ] **2-4 PICOS emocionales (§6-ter): ancla `raw, intense emotional performance`, acción física de cuerpo entero, pose de postura acorde, boca blindada (`silent sob, not forming words`) en N.**
- [ ] animation_prompt: UNA acción + UN movimiento del vocabulario ampliado · N boca cerrada · D solo el hablante mueve la boca.
- [ ] `voice_id` = voz inglesa femenina (NO el ID español) · `voice_speed` 1.25 · `music_volume` 0.
- [ ] Cards EN INGLÉS ("TO BE CONTINUED" / "PART N: …" / "PART N?") y corte a negro.
- [ ] JSON válido UTF-8 (validar con `json.load`) · "ASSETS DE LA SERIE" actualizado al final.

---

## 11. Errores comunes (los del manual español MÁS los nuevos ENG)

Todos los del manual español aplican (personaje encima de la mesa, negativos con fe ciega, más de 3 referencias, re-describir en el animation_prompt, recap en Parte 2+, papeleo antes de la herida, heroína invencible, reversal por documento, etc.). NUEVOS del formato ENG:

- Dejar el `voice_id` español en un JSON ENG (la voz narraría en español o pronunciaría fatal el inglés).
- Mezclar idiomas: una línea de voiceover o un caption en español dentro de una parte ENG.
- Escribir "Mr./Dr./7pm/21" en el voiceover (rompe el TTS).
- Cambiar la romanización de un nombre entre Partes ("Ji-woo" → "Jiwoo").
- Usar rayas españolas (—) para diálogo en inglés en vez de comillas.
- Abusar del vocabulario nuevo: más de 2 movimientos de riesgo (crane/orbit) por cada 10 escenas, o una órbita amplia que derrite la cara.
- Convertir todos los wides en extreme wides: la toma lejana es 1 de cada 10, no la norma.
- Traducir los nombres coreanos o "occidentalizar" el reparto: el género ES coreano en inglés.
- Empezar el prompt de una view derivada con "Same <escenario>": Grok repite la referencia e ignora el ángulo. El cambio de cámara PRIMERO; el "Keep the exact same…" después.
- Parte entera en 2 escenarios, o escenario principal con una sola view: monotonía aunque el guion sea bueno.
- Llanto o furia "calmados" en un pico: la emoción se actúa con el cuerpo (colapso, golpe, súplica) y el ancla cambia a `raw, intense emotional performance`.
- Gritar con palabras en escena N, o llanto de boca abierta sin blindar (`silent sob, not forming words`).
- Repetir el golpe/rasgado en loop en el animation_prompt (la acción intensa se ejecuta UNA vez).
- **Nombrar sin describir** (`"Ha-na wipes the counter"`): el nombre no lleva información visual y el modelo inventa la cara o mueve la boca del personaje equivocado. Siempre nombre + descriptor, y después solo descripción.
- Usar un descriptor distinto en cada Parte ("grey apron" → "work uniform"): la identidad se rompe entre Partes. El descriptor se fija en ASSETS DE LA SERIE y no se toca.
- Pedir `full body shot` sin "head to feet in frame" y sin "both feet on the floor": Grok recorta a medio cuerpo y la Parte se queda sin un solo plano abierto real.
- Usar `medium shot, waist up` en confrontaciones de pie: corta el cuerpo donde peor se ve y esconde las manos. Va `cowboy shot, from the knees up`.
- Personaje siempre centrado y de frente: descentra, deja aire, usa el borde del cuadro.
- Encadenar 3 primeros planos frontales en un tramo emocional: cada 2-3 caras, un insert de objeto, una silueta lejana, un reflejo o un de-espaldas.
- Resolver dos veces la misma expresión con la misma cara frontal: el segundo golpe va de espaldas, en perfil, en reflejo o con la cara tapada.

---

## 12. Ejemplo de tres escenas (template ENG aplicado)

Escena 1 = **extreme wide** lejano y descentrado con gancho · escena 2 = diálogo D con cita en comillas · escena 3 = **cowboy shot** con oclusión + rack focus. Los tres llevan el descriptor `(a Korean woman in her late twenties, long dark hair down, black gala dress)` la primera vez y luego se refieren a ella como "the woman in the black gala dress".

```json
{
  "project": {
    "preset": "novelas-coreanas-eng",
    "title": "The Hidden Heiress - Part 1",
    "serie": "hidden_heiress",
    "slug": "hidden_heiress_part_01",
    "series": { "id": "hidden_heiress", "part": 1, "is_cliffhanger": true },
    "language": "en", "aspect_ratio": "9:16", "fps": 30,
    "reuse_ingredients": true, "grok_clip_seconds": "6",
    "scene_target_seconds": 4, "voice_target_seconds": [3, 4], "voice_ceiling_seconds": "5",
    "hook": "That night, everyone found out my real last name."
  },
  "pipeline": { "image_generation": { "tool": "grok" }, "animation": { "tool": "grok" }, "tts": { "tool": "fish" } },
  "characters": {
    "soo_yeon": {
      "display_name": "Soo-yeon",
      "poses": {
        "base": { "mode": "generate", "asset": "assets/characters/hidden_heiress/soo_yeon_base.png", "prompt": "Character reference, vertical 9:16, single elegant Korean woman, age 23, realistic East-Asian features, oval face, dark brown eyes, long straight black hair, cream blouse, navy skirt, restrained dignified expression, empty hands, neutral soft grey studio background. Cinematic Korean melodrama, natural skin texture, high detail. No text, no logo, no watermark." },
        "gala": { "mode": "generate", "asset": "assets/characters/hidden_heiress/soo_yeon_gala.png", "reference_pose": "base", "prompt": "Same character Soo-yeon, same face and hair, elegant black gala dress, empty hands, restrained expression, neutral studio background." }
      }
    }
  },
  "escenarios": {
    "gran_salon": {
      "display_name": "Grand ballroom",
      "views": {
        "base": { "mode": "generate", "asset": "assets/escenarios/hidden_heiress/gran_salon_base.png", "prompt": "EMPTY luxury Korean hotel ballroom, chandeliers, marble floor, warm elegant lighting, gala atmosphere, no people, no text, realistic cinematic K-drama, vertical 9:16." },
        "desde_balcon": { "mode": "generate", "asset": "assets/escenarios/hidden_heiress/gran_salon_desde_balcon.png", "reference_view": "base", "prompt": "New camera position: from the mezzanine balcony looking down at the marble floor, the balcony rail in the foreground. Keep the exact same luxury ballroom architecture and warm chandelier lighting as the reference. Empty set, no people, no text." },
        "close_mesa": { "mode": "generate", "asset": "assets/escenarios/hidden_heiress/gran_salon_close_mesa.png", "reference_view": "base", "prompt": "New camera position: extreme close view of a table with crystal glasses and a folded card in the foreground, shallow depth of field. Keep the exact same ballroom and warm lighting as the reference. Empty set, no people, no text." }
      }
    }
  },
  "ingredients": [],
  "scenes": [
    {
      "id": "scene_01",
      "render_mode": "animated",
      "references": { "characters": [{ "id": "soo_yeon", "pose": "gala" }], "escenario": { "id": "gran_salon", "view": "desde_balcon" }, "ingredients": [], "scenes": [] },
      "visual": {
        "image_prompt": "Using the provided Soo-yeon (a Korean woman in her late twenties, long dark hair down, black gala dress) in the provided ballroom balcony view: extreme wide shot from the mezzanine balcony looking down, the figure tiny against the architecture, head to feet clearly visible, the woman in the black gala dress standing alone and off-centre on the frame-left third of the marble floor with the empty ballroom filling the right side, both feet on the marble, hands still at her sides, blurred anonymous Korean gala guests drawing back from her on all sides, warm amber chandelier light with soft haze. Cinematic Korean family melodrama, realistic East-Asian characters, elegant luxury atmosphere, emotionally restrained acting, natural skin texture, deep focus, the full room in sharp detail, high production value, consistent facial identity, consistent wardrobe. No text, no watermark, no deformed hands, no Western appearance, no anime. No direct eye contact with the camera. Vertical 9:16.",
        "animation_prompt": "ACTION (within 4 seconds): the blurred guests draw back from her in a slow ring while she stays frozen, mouth closed, not speaking; slow crane down. Single continuous shot. Keep face EXACTLY as provided. Vertical 9:16."
      },
      "voiceover": { "text": "[low, cold, tense] That night, everyone found out my real last name.", "speaker": "narrador" },
      "captions": { "text": "MY REAL NAME", "highlight_words": ["name"] }
    },
    {
      "id": "scene_02",
      "render_mode": "animated",
      "references": { "characters": [{ "id": "soo_yeon", "pose": "gala" }], "escenario": { "id": "gran_salon", "view": "base" }, "ingredients": [], "scenes": [] },
      "visual": {
        "image_prompt": "Using the provided Soo-yeon (a Korean woman in her late twenties, long dark hair down, black gala dress) in the provided grand ballroom: medium close-up, chest up, camera fixed at eye level, the woman in the black gala dress turned three-quarters to camera and framed off-centre to the right, mouth clearly visible, one tear held in her lower lid, hands still at her sides, warm chandelier backlight rimming her hair. Cinematic Korean family melodrama, realistic East-Asian characters, elegant luxury atmosphere, emotionally restrained acting, natural skin texture, shallow depth of field, high production value, consistent facial identity, consistent wardrobe. No text, no watermark, no deformed hands, no anime. No direct eye contact with the camera. Vertical 9:16.",
        "animation_prompt": "ACTION (within 4 seconds): Soo-yeon, the woman in the black gala dress, begins speaking immediately, lips clearly moving through a short deliberate sentence; IMPORTANT: ONLY the woman in the black gala dress moves her mouth; everyone else keeps their mouths closed and still; static camera. Single continuous shot. Keep face EXACTLY as provided. Vertical 9:16."
      },
      "voiceover": { "text": "\"I didn't come to apologize. I came to take back everything.\"", "speaker": "narrador" },
      "captions": { "text": "", "highlight_words": [] }
    },
    {
      "id": "scene_03",
      "render_mode": "animated",
      "references": { "characters": [{ "id": "soo_yeon", "pose": "gala" }], "escenario": { "id": "gran_salon", "view": "close_mesa" }, "ingredients": [], "scenes": [] },
      "visual": {
        "image_prompt": "Using the provided Soo-yeon (a Korean woman in her late twenties, long dark hair down, black gala dress) in the provided ballroom table close view: cowboy shot from the knees up, hands and face both readable, camera through the crystal glasses on the table, out-of-focus glassware in the foreground framing her, the woman in the black gala dress standing beyond the table, her body BEHIND the table edge, both feet on the marble, one hand resting on a folded card on the cloth, warm chandelier light. Cinematic Korean family melodrama, realistic East-Asian characters, elegant luxury atmosphere, emotionally restrained acting, natural skin texture, shallow depth of field, high production value, consistent facial identity, consistent wardrobe. No text, no watermark, no deformed hands, no anime. No direct eye contact with the camera. Vertical 9:16.",
        "animation_prompt": "ACTION (within 4 seconds): her fingers close slowly around the folded card, mouth closed, not speaking; rack focus from the foreground object to her face. Single continuous shot. Keep face EXACTLY as provided. Vertical 9:16."
      },
      "voiceover": { "text": "Nobody gave me my father's chair. So I took it.", "speaker": "narrador" },
      "captions": { "text": "MY FATHER'S CHAIR", "highlight_words": ["chair"] }
    }
  ],
  "capcut_export": {
    "clip_order": ["scene_01", "scene_02", "scene_03"],
    "caption_style": { "font": "bold sans-serif", "position": "lower-third", "color": "white", "stroke": "black" },
    "title_cards": ["TO BE CONTINUED", "PART 2: THE SIGNATURE"],
    "cliffhanger_card": "PART 2?",
    "music_notes": ["Soft dramatic piano"],
    "sfx_notes": ["Gala murmur", "A single glass set down"]
  },
  "audio": { "voice_speed": 1.25, "voice_rate": 1, "music_volume": 0 },
  "tts_export": { "mode": "per_scene", "voice_id": "REEMPLAZAR_voice_id_narradora_ingles", "note": "One single female English voice narrates everything." }
}
```
