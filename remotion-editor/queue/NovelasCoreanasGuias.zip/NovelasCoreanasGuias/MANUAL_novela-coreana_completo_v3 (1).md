# Manual completo: preset `novela-coreana` v2 — GUIA v5

Este manual define como generar JSONs del preset `novela-coreana` v2: videos verticales 9:16 estilo K-drama melodramatico, con personajes coreanos fotorrealistas, escenas animadas en Grok y una sola voz femenina por Fish Audio.

Esta v5 NO cambia el contrato JSON v2 (sigue siendo el esquema `characters.<id>.poses` y `escenarios.<id>.views`). Lo que cambia es la ARQUITECTURA narrativa y visual: motor de DEUDA EMOCIONAL universal (la injusticia es UN motor de varios), sistema MOTOR + MUNDO/SKIN, MAPA DE TEMPORADA obligatorio, ESTADO DE HISTORIA por parte, packs visuales por mundo, y opt-in historico/mistico/mythic fantasy/survival/crime noir/sci-fi suave. La esencia no cambia: todo se anima, no hay paneles estaticos, no hay multivoz.

> **LA VIRALIDAD NO SALE DE TENER UN GIRO. SALE DE ABRIR UNA DEUDA EMOCIONAL QUE EL ESPECTADOR NECESITA VER PAGADA.**
> Esa deuda puede ser injusticia, identidad robada, deseo prohibido, abandono, culpa, proteccion de alguien vulnerable, misterio de lugar, amor bajo mentira, ascenso/supervivencia o traicion intima.
> Antes del secreto, debe DOLER. Antes del misterio, debe IMPORTARTE alguien. Antes del romance, debe existir un RIESGO. Antes del poder, debe haber VULNERABILIDAD. Antes de cualquier cliffhanger, debe haber un PAGO parcial. No escribas "historias de herencias": escribe historias donde una DEUDA emocional queda abierta y el espectador necesita verla cobrada.

**Cambios clave acumulados hasta la v5 (resumen):**

1. Template de `image_prompt` con COLOCACION obligatoria del personaje respecto al mobiliario (arregla el defecto "personaje encima de la mesa").
2. La pose referenciada debe coincidir con la POSTURA de la escena (escena sentada = pose sentada).
3. Vocabulario cerrado de tamanos de plano + posicion fisica de camara + distribucion obligatoria (arregla el defecto "todo son planos cercanos frontales").
4. Regla de oro de Grok: los negativos se IGNORAN; todo lo critico va en lenguaje positivo. El patron "Keep [X], change [Y]" es el que funciona con referencias.
5. Maximo 3 imagenes de referencia por escena (personaje + escenario + prop llenan el cupo).
6. `animation_prompt`: UNA sola accion + UN solo movimiento de camara por clip; nunca re-describir la imagen.
7. Guion con formulas de gancho 0-3 s, motor deseo+obstaculo+reloj, regla anti-valle y taxonomia de 4 cliffhangers rotados.
8. `voiceover.text` y `captions.text` SIEMPRE con ortografia espanola completa (tildes y enie); cifras escritas con palabras.
9. Narracion AUDIO-FIRST: la historia debe entenderse solo con el audio — conflicto primero, maximo 4 nombres hablados presentados con su relacion, dialogos en estilo directo, flashbacks anclados y prueba del ciego.
10. MOTOR DE INJUSTICIA (calibrado con el exito real del canal, heredera_oculta): 30-50 escenas por parte, 40-50% escenas D, despojos consumados en escalada + flashforward de promesa + reversal antes del cliffhanger, interioridad declarada, varianza ritmica (3-16 palabras) y titulo-promesa.
11. FILTRO DE VIRALIDAD antes de escribir (§5): hook sin explicacion ni spoiler del giro, promesa de pago emocional (en injusticia: una fuerza de poder, no "un abogado"), dano concreto ejecutado antes de la escena 6, VICTIMA antes de heroina iconica, objeto ancla que vuelve y anti-papeleo. Si la idea falla 2+ puntos, se reescribe entera.
12. MOTOR DE DEUDA EMOCIONAL universal + SELECTOR DE MOTOR (§5): la injusticia es UN subtipo de 10; el tipo de promesa, la escalera de consecuencias, la densidad D y el reversal VARIAN por motor. El GPT elige motor ANTES de escribir.
13. TEMPORADA (§5): MAPA DE TEMPORADA obligatorio antes de la Parte 1; PLANTILLA DE PARTE N (ninguna parte es puro setup); ESTADO DE HISTORIA (ledger de poder/secretos/preguntas/objeto/reloj/cliffhangers) al final de cada parte; maximo 3 preguntas grandes abiertas a la vez.
14. Lo MISTICO/SOBRENATURAL es OPT-IN por serie (magia sutil / poderes sencillos / visiones), CONTENIDO y fotorrealista; sin VFX de superheroe ni anime (ver §0 y §6).
15. SISTEMA DE DOS EJES: MOTOR (que deuda retiene) + MUNDO/SKIN (donde ocurre y con que lenguaje visual). El motor decide deuda/pago/pregunta; el mundo decide vestuario, escenarios, negativos, props, luz y limite de accion/fantasia. SELECTOR DE MUNDO (§5) con 10 skins, cada uno con su pack de negativos/ancla en §6.
16. 3 MOTORES NUEVOS (§5): N Regresion/segunda oportunidad (con ledger temporal), O Crime noir/mafia romance (violencia fuera de cuadro), P Survival game (tension por decision moral). Lo HISTORICO (sageuk/C-drama) es OPT-IN por serie (`allow_historical`): usa el pack historico de §6 (hanbok/hanfu permitidos), no el negativo default.

---

## 0. Que produce este preset

- Formato: vertical 9:16, `fps: 30`.
- Imagen y animacion: Grok.
- Duracion de escena: minimo 3-4 s, maximo 5 s. Se generan clips de 6 s y el editor recorta.
- Duracion de la parte: 30-50 escenas (~1:30-2:30). Calibrado con el exito real del canal en Facebook (heredera_oculta: 51 escenas). Una parte de 20-25 escenas solo alcanza para un prologo sin deuda emocional: no la publiques como Parte 1.
- Voz: Fish Audio, una sola narradora femenina para narracion y dialogos.
- Estilo: drama familiar/corporativo coreano, herederas, secretos, humillacion, ascenso, venganza emocional, lujo sobrio.
- Por DEFECTO realista (melodrama fotorrealista, que es lo que mas convierte). Lo MISTICO/SOBRENATURAL es OPT-IN por serie (`project.motor:"mistico"` o `project.allow_supernatural:true`): se permite magia sutil, poderes sencillos, visiones, premoniciones, objetos que reaccionan y atmosfera sobrenatural CONTENIDA (ver §6 "Prompts para lo sobrenatural"). Sigue PROHIBIDO el look superheroe/anime: rayos de energia, explosiones VFX, monstruos, transformaciones, ciencia ficcion dura (Grok los derrite y rompen el fotorrealismo que sostiene el genero). Siempre prohibido: gore, marcas y personas reales, comedia exagerada, accion fisica absurda.
- Lo HISTORICO (Joseon/palacio imperial) es OPT-IN por serie (`project.allow_historical:true` o `project.world:"sageuk"`/`"cdrama"`): usa el pack historico de §6 (hanbok/hanfu permitidos). El negativo "no historical clothing" solo aplica a los mundos MODERNOS; en un mundo historico se usa el pack del mundo, nunca el default. Antes de escribir, elige MOTOR + MUNDO (§5).
- La retencion se decide en los primeros 3 segundos: la escena 1 es la mas importante de toda la parte.

---

## 1. Flujo de trabajo por parte

1. Si es serie nueva, primero define biblia: titulo, `serie`, MOTOR PRINCIPAL + secundario (§5 Selector de motor), personajes (MAXIMO 2-3 centrales + antagonista), escenarios: **8-10 POR SERIE — EL DOBLE que antes** (3-4 principales con MINIMO 3 views de posicion cada uno + 4-6 secundarios/de transicion con 1-2 views: callejon, azotea, pasillo, escaleras, exterior del edificio, transporte, bano, cocina), conflicto central, EL RELOJ de la temporada (una fecha limite concreta: la boda, el juicio, la junta de accionistas, el desalojo) y arco de 5-8 partes.
1b. **MAPA DE TEMPORADA obligatorio (§5) antes de la Parte 1:** tabla de las 5-8 partes con funcion, pago parcial, pregunta dominante, consecuencia ejecutada y tipo de cliffhanger de cada una. NO generes la Parte 1 sin el mapa aprobado.
2. Parte 1: genera en el MISMO JSON todos los assets iniciales con `mode:"generate"`.
2b. **Cada parte cierra con ESTADO DE HISTORIA (§5, ledger).** NO generes la Parte N sin el ESTADO DE HISTORIA actualizado de la parte anterior: es lo que evita perder secretos, poder y preguntas abiertas.
3. Partes siguientes: todo asset ya creado va como `mode:"existing"` con la misma ruta. Solo lo nuevo va como `mode:"generate"`.
4. Cada parte entrega UN JSON completo. Ya no se entrega `<slug>_ASSETS.json`.
5. Al final de cada parte imprime "ASSETS DE LA SERIE" actualizado (ver formato abajo).

Regla madre: la primera corrida genera todo lo nuevo; despues el GPT conserva la lista de assets y reutiliza lo existente.

Formato de "ASSETS DE LA SERIE" (incluye continuidad de vestuario):

```
PERSONAJES
- soo_yeon (Soo-yeon): base [ropa: blusa crema/falda azul] | llorando_gala [vestido negro] | sentada_oficina [traje gris] [NUEVO]
ESCENARIOS
- gran_salon: base | desde_escalera
- despacho: base [NUEVO]
PROPS
- collar_perla
RELOJ DE LA SERIE: la junta de accionistas (quedan 3 partes)
CLIFFHANGER USADO EN ESTA PARTE: revelacion (la proxima parte NO debe repetir tipo)
```

---

## 2. Contrato JSON v2

Secciones en este orden:

`project` -> `pipeline` -> `characters` -> `escenarios` -> `ingredients` -> `scenes` -> `capcut_export` -> `audio` -> `tts_export`

```json
{
  "project": {
    "preset": "novela-coreana",
    "title": "La heredera oculta - Parte 1",
    "subtitle": "El apellido prohibido",
    "serie": "heredera_oculta",
    "slug": "heredera_oculta_parte_01",
    "series": { "id": "heredera_oculta", "part": 1, "is_cliffhanger": true },
    "language": "es",
    "aspect_ratio": "9:16",
    "fps": 30,
    "reuse_ingredients": true,
    "grok_clip_seconds": "6",
    "scene_target_seconds": 4,
    "voice_target_seconds": [3, 4],
    "voice_ceiling_seconds": "5",
    "hook": "Esa noche, todos descubrieron mi apellido."
  },
  "pipeline": {
    "image_generation": { "tool": "grok" },
    "animation": { "tool": "grok" },
    "tts": { "tool": "fish" }
  },
  "characters": {
    "soo_yeon": {
      "display_name": "Soo-yeon",
      "poses": {
        "base": {
          "mode": "generate",
          "asset": "assets/characters/heredera_oculta/soo_yeon_base.png",
          "prompt": "Character reference, vertical 9:16, single elegant Korean woman, age 23, realistic East-Asian features, oval face, dark brown eyes, long straight black hair, cream blouse, navy skirt, restrained dignified expression, empty hands, neutral soft grey studio background. Cinematic Korean melodrama, natural skin texture, high detail. No text, no logo, no watermark."
        },
        "llorando_gala": {
          "mode": "generate",
          "asset": "assets/characters/heredera_oculta/soo_yeon_llorando_gala.png",
          "reference_pose": "base",
          "prompt": "Same character Soo-yeon, same face, same hair, elegant black gala dress, restrained tears, empty hands, realistic Korean melodrama, neutral studio background."
        }
      }
    }
  },
  "escenarios": {
    "gran_salon": {
      "display_name": "Gran salon",
      "views": {
        "base": {
          "mode": "generate",
          "asset": "assets/escenarios/heredera_oculta/gran_salon_base.png",
          "prompt": "EMPTY luxury Korean hotel ballroom, chandeliers, marble floor, warm elegant lighting, gala atmosphere, no people, no text, realistic cinematic K-drama, vertical 9:16."
        },
        "desde_escalera": {
          "mode": "generate",
          "asset": "assets/escenarios/heredera_oculta/gran_salon_desde_escalera.png",
          "reference_view": "base",
          "prompt": "New camera position: from the top of the staircase looking down at the marble floor, the banister edge in the foreground. Keep the exact same luxury ballroom architecture and warm chandelier lighting as the reference. Empty set, no people, no text."
        }
      }
    }
  },
  "ingredients": [
    { "id": "collar_perla", "type": "entity", "generation_prompt": "Single pearl necklace, elegant Korean luxury melodrama prop, neutral background, high detail, no text.", "output_file": "assets/ingredients/heredera_oculta/collar_perla.png" }
  ],
  "scenes": [],
  "capcut_export": {
    "clip_order": ["scene_01", "scene_02"],
    "caption_style": { "font": "bold sans-serif", "position": "lower-third", "color": "white", "stroke": "black" },
    "title_cards": ["CONTINUARA", "PARTE 2: LA FIRMA"],
    "cliffhanger_card": "PARTE 2?",
    "music_notes": ["Piano dramatico suave"],
    "sfx_notes": ["Murmullos, golpe de copa, flash de camaras"]
  },
  "audio": { "voice_speed": 1.25, "voice_rate": 1, "music_volume": 0 },
  "tts_export": {
    "mode": "per_scene",
    "voice_id": "bfed5c0810a347dbb62e8ccce7f59c48",
    "note": "Una sola voz femenina narra todas las escenas. Fish Audio por escena."
  }
}
```

---

## 3. Assets: personajes, poses, escenarios y vistas

### Personajes

Cada personaje vive en `characters.<id>.poses`.

- `base`: ficha canonica. Primera aparicion normalmente `mode:"generate"`.
- Poses derivadas: `mode:"generate"` + `reference_pose`.
- Reutilizacion: `mode:"existing"` con la misma ruta.
- Ruta: `assets/characters/<serie>/<personaje>_<pose>.png`.

La pose base debe ser limpia: rostro claro, edad exacta, cabello, ojos, vestuario, expresion por defecto, manos vacias, sin props sostenidos. Los props sostenidos van en pose derivada o en la escena.

Define poses por contexto: `base`, `gala`, `uniforme_oficina`, `llorando`, `perfil_derecho`, `perfil_izquierdo`, `espaldas`, `sentada`, `con_documento`, `herida`, etc. Cada escena usa la pose correcta segun ropa, hora y estado emocional.

**REGLA DE POSTURA (nueva, obligatoria):** la pose referenciada debe coincidir con la POSTURA fisica de la escena, no solo con ropa y emocion.

- Escena sentada -> pose sentada (`sentada`, `sentada_oficina`). Si no existe, generala como pose derivada EN EL MISMO JSON antes de usarla.
- Escena apoyada/tumbada -> pose equivalente.
- NUNCA uses una pose de pie para una escena sentada: Grok conserva la postura de la ficha de referencia y "planta" al personaje de pie sobre el mueble. Este es el origen del defecto "personaje encima de la mesa".

Ejemplo de pose de postura:

```
"sentada_oficina": {
  "mode": "generate",
  "asset": "assets/characters/heredera_oculta/soo_yeon_sentada_oficina.png",
  "reference_pose": "base",
  "prompt": "Same character Soo-yeon, same face and hair, charcoal office suit, seated on a plain chair, upright posture, hands clasped on her lap, neutral studio background."
}
```

### Escenarios

Cada escenario vive en `escenarios.<id>.views`.

- `base`: vista general vacia del lugar.
- Vistas derivadas: `mode:"generate"` + `reference_view`.
- Reutilizacion: `mode:"existing"` con la misma ruta.
- Ruta: `assets/escenarios/<serie>/<escenario>_<view>.png`.

Una vista nueva significa otro angulo real de camara: desde la puerta, desde el fondo, cenital, contrapicado, desde la escalera, close del escritorio. Cambiar solo la hora o luz NO cuenta como vista nueva.

**REGLAS DE VIEWS (nuevas):**

- En este sistema la posicion fisica de la camara ES la view. Un plano lejano exige una view tomada desde lejos (`desde_la_puerta`, `desde_el_fondo`, `general_alta`). Si una parte transcurre casi entera en un escenario que solo tiene la view `base`, genera al menos UNA view nueva de POSICION en esa parte.
- Views con mobiliario u objetos en primer plano (`close_escritorio`, `close_mesa`) son SOLO para insert shots de manos, documentos u objetos, SIN personaje de cuerpo entero. Las escenas con personaje usan views con piso visible.
- Disena la view PARA el plano que vas a pedir: si la escena es "sentada tras el escritorio vista desde el lado del visitante", la view debe ser el despacho vacio visto desde el lado del visitante, con el escritorio en primer termino.
- Para dialogos importantes crea el PAR plano/contraplano: dos views del mismo escenario desde lados opuestos del eje (p.ej. `sofa_lado_a` y `sofa_lado_b`). Asi la conversacion alterna posiciones reales de camara.

**REGLA ANTI-MONOTONIA DE ESCENARIOS (nueva, dura):** el defecto tipico es una Parte entera en 2 lugares y siempre desde el mismo lado. Cuotas obligatorias:

- Cada Parte usa MINIMO 4-5 escenarios distintos. Ningun escenario concentra mas del 50% de las escenas de la Parte.
- Maximo 3-4 escenas seguidas en el MISMO escenario aunque cambie la view; si la secuencia dramatica exige quedarse mas, intercala un insert de objeto, un exterior o un plano del pasillo/calle y regresa.
- Cada escenario PRINCIPAL necesita minimo 3 views de POSICION distintas antes de la Parte 2 (no 1-2). Los secundarios pueden vivir con 1-2.
- Cada Parte introduce al menos 1 escenario nuevo O 2 views nuevas de posicion. Una serie que en la Parte 3 sigue con los mismos 3 sets se siente barata.
- Los momentos de transicion (llegar, salir, esperar, pensar) van en escenarios de transicion (callejon, escaleras, azotea, parada de bus), no en el set principal otra vez.

**CAMBIO PRIMERO, ANCLA DESPUES (nueva, para prompts de views derivadas):** Grok pesa mas lo PRIMERO que lee. Si el prompt de una view derivada empieza con "Same ballroom..." Grok tiende a repetir la imagen de referencia casi identica e ignora el angulo nuevo. PROHIBIDO empezar con "Same <escenario>". El prompt de view derivada empieza con la POSICION NUEVA y deja el ancla de identidad para el final:

- MAL: `"Same luxury ballroom, new camera position from the staircase looking down, same architecture..."`
- BIEN: `"New camera position: from the top of the staircase looking down at the marble floor, the banister edge in the foreground. Keep the exact same luxury ballroom architecture and warm chandelier lighting as the reference. Empty set, no people, no text."`

Patron: `"New camera position: <desde donde + que se ve + que hay en primer plano>. Keep the exact same <escenario> architecture, furniture and lighting as the reference. Empty set, no people, no text."` (En POSES de personaje NO aplica: ahi "Same character X, same face..." sigue yendo PRIMERO porque lo critico es la identidad facial.)

### Props

Los props recurrentes pueden ir en `ingredients[]` como `entity`, con `generation_prompt` y `output_file`. Se referencian por `references.ingredients`.

OJO: los `ingredients` llevan SIEMPRE su `generation_prompt`, aunque el asset ya exista de una parte anterior (el pipeline lo exige; `mode` no existe para ingredients). Para reutilizar un prop, copia el bloque completo con el mismo `output_file`.

**CUPO DE REFERENCIAS (nuevo, duro):** Grok acepta MAXIMO 3 imagenes de referencia por generacion. Cada escena suma: personajes referenciados + escenario view + ingredientes. Nunca pases de 3.

- 1 personaje + escenario + 1 prop = 3. OK.
- 2 personajes + escenario = 3. OK, pero YA NO cabe prop.
- 2 personajes + escenario + prop = 4. PROHIBIDO: quita el prop o metelo descrito en el texto del prompt.

---

## 4. Escenas

Todas las escenas son animadas. Usa `render_mode:"animated"` o omite el campo; nunca uses `static` ni `narrative_card`.

```json
{
  "id": "scene_01",
  "render_mode": "animated",
  "references": {
    "characters": [{ "id": "soo_yeon", "pose": "base" }],
    "escenario": { "id": "gran_salon", "view": "base" },
    "ingredients": [],
    "scenes": []
  },
  "visual": {
    "image_prompt": "...",
    "animation_prompt": "..."
  },
  "voiceover": { "text": "[low, cold, tense] Esa noche, todos descubrieron mi apellido.", "speaker": "narrador" },
  "captions": { "text": "MI APELLIDO", "highlight_words": ["apellido"] }
}
```

Reglas:

- Cada escena necesita al menos una referencia valida: personaje pose, escenario view o ingrediente.
- Si aparece una persona recurrente, debe estar en `references.characters`.
- Si se menciona una multitud, invitados, empleados o periodistas, deben aparecer visualmente como extras anonimos coreanos desenfocados.
- `references.scenes` casi siempre queda `[]`; evita clonar composiciones previas.
- Insert shots (manos, documento, telefono, prop) NO llevan personaje de cuerpo entero: referencian el ingrediente o la view close correspondiente.
- Escenas con DOS personajes: declara quien esta a cada lado y hacia donde mira cada uno ("A on frame-left facing frame-right, B on frame-right facing frame-left"). Manten los eyelines consistentes entre plano y contraplano (regla de 180 grados: la camara siempre del mismo lado del eje).

---

## 5. Guion

### FILTRO UNIVERSAL DE VIRALIDAD (antes de escribir escenas o prompts)

La viralidad no sale del giro: sale de una DEUDA EMOCIONAL que el espectador necesita ver pagada. Esa deuda puede ser injusticia, identidad, deseo prohibido, abandono, culpa, proteccion, misterio de lugar, amor bajo mentira, ascenso/supervivencia o traicion intima. Valida la IDEA con estos puntos ANTES de escribir el JSON. Si falla 2 o mas, reescribe la idea completa, no la maquilles.

1. **HOOK SIN EXPLICACION.** La escena 1 muestra una perdida ejecutada, una amenaza irreversible, una contradiccion intima, una revelacion de identidad o una senal imposible. Prohibido abrir con tramite, geografia, presentacion neutral o mas de UN nombre propio.
2. **PROMESA DE PAGO EMOCIONAL (esc 2-3), segun el motor** (§5 Selector): injusticia = una persona de poder; romance = un gesto intimo que contradice el contrato; misterio = el lugar/objeto reconoce a la protagonista; abandono = aparece senal de que el abandono fue mentira; culpa = alguien afectado reabre la herida; proteccion = alguien vulnerable queda en peligro inmediato; traicion intima = la persona cercana actua de forma sospechosa.
3. **DANO O CONSECUENCIA ANTES DE EXPLICAR.** La deuda del hook se EJECUTA o deja consecuencia visible antes de la escena 6.
4. **UNA PREGUNTA DOMINANTE.** El espectador debe poder decir UNA sola pregunta: "¿quien es ella?", "¿que perdera si ama?", "¿por que la esperaban?", "¿a quien protege?", "¿quien la traiciono?". Nunca "¿que esta pasando?".
5. **ESCALERA DE CONSECUENCIAS.** 3-6 consecuencias EJECUTADAS (no mencionadas) segun el motor; NO todas son despojos materiales: injusticia = cuarto vacio, silla quitada, tarjeta bloqueada; romance = contrato firmado, cama compartida, foto filtrada, beso negado; misterio de lugar = puerta prohibida, expediente borrado, testigo desaparecido; abandono/madre = llamada cortada, carta quemada, medicina retenida; culpa/redencion = funeral, rechazo publico, prueba rota, perdon negado.
6. **VULNERABILIDAD ANTES DE PODER.** Antes de que la heroina suene iconica, el publico la ve perder, dudar, proteger, desear o temer. En el primer tercio: max 1 frase de dignidad por cada 3 consecuencias.
7. **OBJETO ANCLA.** Un objeto emocional (collar, medallon, recibo, silla, sobre, foto, llave, contrato, expediente) aparece antes del segundo tercio y VUELVE en el pago, reversal o cliffhanger.
8. **ANTI-ABSTRACCION.** Todo concepto abstracto se traduce rapido en imagen material (cama, puerta, llamada, silla, carta, contrato, foto, medallon, expediente, uniforme, anillo). Prohibido 2 frases liricas seguidas; el climax es lo MAS material.
9. **PAGO ANTES DEL CLIFFHANGER.** Cada parte PAGA una promesa Y abre una pregunta mas peligrosa; nunca solo abre.
10. **MOTOR CONSISTENTE.** Todas las promesas, consecuencias, densidad D y reversals siguen las reglas del motor elegido (§5 Selector). NO apliques la escalera de despojos de injusticia a motores de romance, misterio, abandono o culpa.

**RECHAZA Y REESCRIBE el JSON si:** la escena 1 tiene mas de un nombre propio o abre con tramite/presentacion; el hook revela el mismo giro que el cliffhanger; la deuda del hook no se ejecuta antes de la escena 6; la heroina da 2 frases de superioridad antes de sufrir 3 consecuencias; el reversal lo entrega un documento en vez de una persona con poder visible; hay 4+ preguntas grandes abiertas o la parte solo abre sin pagar; o el espectador no puede responder EN 8 SEGUNDOS: quien soy, quien me ataca con que deuda concreta, y que pago viene.

### Plantilla universal de Parte 1 (cualquier motor)

| Tiempo aprox | Funcion | Que debe pasar |
|---|---|---|
| 0-3 s | Golpe | Deuda emocional EJECUTADA: perdida, amenaza irreversible, contradiccion intima, senal imposible o decision moral |
| 3-8 s | Promesa | Pago emocional del MOTOR elegido (§5 Selector) |
| 8-20 s | Tablero | Quien narra, quien/que la presiona y que se juega |
| 20-45 s | Consecuencias 1-3 | Tres consecuencias ejecutadas SEGUN el motor (no siempre despojos) |
| 45-70 s | Escalada | Obstaculo fresco: dano publico, intimidad peligrosa, regla secreta o decision moral |
| 70-90 s | Objeto/prueba | Objeto ancla o prueba que cambia el significado |
| 90-115 s | Pago parcial | Reversal por PERSONA: alguien protege, acusa, reconoce, traiciona o salva |
| 115-135 s | Cliffhanger | Pregunta mas peligrosa, de tipo rotado |

### Plantilla Parte 1 — SOLO motor INJUSTICIA / makjang familiar

Los despojos materiales en escalada son especificos de la injusticia; NO los apliques a romance, misterio, survival, etc.

| Tiempo aprox | Funcion | Que debe pasar |
|---|---|---|
| 0-3 s | Golpe | Perdida ejecutada o amenaza irreversible |
| 3-8 s | Promesa | Una fuerza enorme (persona de poder) viene a invertir el poder |
| 8-20 s | Tablero | Nombre de la narradora, relacion con la villana, que se juega |
| 20-45 s | Despojos 1-3 | Cuarto, dinero, apellido, objeto, mesa |
| 45-70 s | Despojos 4-5 | Humillacion publica o expulsion |
| 70-90 s | Objeto/pista | Collar, medallon, recibo, sobre, foto |
| 90-115 s | Reversal parcial | Entra poder externo; alguien baja la mirada |
| 115-135 s | Cliffhanger | Identidad o estatus cambia en una frase |

### Semaforo pre-JSON (evaluate antes de generar)

- **VERDE (genera):** hook claro en 3 s; UNA pregunta dominante; motor elegido; consecuencia ejecutada antes de la escena 6; pago parcial antes del cliffhanger; maximo 3 loops abiertos.
- **AMARILLO (revisa):** hook fuerte pero con demasiada explicacion; dos preguntas dominantes compiten; el pago existe pero llega tarde; el objeto ancla aparece pero no vuelve.
- **ROJO (reescribe beats antes del JSON):** hook administrativo; el giro esta spoileado; no hay consecuencia ejecutada; la parte solo prepara; el cliffhanger sustituye al pago; mas de 3 preguntas abiertas; la protagonista suena invencible antes de que importe.

### Contrato de la parte (defínelo en una linea cada uno, antes de escribir escenas)

MOTOR PRINCIPAL / MOTOR SECUNDARIO / MUNDO (SKIN) / PREGUNTA DOMINANTE / DEUDA QUE SE ABRE / CONSECUENCIA EJECUTADA ANTES DE LA ESCENA 6 / OBJETO ANCLA / PAGO PARCIAL / CLIFFHANGER / TIPO DE CLIFFHANGER / REGLA VISUAL DEL MUNDO / LIMITE DEL MUNDO (que NO puede aparecer) / PREGUNTA QUE QUEDA ABIERTA / QUE CAMBIA EN EL MAPA DE PODER. Este bloque evita escribir por intuicion.

### Base (igual que siempre)

- Idioma hablado: espanol. Prompts visuales: ingles.
- Voz narrativa: primera persona desde la protagonista, frases cortas, emocion contenida, tension creciente.
- Una sola voz femenina narra TODO, incluidos dialogos masculinos.
- Escena N: narracion, boca cerrada. Escena D: dialogo narrado EN ESTILO DIRECTO (cita textual); solo quien habla mueve la boca.
- Longitud por escena: 3-16 palabras, promedio 9-11. VARIANZA obligatoria: al menos 1 golpe de 5 palabras o menos por cada 5 escenas ("Primero, mi habitacion."), colocado tras una frase larga. Una banda uniforme (todas de 8-11) aplana la prosodia del TTS y suena a metronomo.
- Estructura: gancho -> humillacion/injusticia -> pista/revelacion -> decision -> giro -> cliffhanger.

### Ortografia para Fish (nueva, obligatoria)

- `voiceover.text` y `captions.text` van SIEMPRE con ortografia espanola completa: tildes y enie ("perdon" se pronuncia mal; escribe "perdón"; "anos" no es "años").
- Cifras, horas y cantidades se escriben con palabras: "las siete de la tarde", "tres mil millones de wones", no "7pm" ni "3,000,000,000".

### Narracion audio-first (la historia debe entenderse SOLO con el audio)

El espectador no ve los prompts ni sabe los nombres: solo oye a la narradora. Estas reglas existen porque el oido no rebobina.

- **Conflicto primero, identidad despues.** La escena 1 detona (formula de gancho); las escenas 2-4 dejan dicho, dramatizado, el tablero minimo: quien narra (su nombre se PRONUNCIA al menos una vez), quien murio o que se perdio, y que se juega. Ej: `"—Todo el imperio pasa a Ha-yoon, la viuda."` -> `"Ha-yoon soy yo: la nuera sin una gota de su sangre."`
- **Maximo 4 nombres propios HABLADOS por parte.** La memoria de trabajo del oyente tolera 3-4 elementos nuevos; cada nombre extra borra uno anterior. El resto de personajes se nombra por su ROL: "mi suegra", "el abogado", "su esposa". En pantalla pueden aparecer mas personajes; en el AUDIO no.
- **Primera mencion = nombre + relacion (+ rasgo si cabe):** `"Tae-sung, el hermano de mi esposo, se levanto."` Nunca sueltes un nombre sin decir quien es, y nunca metas 2 nombres nuevos en la misma frase.
- **Un solo apodo por persona en TODA la serie.** Si el muerto es "el patriarca", es "el patriarca" siempre (atalo a la relacion una sola vez: "el patriarca, mi suegro"). Alternar patriarca/presidente/senor Jang hace creer al oyente que son personas distintas.
- **Dialogos en estilo DIRECTO con atribucion garantizada.** Dos formas validas: (a) tag antes de la cita (`"Tae-sung escupio: —¿Una viuda ajena dirigiendo nuestra naviera?"`), o (b) la linea A PELO, sin tag, cuando la escena N anterior ya planto al hablante y el visual muestra su boca (`"Entonces conoci a Han Na-ri..."` -> siguiente escena D: `"No quiero quitarte nada."`). La linea a pelo pega mas fuerte: usala en los picos (crueldades y replicas). PROHIBIDO el estilo indirecto ("dijo que...", "pregunto si...") y la linea a pelo sin setup previo. Tras la cita, la narradora vuelve a su "yo".
- **Sin pronombres ambiguos.** Con dos personajes del mismo genero en la secuencia, repite el nombre o el rol; "el"/"ella" solo con antecedente inconfundible. En audio repetir el nombre no es feo: es la unica ancla.
- **Flashbacks anclados al entrar Y al salir,** al INICIO de la frase: `"Tres dias antes de morir, el patriarca..."` y para volver `"De vuelta en la junta, ..."`. Sin ancla, el espectador cree que el muerto revivio.
- **Repeticion estrategica:** el dato que sostiene la parte (el plazo, la cifra, el arma) se dice 2 veces con palabras distintas; el oyente distraido entra a mitad de video.
- **Una idea por frase,** sujeto-verbo-objeto. Las frases de pura atmosfera ("la sala se inclino, o quiza fui yo") se permiten 1 de cada 5 escenas, nunca en racha.
- **PRUEBA DEL CIEGO (obligatoria antes de entregar):** lee SOLO los `voiceover.text` en orden, sin mirar prompts ni referencias. En 8 segundos debes poder responder EN VOZ ALTA, con este formato obligatorio: "Yo soy [nombre/rol], me atacan [antagonista/rol] quitandome/negandome [deuda concreta visible], el pago que viene es [promesa/persona]". Si no puedes completar la frase, reescribe la voz, no las imagenes. Aplicala por PARTE **y por TEMPORADA** (que el arco completo tambien se siga de oido).

### Motor de deuda emocional universal (el corazon del genero)

Toda parte viral ABRE una deuda emocional y PAGA una parte antes del cliffhanger. La injusticia es UN motor de diez; el tipo de promesa, la escalera de consecuencias, la densidad de dialogo y el reversal cambian segun el motor. Elige UN motor principal (y opcional secundario) ANTES de escribir.

Los 10 tipos de deuda (motor -> pregunta que retiene):
1. INJUSTICIA: le quitaron algo que no debian. "¿Como van a pagar por esto?"
2. IDENTIDAD: no sabe quien es, o el mundo la llama por un nombre falso. "¿Quien es ella realmente?"
3. DESEO PROHIBIDO: quiere a alguien/algo que destruiria su posicion. "¿Que perdera si cruza la linea?"
4. ABANDONO: quien debia protegerla desaparecio, mintio o la entrego. "¿La abandonaron o la salvaron?"
5. CULPA/REDENCION: carga una culpa que quiza no es suya, o hizo algo imperdonable por amor. "¿Merece perdon o castigo?"
6. PROTECCION: debe salvar a alguien vulnerable sin revelar su secreto. "¿A quien sacrifica para protegerlo?"
7. MISTERIO DE LUGAR: un colegio/hospital/empresa/mansion/pueblo sabe algo de ella. "¿Por que ese lugar la esperaba?"
8. AMOR BAJO MENTIRA: una relacion falsa empieza a producir sentimientos reales. "¿Que pasa cuando la mentira se vuelve verdad?"
9. ASCENSO/SUPERVIVENCIA: entra a un mundo de elite que quiere destruirla. "¿Que precio pagara por quedarse?"
10. TRAICION INTIMA: la persona mas cercana la vendio, oculto o manipulo. "¿Cuando descubrira la verdad?"

**Regla dura: no todo drama necesita despojos materiales, pero TODO necesita CONSECUENCIAS EJECUTADAS** (visibles, no amenazas). El motor decide cuales:
- Injusticia: cuarto vacio, silla quitada, tarjeta bloqueada, apellido borrado, seguridad arrastrandola.
- Romance/contrato: contrato firmado, cama compartida, foto filtrada, beso negado.
- Misterio/lugar: puerta cerrada, medallon activado, expediente borrado, testigo desaparecido.
- Abandono/madre: llamada cortada, carta quemada, nina escondida, medicina retenida.
- Falso culpable: video manipulado, testigo comprado, uniforme manchado, esposas publicas.
- Internado/elite: senal perdida, regla prohibida, campana, alumno que sabe su nombre.

**La PROMESA (escenas 2-3) es un pago EMOCIONAL y su forma cambia por motor:**
- Injusticia/ascenso/CEO: una PERSONA fisica de poder ("el hombre ante quien mi padre se inclinaba", "la mujer que la familia temia"). Prohibido "un abogado" abstracto.
- Romance/contrato: una contradiccion intima ("Tres dias despues, el esposo que me odiaba durmio frente a mi puerta.").
- Misterio/lugar: el lugar u objeto reacciona ("Esa noche, el retrato de mi madre aparecio en el salon prohibido.").
- Abandono/madre: una senal de que el abandono fue mentira ("Una semana despues, una nina desconocida llamo a mi madre por mi nombre.").
- Falso culpable: el testigo se mueve ("Al amanecer, el unico testigo que me condeno pidio verme.").

**El PAGO/REVERSAL lo entrega una PERSONA** (una entrada, una mirada, una frase), NO un documento leido en solitario (el documento puede existir, pero quien lo REVELA es una persona con presencia). Cada parte PAGA una promesa Y abre una pregunta mas peligrosa; nunca solo abre.

### Sistema de dos ejes: MOTOR + MUNDO

Antes de cualquier biblia, arco, beats o JSON, elige DOS cosas:

1. **MOTOR EMOCIONAL** (que deuda retiene): injusticia, identidad, deseo prohibido, abandono, culpa, proteccion, misterio de lugar, amor bajo mentira, ascenso/supervivencia, traicion intima, regresion, crime noir, survival, mistico. Decide la DEUDA, el PAGO y la PREGUNTA DOMINANTE.
2. **MUNDO / SKIN** (donde ocurre y con que lenguaje visual): moderno, chaebol, makjang extremo, internado oscuro, sageuk Joseon, C-drama de palacio, crime noir, survival game, mythic fantasy, sci-fi suave. Decide VESTUARIO, ESCENARIOS, NEGATIVOS, PROPS, LUZ y el LIMITE de accion/fantasia.

Regla: el motor y el mundo son independientes (una injusticia puede ocurrir en Joseon; una regresion en un chaebol). NUNCA mezcles mundos sin declararlo. El mundo elegido fija que pack de negativos/ancla de §6 se usa.

### Selector de motor (elige uno antes de escribir)

| Motor | Densidad D | Pago obligatorio | Promesa / reversal especifico |
|---|---|---|---|
| A. Heredera / hija falsa / viuda (INJUSTICIA) | 40-50% | Alguien con poder invierte la jerarquia | promesa = persona de poder visible; reversal por persona (nunca solo documento) |
| B. Matrimonio por contrato (DESEO PROHIBIDO) | 35-45% | Un gesto intimo contradice el contrato | promesa = gesto intimo que contradice el contrato; reversal = contradiccion emocional publica |
| C. Internado / legado / mansion (MISTERIO DE LUGAR) | 25-40% | El lugar reconoce a la protagonista antes que ella | promesa = el lugar/objeto reacciona; reversal = el lugar la reconoce antes que ella |
| D. Madre desaparecida / hija perdida (ABANDONO) | 30-45% | Prueba de que el abandono fue mentira/sacrificio | promesa = senal de que el abandono fue mentira; reversal = prueba de sacrificio |
| E. Falso culpable / juicio (VERDAD ENTERRADA) | 30-40% | Prueba que libera en parte pero acusa a alguien cercano | promesa = el testigo se mueve; reversal = la prueba acusa a alguien mas intimo |
| F. CEO / secretaria / amor de poder (VULNERABILIDAD) | 35-45% | El poderoso se quiebra o protege en publico | promesa = el poderoso tiembla al verla; reversal = rompe su regla por ella |
| G. Hospital / vida o muerte (RELOJ BIOLOGICO) | 25-40% | Se salva una vida pero se revela una deuda mayor | promesa = un reloj biologico corre; reversal = se salva la vida, aparece una deuda mayor |
| H. Elite cerrada / club social (EXCLUSION) | 35-50% | La excluida descubre una regla oculta del sistema | promesa = una regla secreta se insinua; reversal = descubre el codigo interno |
| I. Identidad robada / nombre falso (IDENTIDAD) | 30-45% | Alguien la reconoce por una prueba que no se falsifica | promesa = una prueba imposible de falsificar; reversal = alguien la reconoce por ella. Consecuencias: expediente inexistente, foto alterada, nombre borrado, registro cambiado, objeto que solo responde a ella |
| J. Proteccion secreta (PROTECCION) | 25-40% | Salva a alguien vulnerable pero empeora su posicion | promesa = el vulnerable queda en peligro inmediato; reversal = lo salva a costa suya. Consecuencias: medicina retenida, nino escondido, mentira necesaria, sacrificio publico, aliado que sospecha |
| K. Culpa / redencion (CULPA) | 30-45% | Un afectado concede o niega perdon en publico | promesa = un afectado reabre la herida; reversal = perdon concedido o negado en publico. Consecuencias: funeral, rechazo, prueba rota, disculpa rechazada, recuerdo que cambia de sentido |
| L. Traicion intima (TRAICION) | 35-50% | La traicion se demuestra por una accion presente | promesa = la persona cercana actua sospechoso; reversal = la traicion se prueba con una accion, no con explicacion. Consecuencias: llamada grabada, regalo usado como prueba, carta escondida, contrasena compartida, testigo comprado |
| M. Mistico / legado sobrenatural (DESTINO) | 25-40% | El poder u objeto se manifiesta y la marca | promesa = el objeto/lugar reacciona a ella; reversal = el poder se manifiesta una vez y la marca como elegida |
| N. Regresion / segunda oportunidad (DESTINO CORREGIDO) | 30-45% | Cambia un evento del pasado, pero el futuro cobra otro precio | promesa = reconoce un evento futuro y decide cambiarlo; reversal = la desgracia se transfiere al traidor. Requiere LEDGER TEMPORAL (linea original/actual/eventos cambiados/pendientes); cliffhanger tipico: alguien mas recuerda la vida anterior. Hook: "Mori en la boda de mi traidora. Desperte diez anos antes." |
| O. Crime noir / mafia romance (DEUDA DE SANGRE) | 30-45% | El criminal rompe una regla para protegerla | promesa = el que debia matarla la esconde; reversal = la orden de matarla salio de su propia familia. Violencia FUERA de cuadro. Hook: "El hombre que debia matarme me escondio en su casa." |
| P. Survival game / juego moral (SUPERVIVENCIA MORAL) | 25-40% | Gana una prueba salvando a alguien, pero condena a otro | promesa = una regla revela que alguien cercano ya conocia el sistema; reversal = el organizador conoce su nombre real. Tension por DECISION, no por sangre. Hook: "Perdi el primer juego antes de saber que jugabamos con vidas." |
| Q. Transmigracion / villana en novela (DESTINO ESCRITO) | 30-45% | Evita una muerte escrita, pero el guion castiga a otra persona | promesa = reconoce una escena del libro y decide romperla; reversal = un personaje actua FUERA del guion. Requiere LEDGER (capitulo original/escena modificada/destino escrito/personajes fuera del guion); cliffhanger: alguien mas sabe que este mundo es una novela. NO es regresion (no vuelve a su pasado: entra a un guion que cree conocer). Mundos: C-drama, sageuk, mythic, moderno, chaebol. Hook: "Desperte como la villana que moria en el capitulo tres." |
| R. Romance tabu adulto / mentor (DESEO PROHIBIDO + REPUTACION) | 35-45% | El mentor arriesga su puesto por una verdad, SIN cruzar una linea sexual explicita | promesa = el que arruino su nombre es el unico que puede salvarlo; reversal = la denuncia la escribio alguien inesperado. **SEGURIDAD OBLIGATORIA:** todos los personajes romanticos tienen 21+ anos; PROHIBIDO secundaria/menores, grooming, coercion sexual, dependencia vulnerable o contenido sexual explicito. La tension viene de reputacion, beca, carrera, comite, secreto y poder social. Mundos: universidad/posgrado/academia adulta/empresa/hospital/bufete. Hook: "El profesor que arruino mi beca era el unico que podia salvar mi nombre." |

La densidad D es orientativa: makjang familiar y confrontacion piden mas dialogo; misterio, thriller emocional y madre perdida piden mas escenas N de descubrimiento (objetos, puertas, miradas, llamadas, espacios). NO apliques 40-50% a todos los motores.

**Nota de contrato:** el pipeline IGNORA campos desconocidos en `project` (validado: no hay chequeo estricto de claves), asi que `project.motor`, `project.world`, `project.allow_supernatural` y `project.allow_historical` son SEGUROS como metadata. Registra ademas el motor y el mundo en el MAPA DE TEMPORADA y en el ESTADO DE HISTORIA: son la fuente de verdad narrativa aunque el JSON no los lleve.

### Selector de mundo / skin (elige uno; define lo VISUAL, no la deuda)

El MUNDO decide vestuario, escenarios, props, luz, negativos y el limite de accion/fantasia. Mundos A-D usan el ancla y los negativos DEFAULT (o el pack MISTICO si `allow_supernatural`); E-J usan su pack propio de §6.

- **A. Moderno k-drama realista** — chaebol, familia, hospital, empresa, romance moderno. Pack default.
- **B. Makjang extremo** — secretos de nacimiento, impostoras, resurrecciones, gemelas, matrimonio por venganza. **LICENCIA MAKJANG:** el giro puede ser absurdo (resurreccion, bebe cambiado, memoria perdida), pero la EMOCION debe ser clarisima: siempre se sabe a quien le dolio, quien lo hizo y que deuda se abrio. Absurdo permitido, confusion prohibida; cider moment (satisfaccion) dentro de cada parte.
- **C. Chaebol / corporativo** — herencia, juntas, sucesion. La junta NO retiene por la junta: retiene porque una silla, una firma, una tarjeta, una escolta o una puerta cambia de dueno. Cada concepto legal se materializa.
- **D. Internado / mansion gotica** — legado, colegio secreto, lugar que reconoce a la protagonista. Misterio visible; fantasia solo si `allow_supernatural` (pack mistico §6).
- **E. Sageuk Joseon** (`allow_historical`) — palacio coreano, nobleza, sirvientes, identidad falsa, matrimonio politico, linaje oculto. Pack sageuk §6 (hanbok permitido).
- **F. C-drama costume** (`allow_historical`) — palacio imperial, concubinas, clanes, venganza de corte. Pack C-drama §6 (hanfu permitido).
- **G. Crime noir / mafia romance** — mafia, crimen organizado, romance bajo amenaza. Violencia FUERA de cuadro, aftermath emocional, cero gore. Pack noir §6.
- **H. Survival game** — pruebas, reglas, eliminacion, premio, traicion. Sin gore grafico; la tension viene de la DECISION moral, no de la sangre. Pack survival §6.
- **I. Mythic fantasy / Olimpo** (`allow_supernatural`) — dioses, linaje divino, profecias. Fantasia AL SERVICIO del melodrama (herencia divina, hija repudiada, juramento roto), no espectaculo vacio. Pack mythic §6 (fantasia VISIBLE, distinta del mistico sutil).
- **J. Sci-fi suave** — memoria implantada, clon familiar, identidad sintetica, corporacion futurista. Sci-fi emocional, no hard sci-fi. Pack sci-fi §6.

**Cascada de identidad** (motores identidad/regresion y mundo makjang): cada parte tira UNA sola mascara, nunca tres (P1: ella no es quien cree; P2: la madre no la abandono; P3: el protector sabia su nombre). Evita que el drama se vuelva "explicacion de arbol genealogico".

### Una parte = UNA pregunta dominante

Cada parte tiene UNA brujula emocional. La audiencia tolera muchos detalles, pero solo una pregunta que la arrastre. Correcto: P1 "¿Quien es ella realmente?" / P2 "¿Por que el abuelo la oculto?" / P3 "¿Quien cambio la prueba de sangre?". Incorrecto: abrir a la vez "¿quien es?, ¿quien es Na-ri?, ¿que dice el testamento?, ¿quien mato al heredero?, ¿por que miente el abogado?, ¿que significa el collar?". Maximo 3 preguntas grandes abiertas en toda la serie a la vez (ver ESTADO DE HISTORIA); antes de abrir una cuarta, paga una.

### Subtipo INJUSTICIA (reglas estrictas del makjang familiar)

Cuando el motor es INJUSTICIA es INJUSTICIA VISCERAL ACUMULADA + REVERSAL, y aplican reglas mas estrictas. Una parte que solo "prepara el tablero" se siente vacia aunque se entienda perfecto. Calibrado con el exito real del canal (heredera_oculta).

Reglas estrictas del subtipo injusticia (Parte 1):
- Hook: prohibido mencionar "falsa/verdadera/impostora/sangre/clausula" en las primeras 6 escenas; solo estatus aparente ("la hija que todos llamaban legitima").
- Promesa (esc 2-3): SIEMPRE una persona fisica de poder visible; prohibido abogado, documento, clausula o "autoridad" abstracta como promesa.
- Victima primero: en el primer tercio, max 1 frase de dignidad por cada 3 humillaciones EJECUTADAS. Si la heroina se planta antes de la primera perdida publica, reescribe.
- Reversal: entregado por una PERSONA con poder (entrada, mirada, frase), nunca por lectura de documento en solitario.
- Papeleo casi cero: max 1 termino legal en toda la Parte 1 antes de la primera humillacion publica; el resto se traduce en perdida material (cama, silla, tarjeta bloqueada, vestido manchado).

Si en la PRUEBA DEL CIEGO el oyente no puede decir en voz alta "me quitaron X concreto y quiero que Y pague", reescribe.

- **4-6 despojos CONSUMADOS en pantalla**, en escalada: domestico -> identidad -> economico -> publico ("mi cuarto" -> "mi ropa y mi lugar en la mesa" -> "el apellido" -> "las tarjetas" -> "seguridad me saco"). Las amenazas condicionales ("o perderia todo", "quedaria fuera") NO cuentan: duele lo que se EJECUTA, no lo que podria pasar.
- **El antagonista EJECUTA maldades** (vacia el cuarto, derrama el vino y la culpa, llama a seguridad): minimo 2-3 acciones visibles por parte, no solo frases crueles.
- **PROMESA temprana:** en las escenas 2-3, un flashforward que promete el pago: "Una semana despues, el hombre mas poderoso del pais llego preguntando por mi." Esa promesa sostiene toda la escalada de humillacion.
- **PAGO dentro de la parte:** reversal o victoria parcial en el ultimo 15-20%, ANTES del cliffhanger (el poder cambia de manos, alguien paga, la heroina se planta). El cliffhanger invierte ESTATUS o IDENTIDAD ("¿Quien se atrevio a tocar a mi nieta?"); nunca es SOLO una pista que haya que deducir. El misterio/reloj es motor secundario que corre DEBAJO de la injusticia, no en su lugar.
- **INTERIORIDAD declarada:** la narradora dice lo que SIENTE en los golpes ("Aquella frase dolio mas que la prueba.", "Todos esperaban verme suplicar."). Minimo 1 beat de emocion declarada cada 4-5 escenas; un guion que solo reporta hechos deja al espectador sin sentir la historia.
- **VICTIMA antes de ICONICA:** en el primer tercio, maximo 1 replica de dignidad por cada 3 humillaciones ejecutadas. Si la heroina suena invencible desde el segundo 5 ("aprendi a temblar sin arrodillarme" en la escena 3), el espectador no siente que deba defenderla. Primero herida, despues la dignidad.
- **OBJETO ANCLA:** un objeto emocional (collar, recibo del hospital, sobre, silla, foto) aparece antes del segundo tercio y VUELVE en el reversal o el cliffhanger.
- **Lo abstracto se paga en concreto:** toda totalidad ("me lo quitaron todo") se convierte en inventario material en 2 escenas o menos ("mi ropa, mis joyas y mi lugar en la mesa", "un cuarto que costaba menos que uno de mis vestidos"). Prohibido encadenar 2 frases liricas; el climax es el momento MAS material del guion.
- **El titulo ES la promesa del trope** en 8 palabras o menos ("La hija falsa expulso a la verdadera heredera"), no un titulo poetico ("La Clausula del Hielo" no comunica genero ni injusticia).

### El gancho (0-3 segundos deciden todo)

La escena 1 detona, no presenta. Prohibido abrir con paisaje, geografia o presentacion del personaje. Formulas probadas (elige una):

1. **Ultimatum / linea cargada:** "Firma el divorcio antes de medianoche, o tu madre no sale del hospital."
2. **Humillacion publica en su pico:** la copa ya esta derramada, la bofetada ya cayo; el gancho es la reaccion.
3. **Mensaje/documento que estalla:** el close del papel o la pantalla con la frase asesina.
4. **Reaccion primero:** primer plano de la protagonista rota + la frase que lo explica ("Esa noche, todos descubrieron mi apellido.").

Reglas duras del gancho (ver FILTRO al inicio de §5): UN solo nombre propio en la escena 1; NO uses todavia la etiqueta del giro ("falsa", "impostora") sobre quien el cliffhanger va a desenmascarar; y la promesa de las escenas 2-3 debe ser MITICA (una fuerza de poder que viene a invertir el mundo), nunca "un abogado pregunto por mi".

En partes 2 en adelante: la primera escena RE-DRAMATIZA lo que esta en juego en 3 segundos (mostrando, no contando). PROHIBIDO el recap narrado ("En la parte anterior..."). Asume espectador nuevo o distraido.

### Motor de la serie

- Deseo simple de la protagonista + obstaculo FRESCO por parte + reloj corriendo (fecha limite concreta: boda, juicio, junta, desalojo). El reloj se menciona al menos una vez por parte.
- Maximo 2-3 personajes centrales en pantalla por parte. Demasiados nombres juntos matan la comprension en audio.
- Los personajes ACTUAN sus sentimientos, no los explican. Cero exposicion conversada: cada linea avanza el conflicto O revela caracter bajo presion.

### Regla anti-valle (nueva)

- Nunca mas de 4 escenas seguidas (~15-20 s) sin nueva informacion, nueva amenaza o nueva pregunta abierta. Si un tramo solo describe o explica, corta o fusiona.
- Un (1) giro grande por parte, bien colocado (mejor un beat fuerte que tres tibios) + microgiros pequenos cada 6-8 escenas.
- Los "respiros" emocionales existen pero duran 1-2 escenas, nunca un bloque.

### Cliffhanger (taxonomia + rotacion)

Escribe la parte HACIA ATRAS: decide primero los ultimos 3 segundos (la imagen + la frase final) y construye hacia ellos. Tipos (ROTA entre partes, nunca repitas el de la parte anterior):

1. **Revelacion:** "El bebé no es tuyo." / la foto que no debia existir.
2. **Reversal:** la aliada saca los papeles firmados; el debil resulta fuerte.
3. **Deadline:** el reloj llega a cero en pantalla; suena el telefono de la boda.
4. **Intrusion:** alguien entra, se va la luz, la puerta se abre a mitad de la frase.

El cliffhanger NO resuelve el misterio, corta EN el pico (corte-antes-del-beso, corte-antes-de-la-bofetada). La ironia dramatica (el espectador sabe mas que la protagonista) sostiene partes enteras.

**Regla dura (v4):** cada parte PAGA una promesa Y abre una pregunta mas peligrosa; nunca SOLO abre. El reversal/revelacion lo entrega una PERSONA (una entrada, una mirada, una frase asesina), nunca un documento leido en solitario. El cliffhanger por si solo no salva una parte floja: sin pago previo, el espectador se cansa. Y nunca abras un cuarto loop grande sin pagar uno (ver ESTADO DE HISTORIA).

### Tropes

Billonario/CEO, venganza, identidad secreta, matrimonio por contrato, secreto de nacimiento y drama familiar SIGUEN siendo los que mas convierten aunque esten "quemados": tomas prestada la confianza del contrato emocional conocido. La diferenciacion esta en la ejecucion, no en evitar el trope. Refresco valido: dilema moral encima del contrato, villano con culpa y conciencia (no maltrato plano), giros apilados espalda-con-espalda estilo makjang.

Tono prohibido (por defecto): comedia exagerada, accion fisica absurda, explicaciones legales largas, demasiados nombres juntos. La fantasia/lo sobrenatural NO esta prohibido en v4: es OPT-IN por serie y CONTENIDO (§0 y §6).

### MAPA DE TEMPORADA (obligatorio antes de la Parte 1)

Antes de generar la Parte 1, crea una tabla de TODA la temporada. Cada parte lleva: hook autonomo, pregunta dominante, objetivo visible de la protagonista, obstaculo fresco, consecuencia ejecutada, objeto/prueba que aparece, pago parcial antes del cliffhanger, cliffhanger exacto + tipo, pregunta que queda abierta, que sabe el espectador que la protagonista no, que sabe el villano que el espectador no, assets nuevos probables.

Ejemplo (arco de identidad, 8 partes):

| Parte | Funcion | Pago | Cliffhanger |
|---|---|---|---|
| 1 | Herida inicial + promesa | Recupera una senal de estatus | "Tu nombre real no es ese." |
| 2 | Consecuencia del giro | El protector muestra poder pero exige silencio | La villana muestra una foto de la madre |
| 3 | Contraataque | Gana una prueba publica | El aliado vendio la prueba |
| 4 | Intimidad / falsa calma | Una relacion se vuelve peligrosa | El enemigo conoce el objeto ancla |
| 5 | Midpoint | Se revela la mentira central, incompleta | La madre esta viva |
| 6 | Sacrificio | Salva a alguien y pierde proteccion | El reloj se adelanta |
| 7 | Trampa oscura | El villano parece ganar | Entra voluntariamente al lugar prohibido |
| 8 | Pago grande | Se cobra la deuda principal | Nueva deuda para la temporada 2 |

Regla de oro de series: ninguna parte existe para "preparar". Cada parte COBRA algo, PIERDE algo y ABRE algo. La Parte 4 o 5 debe cambiar el genero emocional (una heredera oculta puede volverse misterio de madre, luego romance de proteccion): el motor cambia, la promesa central sigue viva.

### Plantilla de PARTE N (nunca solo Parte 1)

La plantilla de Parte 1 (arriba en §5) es para el estreno. De la Parte 2 en adelante:

- 0-3 s **REENTRADA AUTONOMA:** sin recap; una frase que dramatiza la CONSECUENCIA del cliffhanger anterior y se entiende sin haber visto la parte previa.
- 3-10 s **NUEVO OBJETIVO:** la protagonista muestra que necesita conseguir en esta parte.
- 10-25 s **OBSTACULO FRESCO:** el antagonista cambia de tactica; prohibido repetir la humillacion de la parte anterior.
- 25-55 s **ESCALERA EMOCIONAL:** 3-5 consecuencias ejecutadas segun el motor.
- 55-75 s **MICRO-REVELACION:** un dato cambia el significado de una escena anterior.
- 75-100 s **DECISION:** elige, sacrifica, miente, firma, entra, protege o acusa.
- 100-120 s **PAGO PARCIAL:** alguien pierde poder, se descubre una verdad, se salva a alguien o una relacion cambia.
- 120-135 s **CLIFFHANGER:** una pregunta MAS peligrosa que la anterior, de tipo distinto al ultimo.

Checklist de PARTE N: [ ] la primera frase se entiende sin ver la parte anterior; [ ] la protagonista tiene un objetivo concreto en ESTA parte; [ ] el antagonista usa una tactica NUEVA; [ ] se PAGA una promesa anterior; [ ] se abre una pregunta mas peligrosa; [ ] maximo 3 loops grandes activos; [ ] el reloj de temporada se menciona o avanza; [ ] el objeto ancla aparece o se transforma; [ ] cambia el mapa de poder; [ ] la ultima escena obliga a seguir, pero NO sustituye el pago interno.

### Hooks para Parte 2 en adelante

Prohibido: "En la parte anterior...", "Despues de descubrir la verdad...", "Todo empezo cuando...". La Parte 2 no EXPLICA el cliffhanger: muestra su CONSECUENCIA. Formulas:

1. Consecuencia inmediata: "Recupere mi apellido. Esa misma noche, la policia vino por mi."
2. Falsa victoria: "La mansion volvio a abrirme la puerta, pero mi cuarto ya tenia otra dueña."
3. Nueva amenaza: "El hombre que me llamo nieta me prohibio decir mi verdadero nombre."
4. Contradiccion emocional: "El esposo que me compro por contrato fue el unico que lloro por mi."
5. Objeto ancla: "El medallon de mi madre empezo a arder frente al director."
6. Deadline: "Faltaban seis dias para la boda cuando aparecio la primera esposa."
7. Pago envenenado: "Ganamos el juicio. Entonces mi madre confeso que habia mentido."
8. Entrada de villano: "Na-ri no grito cuando perdio la herencia. Sonrio."

### Estructura de arcos (5 y 8 partes)

Arco de 5: 1 herida + promesa + primer reversal; 2 consecuencia + el enemigo contraataca; 3 midpoint (verdad parcial cambia todo); 4 sacrificio (gana algo, pierde proteccion); 5 pago grande + nueva semilla.

Arco de 8: 1 herida inicial + promesa de temporada; 2 consecuencia del cliffhanger + primer contraataque; 3 prueba falsa o aliado ambiguo; 4 intimidad / falsa calma / la relacion cambia; 5 midpoint (verdad mayor); 6 sacrificio (elige perder algo); 7 darkest point (el villano parece ganar); 8 cobro emocional grande + semilla del siguiente arco.

Regla: la Parte 4-5 CAMBIA el genero emocional; si todo sigue siendo "me humillan / me defiendo / aparece documento", la audiencia se cansa.

### ESTADO DE HISTORIA (ledger, al final de cada parte)

Al final de cada parte, ademas de ASSETS DE LA SERIE, imprime:

```
ESTADO DE HISTORIA
PODER: protagonista / antagonista / aliado / familia-empresa-escuela.
SECRETOS ACTIVOS: [secreto] — lo sabe espectador? protagonista? villano? — se paga en parte __.
PREGUNTAS ABIERTAS: A (abierta en parte __, se paga antes de parte __) / B / C.  (MAXIMO 3)
PAGOS REALIZADOS: parte 1 __, parte 2 __, ...
OBJETO ANCLA: objeto — aparecio en __ — volvio en __ — proximo uso __.
RELOJ: deadline de temporada — tiempo restante — se menciono en esta parte si/no.
CLIFFHANGERS USADOS: parte 1 __, parte 2 __, ... (no repetir tipo consecutivo)
MUNDO: skin actual / reglas visuales / cosas prohibidas / vestuario canon / nivel de fantasia-violencia permitido.
SI REGRESION: linea temporal original / linea actual / eventos cambiados / eventos que aun deben pasar / quien recuerda otra linea.
SI SURVIVAL: regla del juego / premio / castigo / alianzas / traiciones activas.
SI HISTORICO: jerarquia / nombre publico / nombre secreto / ley o costumbre que amenaza a la protagonista.
```

Regla: maximo 3 preguntas grandes abiertas a la vez; antes de abrir una cuarta, paga una anterior. Sin este ledger las historias largas se pierden.

**Si falta el ESTADO DE HISTORIA al pedir la Parte N:** no te niegues de inmediato. Reconstruye un ESTADO PROVISIONAL con lo que haya (ultimo JSON, ASSETS DE LA SERIE, voiceovers previos, mapa de temporada, cliffhanger anterior), imprimelo como "ESTADO PROVISIONAL RECONSTRUIDO" y sigue con BEATS_PARTE o JSON segun el modo pedido. Solo pide informacion si no existe NINGUN dato narrativo previo suficiente.

### Matriz de motores virales (referencia rapida)

| Motor | Hook ideal | Consecuencia ejecutada | Pago parcial | Cliffhanger |
|---|---|---|---|---|
| Injusticia familiar | "Me echaron de casa..." | cuarto vacio, apellido borrado | entra alguien con poder | "Es mi nieta." |
| Identidad secreta | "Mi nombre no existia..." | documento contradice su vida | alguien reconoce el objeto | "Tu madre no murio." |
| Internado oscuro | "El colegio sabia mi nombre..." | senal perdida, regla prohibida | el director se quiebra | "Nos encontraron." |
| Romance contrato | "Firme ser su esposa por cien dias..." | cama compartida, foto publica | el la protege sin querer | "El contrato era para salvarte." |
| Madre perdida | "Mi madre desaparecio el dia que naci..." | carta quemada, llamada cortada | prueba de sacrificio | "Ella vive aqui." |
| Falso culpable | "Confese un crimen que no cometi..." | esposas publicas, video falso | el testigo cambia version | "El verdadero culpable duerme contigo." |
| Sacrificio hospital | "Vendi mi apellido por una cirugia..." | cama perdida, medicina retenida | se salva alguien | "El donante era tu padre." |
| CEO vulnerable | "El hombre que me compro temblaba al verme..." | contrato, humillacion laboral | el rompe su regla | "Ya te conocia de nina." |
| Elite cerrada | "Entre al club donde mi madre desaparecio..." | reglas, exclusion, prueba cruel | descubre un codigo interno | "Tu madre fundo este lugar." |
| Culpa/redencion | "Todos creen que yo la mate..." | funeral, rechazo, prueba rota | alguien perdona en parte | "Ella pidio que mintieras." |
| Mistico/destino | "El internado llevaba veinte anos esperandome..." | luces que fallan, medallon que reacciona, alumno que sabe su nombre | el poder se manifiesta una vez | "Tu no viniste: te trajeron." |

---

## 6. Prompts visuales

Todos los `image_prompt` y `animation_prompt` van en ingles.

### Regla de oro de Grok (nueva)

Grok/Aurora IGNORA los prompts negativos como regla general. El bloque de negativos se mantiene como red de seguridad barata, pero NUNCA carga el peso: todo lo critico se dice en POSITIVO ("empty hands", "clear skin", "she sits BEHIND the desk"), nunca como negacion ("not on the table" no funciona). Con imagenes de referencia el modelo entra en modo EDICION y preserva la composicion de la referencia salvo instruccion explicita: el patron que funciona es **"Keep [X], change [Y]"** (p.ej. "Keep the room exactly as provided; place Soo-yeon seated behind the desk"). Lenguaje natural descriptivo > listas de keywords; evita mas de ~10 objetos distintos por prompt; lo importante va PRIMERO.

### Estructura obligatoria del image_prompt

```
"Using the provided <DisplayName> in the provided <escenario view>:
 <1 tamano de plano> + <2 posicion fisica de camara> + <3 COLOCACION del personaje>
 + <4 accion/emocion (micro-expresion + que hacen las MANOS)> + <5 luz>.
 <6 ancla de estilo>. <7 negativos cortos>. Vertical 9:16."
```

- Usa siempre **"in the provided"**. "on" SOLO si el personaje esta literalmente encima de la superficie (rooftop, cama, escenario de teatro). "on the provided desk view" = personaje encima del escritorio.

**DESCRIBIR, NO SOLO NOMBRAR (nueva, dura).** Un nombre propio no lleva informacion visual: para el modelo, "Ha-na" es un token vacio y la cara se la inventa. El `display_name` sigue siendo obligatorio (el pipeline lo usa para casar la referencia), pero SIEMPRE va acompanado de un descriptor fisico corto la PRIMERA vez que aparece en el prompt, y a partir de ahi el personaje se menciona POR DESCRIPCION, no por nombre:

- MAL: `"Using the provided Ha-na in the provided kitchen: medium shot, Ha-na wipes the counter while Ha-na's mother watches."`
- BIEN: `"Using the provided Ha-na (a Korean woman in her early thirties, long dark hair tied back, grey work apron) in the provided kitchen: medium shot, the woman in the grey apron wipes the steel counter while an older woman watches from the doorway."`

Reglas: descriptor de 4-8 palabras (edad aproximada + pelo + prenda distintiva); el mismo descriptor para el mismo personaje en TODA la serie (se anota junto a la pose en ASSETS DE LA SERIE); con dos personajes en cuadro, cada uno lleva su descriptor y se les distingue por prenda/edad, nunca por nombre; en el resto del prompt se dice "the woman in the grey apron" / "the older woman in the ivory suit". Esto vale igual para el `animation_prompt`.
- La parte descriptiva (slots 1-5) debe quedar en ~25-60 palabras. Ordena de mas a menos importante.
- Describe SIEMPRE que hacen las manos ("hands clasped on her lap", "one hand gripping the phone"): evita manos extra y poses rotas.
- "Insert shot..." como arranque alternativo = close-up de objeto/manos/documento sin rostro; es el unico caso que usa views tipo `close_escritorio`.

### Slot 3: COLOCACION (obligatoria si hay mobiliario)

Si la escena incluye mesa, escritorio, sofa, barra, cama u objeto grande, el prompt DEBE declarar la relacion fisica personaje-mueble con la formula: **verbo de postura + preposicion + oclusion (que parte del mueble queda DELANTE del cuerpo) + donde estan los pies.** Ejemplos listos:

- Sentado a la mesa: `seated at the long table, BEHIND the table edge, the tabletop in the foreground partially hiding her waist, feet on the floor under the table`
- De pie junto a: `standing beside the desk, her full body BEHIND the desk line, both feet on the marble floor`
- Apoyado: `leaning on the bar counter with both hands, body behind the counter`
- Poder tras escritorio: `seated behind the chairman desk, the desk edge in the foreground hiding her waist, tall window behind her`
- Refuerzo opcional para escenas dificiles: abre con `Keep the provided room exactly as provided; place <DisplayName> ...`

Dejar la relacion implicita ("in the office, near the desk") esta PROHIBIDO: es la otra mitad del defecto "encima de la mesa".

### Slots 1-2: tamanos de plano y posicion de camara

Tamanos (lista cerrada, declara UNO):

- `extreme wide shot, the figure tiny against the architecture, head to feet clearly visible` ← NUEVO. Soledad, poder aplastante, antes/despues de un golpe.
- `establishing wide shot, floor to ceiling visible, full body small in the lower third of the frame` (el entorno es el sujeto; asi un wide sobrevive al recorte vertical)
- `full body shot, head to feet in frame` ← **si pides este tamano, escribe SIEMPRE "head to feet in frame" y "both feet on the floor/ground"**. Sin esas dos frases Grok recorta a medio cuerpo y el plano "abierto" no existe.
- `cowboy shot, from the knees up, hands and face both readable` ← NUEVO. **Sustituye al plano medio por defecto en confrontaciones de pie.** El "waist up" corta el cuerpo justo donde peor se ve y esconde las manos.
- `medium shot, waist up` ← usar solo en escenas sentadas tras mesa/escritorio, donde la cintura ya esta ocluida por el mueble
- `medium close-up, chest up`
- `close-up` / `extreme close-up` (ojos, manos, documento; inserts)

Posicion fisica de camara (obligatoria en wides, dialogos y contraplanos; opcional en el resto). Mini-diccionario posicion -> efecto dramatico:

- `camera at the doorway` -> intrusion, personaje atrapado, alguien espia.
- `camera from the visitor side of the desk` -> el del escritorio tiene el poder; anade `slight low angle` para arrogancia.
- `camera behind his shoulder (over-the-shoulder)` -> confrontacion en dialogo.
- `camera at table level` -> intimidad de comida, conversacion de iguales.
- `camera from the far end of the hallway` -> distancia emocional, espionaje.
- `camera fixed frontal at eye level` -> confesion, confrontacion directa.
- `through the glass window with faint reflections` -> secreto, separacion.
- `high angle looking down` -> derrota, pequenez; `low angle` -> poder, amenaza.

Lentes y fotografia que Aurora respeta bien: `85mm portrait, shallow depth of field`, `35mm, deep focus`, `soft bokeh`, `window backlight`. Referencias fotograficas reales mejoran el fotorrealismo.

### COMPOSICION Y ANTI-REPETICION DE CARA (nueva)

El defecto: 40 escenas de la misma cara, centrada, de frente, con la misma expresion. Reglas:

- **Descentrar.** No todo va al centro. Alterna: `subject off-centre on the frame-left third, the empty room filling the right side` · `subject low in the bottom third, the ceiling and chandeliers filling the frame above` · `subject at the very edge of frame, most of the shot is the doorway she is about to cross`. El aire vacio comunica soledad y da variedad sin gastar escenarios.
- **Romper los tramos emocionales.** En una secuencia larga de dolor, PROHIBIDO encadenar 3 primeros planos frontales. Cada 2-3 escenas de cara, mete uno de estos en su lugar: **insert del objeto** (las manos, el papel, la taza, el dobladillo) · **silueta lejana** a contraluz · **reflejo** (espejo, vidrio de la tienda, charco, pantalla apagada) · **de espaldas** con la cara fuera de cuadro · **a traves de** una puerta/estanteria con primer plano desenfocado. Cuentan lo mismo y no cansan.
- **Si repites expresion, cambia o esconde la cara.** Si dos escenas cercanas piden la misma emocion (p. ej. dos golpes de dolor), la segunda NO se resuelve con otro primer plano frontal: se resuelve de espaldas, en perfil, en reflejo, con la cara tapada por una mano, o cortando a las manos. Regla practica: **la misma expresion no se muestra dos veces de frente en la misma Parte.**
- **Angulos, no solo posiciones.** Rota deliberadamente entre `high angle looking down` (derrota, pequenez), `low angle` (poder, amenaza), `strict profile from her left/right side`, `from behind, over her shoulder`, `top-down overhead`, `silhouette against a bright doorway, backlit, features unreadable`, `seen in the mirror / in the dark shop window / in a puddle`, `through the shelves with out-of-focus foreground objects framing her`. Minimo 3 angulos distintos por cada 10 escenas ademas del frontal.

### Distribucion de planos (por cada 10 escenas)

- Minimo 2 escenas abiertas (establishing wide o full body), **y de ellas al menos 1 realmente LEJANA** (extreme wide, desde el fondo del pasillo, desde el balcon, cenital o desde la calle). Toda locacion nueva se presenta con UN wide.
- 2-3 planos medios (el caballo de batalla del dialogo). En confrontaciones de pie usa `cowboy shot, from the knees up`, no "waist up".
- Maximo 5 cerrados (close + medium close-up), inserts incluidos. Los reaction shots en primer plano son contenido primario: guioniza la micro-expresion ("jaw tightens, eyes glisten").
- Minimo 1 over-the-shoulder o desde atras (`from behind`).
- **Minimo 1 encuadre con oclusion, reflejo o silueta** (a traves de puerta/estanteria, espejo/vidrio/charco, contraluz). ← NUEVO
- **Minimo 3 angulos distintos ademas del frontal** (picado, contrapicado, perfil izq/der, de espaldas, cenital). ← NUEVO
- **Maximo 3 primeros planos frontales de la misma cara**; el resto de las reacciones se resuelven en perfil, de espaldas, en reflejo o con insert. ← NUEVO
- Nunca 2 escenas seguidas con el mismo tamano de plano, EXCEPTO plano/contraplano de dialogo (mismo tamano permitido si cambia el lado: OTS izquierda <-> OTS derecha).
- Maximo 2 escenas seguidas con la misma view del escenario.

### Slot 5: luz de melodrama coreano

- Lujo/chaebol/mansion: `warm tungsten glow, golden practicals, amber lamplight, soft haze`.
- Hospital/oficina/frialdad corporativa: `cold blue-grey light, desaturated steel palette`.
- Contraste emocional: frio para la escena reprimida, ambar para el refugio; `window backlight` para siluetas y secretos.
- La luz de una secuencia continua NO cambia entre escenas consecutivas del mismo lugar y hora.

### Slot 6: ancla de estilo obligatoria

`cinematic Korean family melodrama, realistic East-Asian characters, elegant luxury atmosphere, emotionally restrained acting, natural skin texture, shallow depth of field, high production value, consistent facial identity, consistent wardrobe`

En wides/establishing sustituye `shallow depth of field` por `deep focus, the full room in sharp detail` (un wide con DoF corto se colapsa a retrato). El resto del ancla no cambia.

### Slot 6-bis: PICOS EMOCIONALES — actuacion fisica real (nuevo, obligatorio)

El defecto: todo el drama se ve "calmado". La contencion (`emotionally restrained acting`) es el DEFAULT del genero, pero en los PICOS la emocion se actua con TODO EL CUERPO o el espectador no siente nada.

**Regla: 2-4 escenas de PICO por Parte** (la humillacion mayor, la revelacion, la perdida, el cobro). En esas escenas:

1. En el ancla de estilo, sustituye `emotionally restrained acting` por **`raw, intense emotional performance`**. El resto del ancla no cambia.
2. La emocion se escribe en el image_prompt como ACCION FISICA CONCRETA, no como adjetivo. "Sad" no existe; "collapsed on her knees" si. Vocabulario por emocion (en ingles, listo para pegar):
   - **LLANTO / devastacion:** `collapsed on her knees on the floor, sobbing openly, face crumpled, tears streaming down her cheeks` · `slumped against the wall, sliding down to the floor` · `clutching the dress against her chest, rocking slightly` · `gripping the table edge to stay upright, head hanging, shoulders shaking`.
   - **IRA real:** `slamming her palm flat on the table` · `sweeping the dishes off the table with one arm` · `gripping his collar with both fists` · `pointing with a trembling finger, face flushed, jaw clenched, veins tense in her neck` · `tearing the document in half with both hands`.
   - **MIEDO / desesperacion:** `backing against the wall, both hands shaking` · `grabbing his sleeve with both hands, begging` · `one hand clutching her chest, breathing hard`.
   - **ALEGRIA / alivio:** `laughing openly, eyes crinkled shut, both hands over her mouth` · `pulling her into a tight embrace, eyes squeezed shut` · `sinking into a chair with relief, hand over her heart`.
3. **Bocas en picos de llanto (escena N):** se permite boca abierta SI se blinda contra el lip-sync falso: `mouth open in a silent sob, not forming words, no speech-like lip movement`. En picos de ira en escena N: `shouting silently is forbidden — keep the jaw clenched, mouth closed`; el grito con palabras va SIEMPRE en escena D con su cita en el voiceover.
4. **Animacion del pico:** sigue siendo UNA accion + UN movimiento, pero la accion es la fisica del pico, simple y ejecutable: `her shoulders shake as she sobs` · `she slams her palm on the table once and the glasses jump` · `she slides slowly down the wall to the floor` · `she tears the paper in one motion`. Golpes y rasgados = UNA vez, no repetidos (el loop se ve falso). Nada de morphs faciales extremos: las lagrimas y la cara rota se piden en el IMAGE prompt; la animacion aporta el temblor.
5. **La pose debe acompanar (REGLA DE POSTURA):** pico tirada en el piso → pose `llorando_piso` (kneeling/collapsed) generada en el MISMO JSON. Nunca actuar un colapso con una pose de pie.
6. **Dosificacion:** el pico pega porque el resto esta contenido. Si toda la Parte grita, nada grita. Primero herida contenida (golpe-golpe-respiro), el pico ESTALLA, y despues vuelve la contencion. Colocacion tipica: 1 pico en la humillacion central, 1 en la revelacion/cobro, opcional 1 en el cliffhanger.

### Slot 7: negativos (red de seguridad, sin fe ciega)

Hay DOS bloques de negativos; usa el que corresponda al motor de la serie.

NEGATIVOS DEFAULT (realista):
`No text, no subtitles, no watermark, no logo, no deformed hands, no extra hands, no duplicated faces, no cloned characters, no Western appearance, no anime, no fantasy, no superpowers, no historical clothing. No direct eye contact with the camera. Vertical 9:16.`

NEGATIVOS OPT-IN MISTICO (series con `allow_supernatural`; NO lleva "no fantasy/no superpowers" para no chocar con el glow/vision positivo):
`No text, no subtitles, no watermark, no logo, no deformed hands, no extra hands, no duplicated faces, no cloned characters, no Western appearance, no anime, no superhero VFX, no energy beams, no monsters, no glowing cartoon eyes, no historical clothing. No direct eye contact with the camera. Vertical 9:16.`

Recuerda: si algo importa, ya lo dijiste en positivo en los slots 1-5.

### Packs visuales por mundo (usa el que declare el MUNDO en §5)

Mundos A-D (moderno/makjang/chaebol/internado) usan el ancla del Slot 6 y los negativos DEFAULT (o el MISTICO si `allow_supernatural`). Los mundos E-J sustituyen ancla y negativos por su pack:

**SAGEUK JOSEON** (`allow_historical`) — hanbok, norigae, gat, binyeo, palacio Joseon, patio de tierra, linternas, biombos, pergaminos, sello real, jerarquia extrema, destierro, matrimonio politico.
- Ancla: `cinematic Korean sageuk melodrama, realistic Joseon-era Korean characters, elegant palace atmosphere, restrained emotional acting, natural skin texture, historically inspired hanbok wardrobe, high production value, consistent facial identity`
- Negativos: `No text, no subtitles, no watermark, no logo, no deformed hands, no extra hands, no duplicated faces, no cloned characters, no Western medieval armor, no modern clothing, no sneakers, no phones, no cars, no modern office, no anime, no superhero VFX. No direct eye contact with the camera. Vertical 9:16.`

**C-DRAMA COSTUME** (`allow_historical`) — hanfu, palacio imperial, jardines, biombos, horquillas, abanicos, pergaminos, sello imperial, carruaje, patio de nieve.
- Ancla: `cinematic Chinese costume melodrama, realistic East-Asian characters, imperial palace intrigue, elegant hanfu wardrobe, restrained emotional acting, high production value, consistent facial identity`
- Negativos: `No text, no watermark, no logo, no deformed hands, no duplicated faces, no modern clothing, no modern buildings, no cars, no phones, no Western medieval armor, no anime, no superhero VFX. No direct eye contact with the camera. Vertical 9:16.`

**CRIME NOIR** — autos negros, lluvia, pasillos frios, clubes privados, funerales, manos temblando, puerta cerrada; violencia FUERA de cuadro, sangre minima o ausente, aftermath emocional.
- Ancla: `cinematic Korean crime noir melodrama, realistic East-Asian characters, cold moody lighting, restrained emotional acting, natural skin texture, high production value, consistent facial identity`
- Negativos: los default MAS `no graphic gore, no blood spray, no on-screen violence, no fight choreography`.

**SURVIVAL GAME** — uniformes sin logos, luces frias, numeros, habitaciones vacias, pantallas abstractas SIN texto legible, puertas metalicas, camaras de vigilancia; castigo fuera de cuadro.
- Ancla: `cinematic survival thriller melodrama, realistic East-Asian characters, cold institutional lighting, restrained tension, natural skin texture, high production value, consistent facial identity`
- Negativos: los default MAS `no graphic gore, no blood, no readable UI text, no video game HUD`.

**MYTHIC FANTASY / OLIMPO** (`allow_supernatural`) — fantasia VISIBLE al servicio del melodrama (herencia divina, juramento roto), no espectaculo vacio.
- Ancla: `cinematic Asian mythic melodrama, realistic East-Asian characters, divine palace atmosphere, elegant white stone architecture, soft golden supernatural light, restrained emotional acting, high production value, consistent facial identity`
- Negativos: `No text, no subtitles, no watermark, no logo, no deformed hands, no extra hands, no duplicated faces, no anime, no cartoon effects, no superhero suit, no plastic armor, no video game UI. Vertical 9:16.`

**SCI-FI SUAVE** — laboratorio, pantallas abstractas sin texto, capsulas medicas, vidrio, acero, luces azules, implante sutil, pulsera biometrica.
- Ancla: `cinematic near-future melodrama, realistic East-Asian characters, sleek corporate lab atmosphere, cool blue lighting, restrained emotional acting, natural skin texture, high production value, consistent facial identity`
- Negativos: los default MAS `no complex spaceships, no aliens, no futuristic weapons, no readable UI text, no video game HUD`.

### Prompts para lo sobrenatural (opt-in, solo series con `allow_supernatural`)

Lo sobrenatural se ve CONTENIDO y fotorrealista, como cine de misterio coreano (tono Goblin/Guardian, no anime). Reglas:

- Manifestalo con LUZ y practicos, NO con VFX: `a soft supernatural glow`, `faint light emanating from the medallion`, `candles flaring by themselves`, `frost creeping across the mirror`, `her reflection lagging half a second`, `a pale figure barely visible in the deep background, out of focus`.
- Visiones/premoniciones: `a faint translucent overlay of a memory`, `subtle double-exposure of a past scene`, sin cortar el plano.
- Poder sencillo = un gesto + un efecto de luz sutil (`she raises her hand and the lamps dim`); NUNCA rayos, ondas de energia, auras de color saturado, transformaciones ni criaturas.
- Manten el ancla realista y los negativos de §6; anade en positivo lo sobrenatural que quieras y en el bloque negativo `no cartoon effects, no anime energy, no glowing cartoon eyes, no monsters, no superhero VFX`.
- El animation_prompt sobrenatural sigue siendo UNA accion + UN movimiento LENTO (`the glow slowly intensifies`, `the frost spreads`); el movimiento rapido derrite el efecto.

### animation_prompt

- Empieza con `ACTION (within 4 seconds):`.
- **UNA sola accion fisica del sujeto + UN solo movimiento de camara nombrado** (`slow dolly in`, `slow push-in`, `static camera`, `handheld sway`). Mas de una accion o frases tipo "cut to" / "camera switch" provocan cortes de plano a mitad del clip.
- NO re-describas la imagen (ya la tiene): describe solo el CAMBIO.
- Movimiento SIMPLE y lento: el movimiento rapido derrite caras y manos. Evita animar extreme close-ups de cara/manos.
- En escenas N: `mouth closed, not speaking`.
- En escenas D, el que habla debe VERSE hablando: encuadre medium o mas cerrado (NUNCA wide/full body: la boca no se lee), rostro frontal o tres cuartos, boca visible en cuadro. Formula, **con descriptor en vez de nombre a secas**: `the woman in the grey apron begins speaking immediately, lips clearly moving through a short deliberate sentence; IMPORTANT: ONLY the woman in the grey apron moves her mouth; everyone else keeps their mouths closed and still.` (Si el pipeline exige el nombre, usa `<DisplayName>, the woman in the grey apron, begins speaking...` — nombre Y descripcion, nunca el nombre solo.)
- Expectativa D: Grok NO sincroniza silabas con el audio (no hay lip-sync real); el objetivo es que se LEA quien habla mientras la narradora cita su linea. Linea corta, y la escena D coincide con la CITA directa de ese personaje en el voiceover.
- DENSIDAD D: DEPENDE DEL MOTOR elegido en §5 (Selector), NO es fija. Injusticia/elite/confrontacion familiar 40-50%; romance-contrato/CEO/traicion intima 35-45%; madre perdida/falso culpable/culpa 30-45%; misterio de lugar/hospital/proteccion/mistico 25-40%. Van en RAFAGAS de 2-4 escenas por confrontacion, no salpicadas: la crueldad/el conflicto se OYE en boca de los personajes. NUNCA fuerces 40-50% en misterio, hospital, madre perdida o mistico (ahi mas escenas N de descubrimiento: objetos, puertas, miradas, llamadas).
- Cierra con `Single continuous shot. Keep face(s) EXACTLY as provided. Vertical 9:16.`

---

## 7. Captions, highlights y tags Fish

- `captions.text`: corto, 3-7 palabras, selectivo. Puede ser `""`. Con tildes y enie.
- `highlight_words`: solo palabras que realmente aparecen en `voiceover.text`.
- Tags Fish: al inicio del `voiceover.text`, en ingles, compuestos de 3-5 elementos. Se colocan solo en beats fuertes: gancho, revelacion, amenaza, cliffhanger. No en cada escena.
- Catalogo util para este genero (compuestos, en ingles):
  - `[low, cold, tense]` — gancho, amenaza contenida.
  - `[soft, trembling, hurt]` — humillacion, herida fresca.
  - `[icy, controlled, threatening]` — la protagonista toma poder.
  - `[breathless, urgent]` — descubrimiento, huida.
  - `[bitter, mocking]` — villana, sarcasmo elegante.
  - `[warm, nostalgic, sad]` — flashback, perdida.
  - `[low, resolute]` — decision, juramento.

---

## 8. Voz y audio

```json
"audio": { "voice_speed": 1.25, "voice_rate": 1, "music_volume": 0 },
"tts_export": {
  "mode": "per_scene",
  "voice_id": "bfed5c0810a347dbb62e8ccce7f59c48"
}
```

Reglas duras:

- Voz Fish Audio, no ElevenLabs.
- `mode:"per_scene"`, no `dialogue`, no `full_script` obligatorio.
- `voiceover.speaker` siempre `"narrador"`.
- Una sola voz femenina para toda la serie.
- `voice_speed: 1.25` fijo.
- `music_volume: 0`; musica y SFX solo como notas.
- Ortografia completa en el texto hablado (tildes, enie); cifras con palabras.

---

## 9. Continuidad

Antes de entregar cada parte, revisa:

- Que ropa trae cada personaje y por que (la tabla de ASSETS DE LA SERIE registra ropa por pose).
- Si la escena sigue fisicamente desde la anterior.
- Si el lugar y la hora tienen sentido, y si la LUZ es consistente dentro de cada secuencia (no saltar de ambar a azul en el mismo cuarto y hora).
- Si la pose referenciada coincide con ropa, emocion, accion Y POSTURA (sentado/de pie/apoyado).
- Si el escenario view corresponde al angulo Y la distancia del prompt (plano lejano = view lejana).
- Si los eyelines de un dialogo son consistentes entre plano y contraplano (A mira frame-right, B mira frame-left, siempre).
- Si cada asset nuevo se usa al menos una vez.
- Si no se regenera un asset ya existente.
- Si ninguna escena pasa de 3 referencias (personajes + escenario + props).

---

## 10. Checklist

- [ ] Motor principal + secundario Y MUNDO/SKIN elegidos y documentados (Contrato de la parte) antes de cualquier escena.
- [ ] Opt-in especial declarado si aplica (`allow_supernatural` para mistico/mythic, `allow_historical` para sageuk/C-drama); prompts usando el PACK del mundo (§6), no el default.
- [ ] Serie nueva: MAPA DE TEMPORADA impreso y aprobado antes de la Parte 1.
- [ ] ESTADO DE HISTORIA actualizado impreso al final de cada parte.
- [ ] `project.preset` = `"novela-coreana"`.
- [ ] `project.serie` y `project.slug` correctos.
- [ ] `pipeline.image_generation.tool` = `"grok"`; `pipeline.animation.tool` = `"grok"`; `pipeline.tts.tool` = `"fish"` o ausente.
- [ ] Sin `opening`, sin `narrative_card`, sin `static`.
- [ ] 30-50 escenas (~1:30-2:30); todas con `visual.image_prompt` y `visual.animation_prompt`; densidad D SEGUN el motor (§5 selector: injusticia 40-50%, misterio/hospital/madre 25-40%), en rafagas.
- [ ] Motor de injusticia: 4-6 despojos consumados en escalada; antagonista ejecuta 2-3 maldades; flashforward de promesa en escenas 2-3; reversal/pago antes del cliffhanger; cliffhanger de estatus/identidad (no solo pista); 1 emocion declarada cada 4-5 escenas; titulo = promesa del trope.
- [ ] FILTRO DE VIRALIDAD pasado: hook sin explicacion y con UN solo nombre; el hook NO spoilea el giro; promesa de pago emocional en escenas 2-3 (en injusticia: persona de poder, no "abogado"); dano del hook ejecutado antes de la escena 6; victima antes de heroina iconica (max 1 dignidad por 3 humillaciones en el primer tercio); objeto ancla que vuelve; max 2 terminos legales antes de la primera humillacion.
- [ ] MOTOR PRINCIPAL elegido (§5 selector); consecuencias, promesa, reversal y densidad D acordes a ESE motor (no la escalera de injusticia por defecto).
- [ ] Serie: MAPA DE TEMPORADA creado antes de la Parte 1; ESTADO DE HISTORIA (ledger) impreso al final; maximo 3 preguntas grandes abiertas a la vez; UNA pregunta dominante por parte.
- [ ] Parte N (2+): reentrada autonoma sin recap (muestra la CONSECUENCIA del cliffhanger); antagonista con tactica NUEVA; paga una promesa anterior; abre una pregunta mas peligrosa de tipo distinto; objeto ancla aparece o se transforma; reloj mencionado o avanzado.
- [ ] Todas las escenas con voz corta (7-13 palabras, 3-5 s), CON tildes y enie, cifras en palabras.
- [ ] `characters.<id>.poses` completo, rutas bajo `assets/characters/<serie>/`; poses de POSTURA para escenas sentadas/apoyadas.
- [ ] `escenarios.<id>.views` completo, rutas bajo `assets/escenarios/<serie>/`.
- [ ] Solo assets nuevos con `mode:"generate"`; lo existente con `mode:"existing"`.
- [ ] Cada escena referencia pose/view declaradas; maximo 3 referencias por escena.
- [ ] Todo image_prompt cumple los 7 slots; colocacion explicita en TODA escena con mobiliario; "in the provided" (nunca "on" salvo superficie real).
- [ ] Distribucion de planos cumplida (>=2 abiertas, <=5 cerradas, >=1 OTS/behind por cada 10; sin 2 seguidas del mismo tamano salvo plano/contraplano; max 2 seguidas de la misma view).
- [ ] VARIEDAD DE ESCENARIOS: minimo 4-5 escenarios distintos en la Parte; ninguno concentra mas del 50% de las escenas; maximo 3-4 escenas seguidas en el mismo escenario; cada escenario principal con >=3 views de posicion; la Parte introduce >=1 escenario nuevo o 2 views nuevas.
- [ ] DESCRIBIR NO SOLO NOMBRAR: cada personaje lleva descriptor fisico corto la primera vez en CADA prompt (imagen y animacion) y luego se menciona por descripcion; mismo descriptor en toda la serie.
- [ ] LEJANIA REAL: >=1 toma verdaderamente lejana por cada 10 escenas; los `full body shot` llevan "head to feet in frame" + "both feet on the floor"; confrontaciones de pie en `cowboy shot, from the knees up`, no "waist up".
- [ ] VARIEDAD DE ANGULOS: >=3 angulos distintos ademas del frontal por cada 10 escenas; >=1 encuadre con oclusion/reflejo/silueta; personaje descentrado en al menos 2 escenas.
- [ ] ANTI-REPETICION DE CARA: maximo 3 primeros planos frontales de la misma cara por cada 10 escenas; la misma expresion no se muestra dos veces de frente en la Parte; los tramos emocionales se rompen con insert de objeto, silueta, reflejo o de espaldas.
- [ ] Prompts de views derivadas empiezan con "New camera position: ..." y el "Keep the exact same..." va DESPUES — nunca empiezan con "Same <escenario>".
- [ ] 2-4 PICOS emocionales con actuacion fisica de cuerpo entero (Slot 6-bis): ancla `raw, intense emotional performance`, accion fisica concreta en el image_prompt, pose de postura acorde, boca blindada (`silent sob, not forming words`) en N.
- [ ] animation_prompt: una accion + un movimiento de camara; N con boca cerrada; escenas D en RAFAGAS SEGUN EL MOTOR (NUNCA cifra fija global): injusticia/elite/confrontacion familiar 40-50%; romance/CEO/traicion intima 35-45%; madre/falso culpable/culpa/identidad/regresion/noir/transmigracion 30-45%; misterio/hospital/proteccion/survival/mistico/sci-fi 25-40%. Nunca forzar 40-50% en misterio, hospital, madre, mistico, survival o sci-fi.
- [ ] Gancho en scene_01 con una de las 4 formulas; cliffhanger de tipo DISTINTO al de la parte anterior.
- [ ] Ningun tramo de mas de 4 escenas sin informacion/amenaza/pregunta nueva.
- [ ] Narracion pasa la PRUEBA DEL CIEGO: nombre de la narradora pronunciado, tablero dicho en escenas 2-4, maximo 4 nombres hablados presentados con su relacion, un solo apodo por persona.
- [ ] Escenas D en estilo directo con atribucion garantizada (tag antes de la cita, o linea a pelo con N de setup previa); sin pronombres ambiguos; flashbacks anclados al entrar y al salir.
- [ ] Extras anonimos coreanos desenfocados en espacios publicos.
- [ ] Captions/highlights validos. JSON valido sin comentarios.
- [ ] Al final se entrega "ASSETS DE LA SERIE" actualizado (con ropa por pose, reloj de la serie y tipo de cliffhanger usado).

---

## 11. Errores comunes

- Entregar `_ASSETS.json`: en v2 ya no existe.
- Usar `ingredients` viejo para personajes principales.
- Poner cards de personaje fuera de `characters.<id>.poses`.
- Usar `render_mode:"static"`. Usar ElevenLabs o multivoz.
- **Personaje encima de la mesa:** pose de pie en escena sentada, o colocacion implicita sin oclusion, o "on the provided <view>". Las tres cosas estan prohibidas.
- **View close de mobiliario con personaje de cuerpo entero** (las views close son solo para inserts).
- Repetir plano medio frontal en muchas escenas; dos escenas seguidas con el mismo tamano de plano; toda la parte en la view `base`.
- Confiar en negativos ("not standing on the table"): Grok los ignora; se dice en positivo.
- Mas de 3 referencias en una escena (2 personajes + escenario + prop = 4: se cae el prop).
- Re-describir la imagen entera en el animation_prompt, o pedir dos acciones / "cut to" (provoca cortes de camara).
- Poner un personaje en prompt sin referenciarlo.
- Cambiar rostro, edad, peinado o ropa sin pose nueva. Hacer un `view` nuevo solo por cambiar luz.
- Meter texto dentro de imagen.
- Voiceover sin tildes ("perdon", "anos") o con cifras en numeros.
- Nombres sueltos sin relacion ("Yu-ri sonrio" sin decir quien es Yu-ri) o mas de 4 nombres hablados por parte.
- Dialogos en estilo indirecto ("pregunto si...", "dijo que...") en escenas D.
- Dos etiquetas para la misma persona (patriarca/presidente) o pronombres ambiguos entre personajes del mismo genero.
- Flashback sin ancla de entrada y salida en el audio (el espectador cree que el muerto revivio).
- Racha de frases de atmosfera sin informacion nueva: es la version en audio del valle.
- Parte que es puro setup: cero perdidas ejecutadas, todo amenazas condicionales ("o perderia todo"). Sin despojos no hay deuda emocional que cobrar.
- Cliffhanger deductivo (una pista, un reloj) sin pago/reversal previo dentro de la parte.
- Crueldad narrada en tercera persona en vez de dicha por el antagonista en escena D.
- Flashback que repite el mismo beat en 2-3 escenas seguidas (busco/entrego/miro = UNA escena).
- Guion sin emociones declaradas de la narradora: reporta hechos, no siente.
- Titulo poetico que no comunica el trope ni la injusticia.
- Hook que spoilea el giro: llamar "falsa"/"impostora" a quien el cliffhanger va a desenmascarar.
- Promesa debil de reversal ("un abogado pregunto por mi") en vez de una fuerza mitica de poder.
- Papeleo antes de la herida: terminos legales ("clausula", "acciones", "registro") antes de mostrar una perdida material.
- Heroina invencible desde la escena 1: frases de superioridad antes de que el publico la haya visto sufrir 3 despojos.
- Objeto emocional que nunca vuelve, o reversal entregado por un documento en vez de una persona con poder visible.
- Mas de un nombre propio en la escena 1, o abrir con tramite legal en vez de una perdida ejecutada.
- Convertir TODO drama en venganza/despojos: la injusticia es UN motor de 10; elige el motor correcto (§5 selector) y su escalera propia.
- Parte 2+ que EXPLICA el cliffhanger anterior o hace recap ("En la parte anterior..."), en vez de mostrar su consecuencia.
- Abrir preguntas sin pagar ninguna: mas de 3 loops grandes abiertos = el espectador se pierde (ver ESTADO DE HISTORIA).
- Densidad D fija 40-50% en misterio/hospital/madre perdida: ahi va 25-40% con mas escenas N de descubrimiento (objetos, puertas, miradas).
- Serie sin MAPA DE TEMPORADA ni ESTADO DE HISTORIA: la Parte 2+ improvisa, repite humillaciones y pierde secretos/preguntas.
- Reversal entregado por un documento leido solo, en vez de una persona con poder visible.
- Sobrenatural con VFX de superheroe/anime (rayos, auras, monstruos, ojos brillantes de dibujo): rompe el fotorrealismo; usa luz y practicos (§6).
- Mezclar mundos sin declararlo (un celular en Joseon, una sala de juntas moderna en un palacio imperial).
- Usar los negativos DEFAULT en un mundo sageuk/C-drama/mythic: "no historical clothing/no fantasy" bloquea el hanbok/hanfu/la fantasia; usa el pack del mundo (§6).
- Regresion sin LEDGER TEMPORAL (linea original/actual/eventos cambiados): la historia se vuelve confusa.
- Survival o crime noir que retienen por sangre/accion en vez de por decision moral o aftermath emocional; gore grafico (prohibido en el pipeline).
- Tirar 3 mascaras de identidad en la misma parte (cascada: una por parte).
- Abrir una parte con recap narrado ("En la parte anterior...").
- Resolver el misterio en el cliffhanger, o repetir el mismo tipo de cliffhanger dos partes seguidas.
- Empezar el prompt de una view derivada con "Same <escenario>": Grok repite la imagen de referencia e ignora el angulo nuevo. El cambio de camara va PRIMERO; el "Keep the exact same..." va despues.
- Parte entera en 2 escenarios: se siente monotona aunque cambien las views. Minimo 4-5 escenarios por Parte y transiciones en sets secundarios.
- Escenario principal con una sola view toda la serie ("todo desde el mismo lado").
- Llanto o furia "calmados" en un pico emocional: cara neutra + adjetivo triste no es actuar. El pico se actua con el cuerpo (colapso al piso, golpe en la mesa, suplica agarrando la manga) y el ancla cambia a `raw, intense emotional performance`.
- Gritar con palabras en escena N, o llanto con boca abierta sin blindar (`silent sob, not forming words`): parece lip-sync roto.
- Repetir el golpe/rasgado en loop en el animation_prompt (la accion fisica intensa se ejecuta UNA vez).
- **Nombrar sin describir** ("Ha-na wipes the counter"): el nombre no lleva informacion visual y el modelo inventa la cara. Siempre nombre + descriptor fisico corto, y luego "the woman in the grey apron".
- Pedir `full body shot` sin "head to feet in frame" y sin "both feet on the floor": sale recortado a medio cuerpo y el plano abierto nunca existe.
- Usar "medium shot, waist up" en confrontaciones de pie: corta el cuerpo donde peor se ve y esconde las manos. Ahi va `cowboy shot, from the knees up`.
- Personaje siempre centrado y de frente: descentra, deja aire, usa el borde del cuadro.
- Encadenar 3 primeros planos frontales en un tramo emocional: se rompe con insert del objeto, silueta lejana, reflejo o de espaldas.
- Resolver dos veces la misma expresion con la misma cara frontal: la segunda va en perfil, de espaldas, en reflejo o tapada.

---

## 12. Ejemplo de tres escenas (template v5 aplicado)

Escena 1 = wide establecedor con gancho; escena 2 = medium close-up con dialogo D; escena 3 = COLOCACION con oclusion tras escritorio (el patron anti-"encima de la mesa").

```json
{
  "project": {
    "preset": "novela-coreana",
    "title": "La heredera oculta - Parte 1",
    "serie": "heredera_oculta",
    "slug": "heredera_oculta_parte_01",
    "series": { "id": "heredera_oculta", "part": 1, "is_cliffhanger": true },
    "language": "es",
    "aspect_ratio": "9:16",
    "fps": 30,
    "reuse_ingredients": true,
    "grok_clip_seconds": "6",
    "scene_target_seconds": 4,
    "voice_target_seconds": [3, 4],
    "voice_ceiling_seconds": "5",
    "hook": "Esa noche, todos descubrieron mi apellido."
  },
  "pipeline": {
    "image_generation": { "tool": "grok" },
    "animation": { "tool": "grok" },
    "tts": { "tool": "fish" }
  },
  "characters": {
    "soo_yeon": {
      "display_name": "Soo-yeon",
      "poses": {
        "base": { "mode": "existing", "asset": "assets/characters/heredera_oculta/soo_yeon_base.png" },
        "llorando_gala": { "mode": "generate", "asset": "assets/characters/heredera_oculta/soo_yeon_llorando_gala.png", "reference_pose": "base", "prompt": "Same character Soo-yeon, same face and hair, elegant black gala dress, restrained tears, empty hands, realistic Korean melodrama, neutral studio background." },
        "sentada_oficina": { "mode": "generate", "asset": "assets/characters/heredera_oculta/soo_yeon_sentada_oficina.png", "reference_pose": "base", "prompt": "Same character Soo-yeon, same face and hair, charcoal office suit, seated on a plain chair, upright posture, hands clasped on her lap, neutral studio background." }
      }
    }
  },
  "escenarios": {
    "gran_salon": {
      "display_name": "Gran salon",
      "views": {
        "base": { "mode": "existing", "asset": "assets/escenarios/heredera_oculta/gran_salon_base.png" },
        "desde_escalera": { "mode": "generate", "asset": "assets/escenarios/heredera_oculta/gran_salon_desde_escalera.png", "reference_view": "base", "prompt": "New camera position: from the top of the staircase looking down at the marble floor, the banister edge in the foreground. Keep the exact same luxury ballroom architecture and warm chandelier lighting as the reference. Empty set, no people, no text." }
      }
    },
    "despacho": {
      "display_name": "Despacho del presidente",
      "views": {
        "base": { "mode": "generate", "asset": "assets/escenarios/heredera_oculta/despacho_base.png", "prompt": "EMPTY luxury Korean chairman office seen from the visitor side, large dark wood desk in the foreground, empty executive chair and tall window behind it, cold blue-grey daylight, desaturated corporate palette, no people, no text, realistic cinematic K-drama, vertical 9:16." }
      }
    }
  },
  "ingredients": [],
  "scenes": [
    {
      "id": "scene_01",
      "references": { "characters": [{ "id": "soo_yeon", "pose": "base" }], "escenario": { "id": "gran_salon", "view": "base" }, "ingredients": [], "scenes": [] },
      "visual": {
        "image_prompt": "Using the provided Soo-yeon in the provided grand ballroom: establishing wide shot from the entrance doors, floor to ceiling visible, Soo-yeon full body small in the lower third standing alone on the marble floor, hands still at her sides, blurred anonymous Korean gala guests turning toward her on both sides, restrained shock, warm amber chandelier light with soft haze. Cinematic Korean family melodrama, realistic East-Asian characters, elegant luxury atmosphere, emotionally restrained acting, natural skin texture, deep focus, the full room in sharp detail, high production value, consistent facial identity, consistent wardrobe. No text, no watermark, no deformed hands, no Western appearance, no anime. No direct eye contact with the camera. Vertical 9:16.",
        "animation_prompt": "ACTION (within 4 seconds): blurred guests slowly turn toward Soo-yeon while she stays frozen, only her chin lifting slightly, mouth closed, not speaking; slow dolly in. Single continuous shot. Keep face EXACTLY as provided. Vertical 9:16."
      },
      "voiceover": { "text": "[low, cold, tense] Esa noche, todos descubrieron mi apellido.", "speaker": "narrador" },
      "captions": { "text": "MI APELLIDO", "highlight_words": ["apellido"] }
    },
    {
      "id": "scene_02",
      "references": { "characters": [{ "id": "soo_yeon", "pose": "llorando_gala" }], "escenario": { "id": "gran_salon", "view": "desde_escalera" }, "ingredients": [], "scenes": [] },
      "visual": {
        "image_prompt": "Using the provided Soo-yeon in the provided grand ballroom staircase view: medium close-up from her right profile, camera at the top of the staircase, she stands at the railing with both hands resting on the banister, one tear on her cheek, guests blurred far below, warm chandelier backlight rimming her hair. Cinematic Korean family melodrama, realistic East-Asian characters, elegant luxury atmosphere, emotionally restrained acting, natural skin texture, shallow depth of field, high production value, consistent facial identity, consistent wardrobe. No text, no watermark, no deformed hands, no anime. No direct eye contact with the camera. Vertical 9:16.",
        "animation_prompt": "ACTION (within 4 seconds): one tear falls as she speaks a short line with restrained dignity, camera static. IMPORTANT: ONLY Soo-yeon moves her mouth; blurred guests below stay still. Single continuous shot. Keep face EXACTLY as provided. Vertical 9:16."
      },
      "voiceover": { "text": "No vine a pedir perdón. Vine a reclamarlo todo.", "speaker": "narrador" },
      "captions": { "text": "", "highlight_words": [] }
    },
    {
      "id": "scene_03",
      "references": { "characters": [{ "id": "soo_yeon", "pose": "sentada_oficina" }], "escenario": { "id": "despacho", "view": "base" }, "ingredients": [], "scenes": [] },
      "visual": {
        "image_prompt": "Using the provided Soo-yeon in the provided chairman office: medium shot from the visitor side of the desk, camera at eye level, Soo-yeon seated BEHIND the chairman desk, the desk edge in the foreground partially hiding her waist, hands clasped on the dark wood surface, feet on the floor behind the desk, tall window behind her, cold blue-grey daylight from the window. Cinematic Korean family melodrama, realistic East-Asian characters, elegant luxury atmosphere, emotionally restrained acting, natural skin texture, shallow depth of field, high production value, consistent facial identity, consistent wardrobe. No text, no watermark, no deformed hands, no anime. No direct eye contact with the camera. Vertical 9:16.",
        "animation_prompt": "ACTION (within 4 seconds): she leans forward slightly and places one hand flat on the desk, mouth closed, not speaking; static camera. Single continuous shot. Keep face EXACTLY as provided. Vertical 9:16."
      },
      "voiceover": { "text": "[icy, controlled] La silla de mi padre. Nadie me la regaló.", "speaker": "narrador" },
      "captions": { "text": "LA SILLA DE MI PADRE", "highlight_words": ["padre"] }
    }
  ],
  "capcut_export": {
    "clip_order": ["scene_01", "scene_02", "scene_03"],
    "caption_style": { "font": "bold sans-serif", "position": "lower-third", "color": "white", "stroke": "black" },
    "title_cards": ["CONTINUARA", "PARTE 2: LA FIRMA"],
    "cliffhanger_card": "PARTE 2?",
    "music_notes": ["Piano dramatico suave"],
    "sfx_notes": ["Murmullos de gala", "Silencio de oficina con reloj"]
  },
  "audio": { "voice_speed": 1.25, "voice_rate": 1, "music_volume": 0 },
  "tts_export": { "mode": "per_scene", "voice_id": "bfed5c0810a347dbb62e8ccce7f59c48", "note": "Una sola voz femenina narra todo." }
}
```

### Mini-ejemplos de otros motores (beats de referencia, mismo contrato JSON)

Para que el sistema NO caiga siempre en injusticia, aqui el esqueleto de dos motores distintos (solo cambia la historia; el contrato, assets y prompts son identicos):

**Romance por contrato (motor B):**
- Hook (esc 1): "Firme ser su esposa por cien dias." (contradiccion intima, no humillacion)
- Promesa (esc 2-3): "Tres noches despues, el hombre que me odiaba durmio frente a mi puerta."
- Consecuencias ejecutadas: contrato firmado, cama compartida, foto publica filtrada, beso negado.
- Pago/reversal (por persona): el la protege en publico sin querer.
- Cliffhanger: "El contrato no era para comprarme. Era para esconderme."

**Madre desaparecida (motor D):**
- Hook (esc 1): "Mi madre desaparecio la noche que naci."
- Promesa (esc 2-3): "Una semana despues, una nina desconocida llamo a mi madre por mi nombre."
- Consecuencias ejecutadas: carta quemada, llamada cortada, foto escondida, medicina retenida.
- Pago/reversal (prueba de sacrificio): una prueba muestra que el abandono fue para salvarla.
- Cliffhanger: "Ella no me dejo: la obligaron. Y esta viva aqui."

Ninguno usa herencia ni despojos, pero ambos abren una DEUDA emocional con pago dentro de la parte.
