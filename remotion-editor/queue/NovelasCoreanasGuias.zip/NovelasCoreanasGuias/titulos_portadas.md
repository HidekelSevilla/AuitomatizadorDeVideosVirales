# Títulos para portadas (thumbnails) — estilo INTERNADO LEGADO / HEREDERA OCULTA

## Lo que dicen tus vistas
- Marcas de 2 palabras = tus mayores hits: INTERNADO LEGADO (79 mil), HEREDERA OCULTA (75/41 mil).
- Frase larga = fuerte pero menor: "LE PAGUÉ SU VIDA Y EMBARAZÓ A OTRA" (24 mil).
- Título literal/plano = flop: "MI HIJO ELIGIÓ A SU PADRE RICO" (1,3–8 mil).

## Regla de portada
```
ARRIBA (chico):  MARCA DE LA SERIE  ← 2 palabras, igual en todas las Partes (esto hace el maratón)
CENTRO (grande): GANCHO de esa Parte ← solo si cabe; en P1 obligatorio
ABAJO (grande):  PARTE X
```
El gancho corto es para la Parte 1 (el primer clic). De la Parte 2 en adelante, la marca + PARTE X ya basta porque la imagen manda.

---

# SERIE 1 — medula_prestada
### MARCA (recomendada): **SANGRE PRESTADA**
Alternativas: HEREDERA DONADA · APELLIDO ROBADO · SANGRE Y APELLIDO

Gancho corto por Parte (mayúsculas serif, ≤7 palabras):

| Parte | GANCHO DE PORTADA |
|---|---|
| 1 | TRES AÑOS FUI SU BANCO DE SANGRE |
| 2 | SU AMANTE ERA LA HIJA FALSA |
| 3 | ME BORRARON DEL REGISTRO |
| 4 | MI BODA FUE UNA COMPRA |
| 5 | MI MADRE ME ROBÓ AL NACER |
| 6 | FIRMÉ QUE NO ERA NADIE |
| 7 | MI PADRE ME NEGÓ EN PÚBLICO |
| 8 | LA NOVIA NO DIO UNA GOTA DE SANGRE |

Variantes más brutales para la P1 (elige la que enganche):
- LE DI MI SANGRE, LE DIERON MI CAMA A OTRA
- ME SACABAN SANGRE Y ME QUITARON EL APELLIDO
- FUI SU DONADORA HASTA QUE ME ECHARON

---

# SERIE 2 — boda_repetida
### MARCA (recomendada): **BODA REPETIDA**
Alternativas (más misteriosas, estilo HEREDERA OCULTA): OTRA VEZ DE BLANCO · NOVIA DOS VECES · LA NOVIA QUE VOLVIÓ

Gancho corto por Parte:

| Parte | GANCHO DE PORTADA |
|---|---|
| 1 | MI HERMANA ME AHOGÓ EN MI BODA |
| 2 | ME HICIERON PASAR POR LOCA |
| 3 | ME MATÓ POR MI EMBARAZO |
| 4 | QUIERE ROBARME A MI HIJO |
| 5 | GRITÓ QUE YO YA ESTABA MUERTA |

Variantes para la P1:
- MI HERMANA ME AHOGÓ. DESPERTÉ EN MI BODA
- ME MATARON POR LA HERENCIA. VOLVÍ EN EL TIEMPO
- MI ESPOSO SOSTUVO LA PUERTA MIENTRAS ME AHOGABA

---

## Cómo diseñarlas para que se lean en miniatura
1. **Marca arriba, chica, small caps** (como "INTERNADO LEGADO"): color claro con brillo dorado/plata según la serie.
2. **Gancho al centro o partido en 2–3 líneas**, con la palabra más fuerte más grande (SANGRE, AHOGÓ, LOCA, MUERTA).
3. **PARTE X enorme abajo** con la voluta dorada que ya usas.
4. **Cara del villano o de la protagonista mirando de lado**, nunca a cámara (igual que tus mejores portadas).
5. **Contraste de color por serie**: medula_prestada en rojos/vino (sangre); boda_repetida en azules fríos (agua/tina) — así se distinguen de un vistazo en tu grid.
6. Máx **6–7 palabras** en el gancho. Si no cabe grande, córtalo.

## Test antes de exportar
Míralo a tamaño de uña. Si en 2 segundos no sabes **quién traicionó a quién**, la palabra grande está mal elegida.
