# Títulos y hashtags v2 — que vendan

## La fórmula (la de "Mi esposo embarazó a mi mejor amiga")

```
[MI + persona íntima]  +  [verbo brutal concreto]  +  [a MÍ / a alguien mío]
                        (+ opcional: el giro que no sabían)
```

**Reglas duras:**

1. **Siempre un posesivo de familia**: mi esposo, mi suegra, mi hermana, mi cuñada, mi propio padre. Sin "la mujer que…", sin "alguien".
2. **Verbo de daño, no de objeto**: ahogó, metió, echó, vendió, borró, gritó, negó. NUNCA "doné", "encontré", "descubrí un papel".
3. **Cosas que la gente puede sentir en el cuerpo**: sangre, cama, tina, hijo, nombre. No "médula", no "carnet", no "credencial".
4. **Dos frases máximo.** La primera duele, la segunda gira.
5. **Nada de misterio elegante.** "Yo estaba muerta en un libro" es literario. "Mi suegra me borró del registro" es una acusación.

---

# SERIE 1 — medula_prestada

> Nota: en los títulos públicos conviene decir **"me sacaban sangre" / "banco de sangre"** en vez de "médula". Médula es clínico; sangre es visceral y es la fórmula que ya funciona en el género ("banco de sangre del marido").

## PARTE 1
- **PANTALLA:** `Mi esposo metió a su amante en mi cama`<br>`mientras yo donaba sangre para su hermana.`
- **CAPTION:** Tres años fui el banco de sangre de la familia de mi esposo. La noche que salí del hospital, otra mujer dormía en mi cama y mi suegra me sacó a la lluvia. Parte 1 de 8.
- **HASHTAGS:** `#NovelaCoreana #Infidelidad #Suegras #MedulaPrestada #Reels`

## PARTE 2
- **PANTALLA:** `La amante de mi esposo vivía`<br>`en la casa de mi verdadero padre.`
- **CAPTION:** Mi suegra me echó a la calle con lo puesto. Esa misma noche entré a la casa más rica del país y por la escalera bajó descalza la mujer que dormía en mi cama. Parte 2 de 8.
- **HASHTAGS:** `#NovelaCoreana #Infidelidad #DramaCoreano #MedulaPrestada #Reels`

## PARTE 3
- **PANTALLA:** `Mi cuñada me llamó estafadora.`<br>`El dueño de todo se levantó y dijo mi nombre.`
- **CAPTION:** Me borraron del registro del hospital para que otra ocupara mi lugar. En la cena con los socios, el hombre más temido del país se puso de pie y dijo mi nombre completo. Parte 3 de 8.
- **HASHTAGS:** `#NovelaCoreana #HistoriasDeVenganza #IdentidadRobada #MedulaPrestada #Reels`

## PARTE 4
- **PANTALLA:** `Mi boda fue una compra.`<br>`Me lo confesó mi propio esposo sin darse cuenta.`
- **CAPTION:** Mi esposo volvió a buscarme cuando supo quién era yo. Le hice una pregunta que no debía saber contestar y contestó sin pensar: su madre se lo había dicho antes de pedirme matrimonio. Parte 4 de 8.
- **HASHTAGS:** `#NovelaCoreana #Traicion #Infidelidad #MedulaPrestada #Reels`

## PARTE 5
- **PANTALLA:** `Mi madre me mintió toda la vida.`<br>`Ella fue quien me sacó del hospital.`
- **CAPTION:** Mi madre me dijo siempre que limpiaba oficinas. En la única caja que quedó de ella encontré su uniforme de enfermera y el sello del hospital donde me registraron muerta. Parte 5 de 8.
- **HASHTAGS:** `#NovelaCoreana #Madres #HistoriasQueAtrapan #MedulaPrestada #Reels`

## PARTE 6
- **PANTALLA:** `Mi suegra me puso precio:`<br>`mi nombre a cambio de salvar a su hija.`
- **CAPTION:** Su hija se estaba muriendo y yo era la única compatible. Mi suegra me hizo firmar que no era nadie para dejarme entrar al quirófano. Firmé. Parte 6 de 8.
- **HASHTAGS:** `#NovelaCoreana #Suegras #HistoriasDeVenganza #MedulaPrestada #Reels`

## PARTE 7
- **PANTALLA:** `Mi propio padre dijo que yo no era nadie.`<br>`Delante de las cámaras.`
- **CAPTION:** Mi suegra llegó con abogados y prensa, y el hombre que me buscó veintiséis años bajó la mirada y dijo que yo no era nadie. Esa noche entré sola a la casa que me echó. Parte 7 de 8.
- **HASHTAGS:** `#NovelaCoreana #Traicion #DramaCoreano #MedulaPrestada #Reels`

## PARTE 8 (final)
- **PANTALLA:** `Le pedí a la novia una gota de sangre.`<br>`Se negó delante de trescientos invitados.`
- **CAPTION:** El día de su boda le pedí a la novia una sola gota de sangre. No quiso. Trescientos invitados entendieron lo mismo al mismo tiempo. Final de temporada. Parte 8 de 8.
- **HASHTAGS:** `#NovelaCoreana #HistoriasDeVenganza #FinalExplosivo #MedulaPrestada #Reels`

---

# SERIE 2 — boda_repetida

## PARTE 1
- **PANTALLA:** `Mi hermana me ahogó en la tina.`<br>`Mi esposo le sostuvo la puerta.`
- **CAPTION:** Mi hermana me ahogó en la tina de mi casa y mi esposo le sostuvo la puerta. Desperté ocho horas antes, el día de mi boda, con todos los recuerdos. Parte 1 de 5.
- **HASHTAGS:** `#NovelaCoreana #HistoriasDeVenganza #Hermanas #BodaRepetida #Reels`

## PARTE 2
- **PANTALLA:** `Mi hermana convenció a todos`<br>`de que yo estaba loca.`
- **CAPTION:** Mi hermana se mudó al cuarto de al lado con la puerta abierta, leyó mi cuaderno en la cena y le dijo a mi abuelo que yo hablaba dormida. Una loca no hereda. Parte 2 de 5.
- **HASHTAGS:** `#NovelaCoreana #Hermanas #DramaCoreano #BodaRepetida #Reels`

## PARTE 3
- **PANTALLA:** `Mi hermana sabía que yo estaba embarazada`<br>`antes que yo. Por eso me mató.`
- **CAPTION:** Me llevaba té todas las mañanas. Las últimas semanas sabía a jengibre: para las náuseas. No me mataron por la herencia. Me mataron por lo que llevaba dentro. Parte 3 de 5.
- **HASHTAGS:** `#NovelaCoreana #HistoriasDeVenganza #Hermanas #BodaRepetida #Reels`

## PARTE 4
- **PANTALLA:** `Mi hermana anunció mi embarazo antes que yo`<br>`para quitarme a mi hijo.`
- **CAPTION:** Lo dijo en la mesa, delante de toda la familia, y en un día me convirtió en la mujer más frágil de la casa. Una madre inestable no cría a un heredero: lo cría su tía. Parte 4 de 5.
- **HASHTAGS:** `#NovelaCoreana #Madres #Hermanas #BodaRepetida #Reels`

## PARTE 5 (final)
- **PANTALLA:** `Mi hermana gritó que yo ya estaba muerta.`<br>`Delante de treinta personas.`
- **CAPTION:** En la lectura del testamento la dejé hablar hasta que se delató sola: le gritó "ya estabas muerta" a una mujer viva, sentada frente a ella. El médico que ella trajo la estaba mirando a ella. Parte 5 de 5.
- **HASHTAGS:** `#NovelaCoreana #HistoriasDeVenganza #FinalExplosivo #BodaRepetida #Reels`

---

## Test rápido antes de quemar el título

Léelo en voz alta. Si no puedes contestar **"¿quién le hizo qué a quién?"** en tres segundos, no sirve.

- ❌ "Fui al hospital donde nací. Yo estaba muerta." → no hay culpable, hay un misterio.
- ✅ "Mi suegra me borró del registro para que otra ocupara mi lugar." → hay culpable, hay daño, hay giro.
