# Catálogo de Arquetipos Virales — VENA SENTIMENTAL MADRE/PADRE–HIJO
### Documento compañero de `InvestigacionNovelas.md` · julio 2026
### Adaptación a novela coreana melodramática vertical faceless (es-MX, 9:16, por Partes)
*(v2 — corregido tras verificación adversarial: ver §9 Registro de correcciones)*

---

## TL;DR

- Tu instinto es correcto y hay dato duro detrás: **el 41% de los consumidores hispanos de EE.UU. ven microdramas, contra el 22% de la población general [IND — Hub Research]**. Es casi el doble. Y **Latinoamérica ya es el 23% de las descargas globales** del sector, con México creciendo **+170% interanual [IND — Sensor Tower / AppsFlyer]**.
- **Tu ventaja diferencial ya la tienes y no la estás explotando:** el verbo **"eligió"**. En una muestra de ~45 títulos del nicho hispano, el eje dominante es la *agresión* (`humilló`, `me echó`, `me dejaron`). El frame de **elección** apareció solo 3 veces. Elegir duele distinto: implica que el hijo **tuvo opción y te descartó**. Conviértelo en firma de canal.
- **Mejor evidencia por arquetipo:** el "hijo que reniega del progenitor pobre" tiene el único dato de rating nacional del catálogo — **47,6% [IND — AGB Nielsen Corea]**. El "hijo enfermo como moneda de cambio" tiene el único dato de engagement por título del sector, pero es **[AUTO]**, no auditado.
- **Hueco de mercado:** la variante "padres sacrificados abandonados en la vejez" tiene **demografía y economía de producción documentadas [IND]** en China y **ningún hit occidental documentado**. Pero ojo: *no encontré un título concreto que pruebe el arquetipo* — la oportunidad es real, la prueba por título no existe todavía. Trátalo como apuesta informada, no como certeza.
- **Riesgo verificado:** en enero de 2026 YouTube purgó canales de IA repetitiva, incluidos varios de 5-6 millones de suscriptores, y anunció que **reducirá la distribución**, no solo la monetización. Verifiqué el mismo título clonado en 5+ videos distintos en este nicho. Lo que penalizan no es "usar IA": es **repetir**.

---

## 0. Cómo leer las cifras de este documento

| Etiqueta | Significado |
|---|---|
| **[IND]** | Medición independiente con metodología publicada (Sensor Tower, AppsFlyer, AGB Nielsen, Kantar, IBOPE, Hub Research, Deloitte). Fiable. |
| **[AUTO]** | Declarada por la propia plataforma y repetida por prensa. **No auditada.** Señal relativa de qué fórmula funciona, no verdad. |
| **[VERIF]** | Cifra de Reddit citada textualmente en prensa que enlaza el post original. |
| **[SIN CIFRA]** | Arquetipo popular sin métrica publicada. Señal editorial, no dato. |
| **[LEYENDA]** | Cifra que circula como mito y que la propia fuente propietaria desmiente. |

**Advertencias duras:**

1. **Los contadores de "vistas" de ReelShort, DramaBox y FlareFlow son [AUTO].** Sin metodología publicada; una "vista" probablemente cuenta el arranque de un episodio, no la serie. No comparables entre plataformas ni con YouTube.
2. **Techo real de Reddit en este nicho: ~18.000 upvotes en un post.** (Los comentarios top a veces lo superan: 18.300 en un caso.) Quien prometa "cientos de miles" miente. Fiabilidad: Newsweek (cita cifra + enlaza el post) > TwistedSifter > Bored Panda (nunca publica métricas de Reddit) > canales de retelling (mayoritariamente IA, sin original rastreable).
3. **Cifras de exportación de telenovela y dizi son promocionales.** "180 países", "100 millones de espectadores" = material de distribuidora. Las de rating (AGB Nielsen Corea, Kantar España, IBOPE Brasil) sí son medición real.
4. **Sobre el tamaño del mercado:** Deloitte dice $7,8B (global anual); Sensor Tower mide ~$750M de compras in-app en **un trimestre** y solo en tiendas de apps. No son magnitudes comparables — la brecha es metodológica, no una contradicción. Usa Sensor Tower para lo auditable.

---

## 1. LAS SIETE REGLAS DEL MOTOR MATERNO

Destiladas de los tres sistemas (telenovela latina, dizi turco, makjang coreano) y del microdrama vertical actual. Mandan sobre cualquier arquetipo del catálogo.

**1. Dos figuras maternas y un hijo que no sabe la verdad.**
Variety lo formula sobre el formato japonés `Mother`: contrasta dos figuras maternas opuestas y las conecta a través de un niño. Base "casi bíblica" que localiza en cualquier mercado.
> ⚠️ **La mecánica es libre; la ejecución de `Mother` NO.** Ese formato lo licencia Nippon TV territorio por territorio (11 adaptaciones oficiales). Sus dispositivos concretos —maestra suplente, fingir la muerte de la niña, la fuga en tren, la cacería mediática— son **IP comercial viva**. Usa la mecánica de las dos madres; **no copies esa secuencia**. Ver M5.

**2. Haz PERDONABLE a la mala madre.**
Del productor del remake español de `Mother`: *"empatizas con todos los personajes, incluso con la madre biológica maltratadora. La perdonas."* Una villana materna monstruosa limita tu alcance al público de venganza; una comprensible lo duplica.

**3. El sistema debe fallar ANTES del acto desesperado.**
Antes de que tu protagonista mienta, robe, huya o firme algo terrible, **muestra que pidió ayuda y no llegó**. Sin ese beat es una delincuente; con él, una heroína.

**4. Injerta un reloj corporal.**
Enfermedad, trasplante, embarazo, cirugía. En `Kadın` la única donante compatible es la hermana que la odia: **el cuerpo obliga a la reconciliación que la voluntad rechaza.** El giro más eficiente de toda la investigación.

**5. El ajuste de cuentas rinde más que el abrazo. (Dato duro [IND].)**
`Senhora do Destino` (Globo, 2004-05), curva IBOPE episodio a episodio:
- Reencuentro madre-hija → **55 puntos**
- Pelea con la villana que robó al bebé → **58 puntos**
El castigo pagó 3 puntos más. **Diseña al villano como personaje presente, nunca como flashback.**

**6. Un niño en pantalla compra atención en 3 segundos.**
Validado por Nippon TV en todos los territorios: el rol infantil activa el instinto protector. El niño es palanca emocional **para el adulto que mira**, no protagonista para público infantil.

**7. No repartas alivio.**
Regla makjang: la injusticia se acumula sin desahogo para que el pago —el *"cider"* (사이다)— valga el doble. Nada de victorias intermedias.

---

## 2. LOS CUATRO "MOMENTOS DE JUSTICIA" QUE MÁS RINDEN

Transversales a los arquetipos de Reddit. Son tus finales de Parte.

1. **LA FACTURA** — cuantificar la deuda emocional en dinero. El hijo no grita: emite una cuenta. El padre descubre que la reconciliación tiene tarifa.
2. **LA FRASE DEVUELTA** — repetir textualmente las palabras del abandono, años después. No requiere dinero ni violencia, solo memoria. El más barato de producir y el más devastador.
3. **EL CORTE SILENCIOSO DEL RECURSO** — dejar de pagar, bloquear, no firmar. Sin discurso.
4. **LA EXCUSA REPRODUCIDA ANTE TESTIGOS** — exhibir la prueba del desprecio sin comentarla.

---

## 3. CATÁLOGO DE ARQUETIPOS

Formato: **Premisa → Mecanismo → Señal → Adaptación → 5 Partes → Gancho**
Nombres coreanos originales, verificados contra colisiones con figuras públicas y personajes conocidos.
Tipos de cliffhanger: **revelación · reversal · intrusión · deadline**. Regla: no repetir tipo en Partes consecutivas.

---

### M1. EL HIJO QUE ELIGIÓ AL PADRE RICO ★ALTO
> *Tu propio nicho. Lo que sigue es cómo exprimirlo.*

**Premisa:** La madre crió sola al hijo con dos empleos. El padre que se fue reaparece cuando el niño ya está criado — con dinero, regalos y una casa grande. El hijo lo elige. No hay maltrato ni grito: hay una elección tranquila, y eso es lo que destruye.

**Mecanismo:** Único arquetipo del catálogo donde el dolor no viene de una agresión sino de una **preferencia**. La agresión se odia; la preferencia se interioriza. Emoción: indignación + vergüenza vicaria. Brecha: *¿qué le prometió el padre?* / *¿qué hará ella?*

**Señal:** No hay caso de Reddit con cifra publicada de este arquetipo exacto — solo granjas de contenido sin post rastreable **[SIN CIFRA]**. Pero el arquetipo hermano tiene el mejor dato del catálogo: `My Daughter Seo-young` (KBS2, 2012-13), hija que niega a su padre pobre y llega a declararlo muerto para casarse con un rico → **47,6% de rating en el final, drama más visto de 2013 [IND — AGB Nielsen]**. Confirma que el motor aguanta el género intercambiado.

**Adaptación:** **Yoon Ji-young**, 44, limpia oficinas de noche. Su hijo **Yoon Tae-o**, 17, entra becado a un colegio de élite. Aparece **Jang Woo-seok**, 49, el padre que se fue: presidente de un grupo constructor, con esposa nueva y sin hijos varones. Tae-o se cambia el apellido.

| # | Avanza | Cliffhanger |
|---|---|---|
| 1 | El padre reaparece; el hijo acepta la cena, luego la casa, luego el apellido | El hijo la presenta como *"la señora que nos ayuda"* (**revelación**) |
| 2 | Ji-young firma la cesión de custodia para no arruinarlo | El colegio llama: el niño dio otra dirección y otro apellido (**reversal**) |
| 3 | Lo que el padre quiere de verdad: un heredero varón antes de una junta | Le pide a Tae-o que firme algo que no entiende (**intrusión**) |
| 4 | Ji-young lo sabía desde el principio y por eso firmó | Tae-o encuentra **diecisiete años** de recibos de pensión impagada (**revelación**) |
| 5 | Cobro: el hijo vuelve; ella ya no está donde la dejó | Ella no abre la puerta (**deadline**) |

**Gancho (oficial):** *Mi hijo eligió a su padre rico… Firmé los papeles el mismo día.*
Alternativas a testear: `Mi hijo eligió a su padre rico delante de todos. Así que firmé.` · `"Prefiero a papá, él sí tiene dinero"… Mi hijo eligió, y yo también.`

> 🎯 **Corrección a tu título actual.** `Mi hijo eligió a su padre rico` es solo el primer movimiento. La fórmula que domina el nicho hispano es **triple**: `[AGRAVIO + testigo público] … [BISAGRA] [VINDICACIÓN NO RESUELTA]`. Compara con el competidor estructural más cercano que encontré: *"Mi esposo e hijo eligieron a la amante, me humillaron. Tras mi partida, su arrepentimiento los devora."*

---

### M2. LA MADRE HUMILLADA QUE ERA LA DUEÑA ★ALTO

**Premisa:** Madre de origen humilde visita el mundo nuevo de su hijo. La confunden con el servicio y la humillan en público. Es, en secreto, quien controla el lugar.

**Mecanismo:** Ironía dramática pura — el espectador sabe lo que la sala no. Cada humillación es una deuda que se va a cobrar.

**Señal [AUTO, pero fuerte]:** Dos plataformas rivales clonaron la **misma estructura con distinta piel**, lo que indica que los datos de retención la validan:
- `The Extraordinary Mother of a Billionaire` — ReelShort, 56 eps: madre de pueblo criada sola a un hijo multimillonario; la confunden con una ladrona y la humillan en público.
- `Think Again! I'm the Hidden Boss Mom` — DramaBox, 52 eps: las madres del comité escolar la humillan como "una don nadie"; ella es la dueña del colegio.
- `Crowned in Love: The Mother of Three Big Shots` — DramaBox, **100 eps, rating 10.0 [AUTO]**.

**Adaptación:** **Han Bok-ja**, 58, vende comida en un puesto de mercado. Su hijo **Han Ji-hoon**, 32, se casa con la hija de un grupo hotelero. En el banquete, **la consuegra, Wi Geum-sil**, 60, la manda a la mesa del personal. Lo que nadie sabe: la sociedad que compró ese hotel hace once años lleva el nombre del difunto marido de Bok-ja, y ella es la única accionista.

| # | Avanza | Cliffhanger |
|---|---|---|
| 1 | La sientan con el servicio; la consuegra le pide que se cambie de ropa | Un mesero se inclina y la llama *"presidenta"* (**revelación**) |
| 2 | Ella le prohíbe decirlo: quiere ver hasta dónde llegan | La consuegra le ofrece dinero para que no vuelva (**reversal**) |
| 3 | El hijo elige el silencio delante de su suegra | La consuegra entra en la oficina del hotel a exigir y se topa con Bok-ja sentada allí (**intrusión**) |
| 4 | La junta de accionistas se adelanta | El hotel cancela el contrato de la familia de la nuera (**reversal**) |
| 5 | Cobro en la sala donde la sentaron con el servicio | Le devuelve al hijo el sobre con la matrícula que le pagó (**revelación**) |

**Gancho:** *La suegra de mi hijo me sentó con los meseros. Yo era la dueña del hotel.*

---

### M3. LOS PADRES ABANDONADOS EN LA VEJEZ ★ALTO — **el hueco más grande, con reserva**

**Premisa:** Padre o madre que se sacrificó una vida entera es internado en un asilo por sus hijos, o abandonado con una excusa ("ahí vas a estar mejor"). Los hijos siguen con su vida. El progenitor tiene un recurso que ellos no saben.

**Mecanismo:** Indignación moral máxima — viola el contrato humano más básico. Y tiene un público que se identifica *directamente*, no vicariamente.

**Señal — leer con cuidado:** La **demografía y la economía** están documentadas [IND]. El informe iResearch (vía Sixth Tone) establece la diferencia estructural: los ultracortos para jóvenes tratan trabajo y amor; **los hechos para público mayor tratan la relación padres-hijos**, y su atractivo viene de que el protagonista usa recursos enormes para resolver la falta de piedad filial.
Economía (CIW, enero 2026): **310M de chinos de 60+**; producciones de 100-300K RMB alcanzan **70% de rentabilidad**; esa audiencia tiene tiempo, tolera publicidad, no piratea y no exige calidad de producción. Cita de productor: *"No necesitan estructura narrativa de nivel cine. Emoción entregada de forma directa: eso cumple el estándar."*
> ⚠️ **Lo que NO tengo:** un título concreto que pruebe este arquetipo. El hit chino de 1.000M de reproducciones que suele citarse (`家里家外`, Hongguo 2025) es en realidad **un drama de época en dialecto sichuanés sobre una familia reconstituida en los años ochenta** — no trata de abandono filial. Lo retiro como evidencia.
> **Conclusión honesta:** la demanda está validada, la oferta occidental no existe, y la prueba por título tampoco. Es una **apuesta informada**, no una certeza. Prodúcela como piloto de 5 Partes antes de comprometer más.

**Adaptación:** **Ham Wol-sun**, 71, vendió su casa para pagar la clínica de su nuera. Sus dos hijos la internan en una residencia de las afueras "por un mes". Pasan dos años. Lo que no saben: el terreno donde está construida la fábrica familiar sigue escriturado a su nombre, y la renta de ese terreno se ha estado acumulando en una cuenta que solo ella firma.

| # | Avanza | Cliffhanger |
|---|---|---|
| 1 | La internan "por un mes"; empaca poco para no molestar | Pasan cuatro meses sin una sola visita (**deadline**) |
| 2 | Descubre por otra interna que sus hijos vendieron su casa | Le llega por correo un estado de cuenta a su nombre (**revelación**) |
| 3 | Los hijos aparecen con papeles: necesitan su firma para un préstamo | Wol-sun pide leerlos y ellos se los quitan de las manos (**intrusión**) |
| 4 | Con la renta acumulada, paga la residencia de otras tres internas | El banco rechaza el préstamo: el aval no era de los hijos (**reversal**) |
| 5 | Los hijos llegan a rogar; los recibe en la sala común, delante de todas | Les ofrece una habitación en el asilo (**revelación**) |

**Gancho:** *Mis hijos me internaron "por un mes". Ese terreno seguía a mi nombre.*

---

### M4. EL HIJO ENFERMO COMO MONEDA DE CAMBIO ★ALTO

**Premisa:** Madre sin recursos, hijo que necesita una operación. Quien puede pagarla acepta con una condición: que renuncie a algo que no debería tener precio.

**Mecanismo:** El chantaje más cruel posible porque **no tiene salida buena**. La audiencia no puede resolverlo mentalmente, y eso la retiene. Niño en pantalla + reloj biológico.

**Señal:** `Mommy, It Hurts… Where's Daddy?` (FlareFlow) **atrajo a más del 40% de los usuarios activos existentes en días**, con tasas de finalización sobre la media **[AUTO — cifra de COL Group vía Variety y ContentAsia, no auditada por tercero]**. Llevó a FlareFlow al Top 5 de entretenimiento en Google Play EE.UU.
En español ya existe y validado por un gigante: `¡Mamá, No Me Dejes Morir!` — **ViX MicrO (TelevisaUnivision), 71 capítulos**, uno de los 7 títulos de lanzamiento **[AUTO — Univision no publicó cifra]**.

**Adaptación (deliberadamente distinta del título de ViX: aquí el chantajista es la EMPRESA, no la suegra):** **Noh Eun-ji**, 29, cajera. Su hijo **Noh Ha-neul**, 5, necesita una cirugía cardíaca. La aseguradora se la niega por una cláusula. La empresa que la despidió embarazada ofrece pagarla completa — a cambio de que firme que su despido fue voluntario y retire la demanda colectiva que **otras once mujeres** están sosteniendo con su testimonio.

| # | Avanza | Cliffhanger |
|---|---|---|
| 1 | La cirugía cuesta lo que gana en nueve años; la aseguradora dice no | El abogado de la empresa deja el cheque y el desistimiento en la misma mesa (**revelación**) |
| 2 | Firma. La cirugía sale bien | Las otras once pierden el caso el mismo día (**reversal**) |
| 3 | Una de ellas la busca a la salida del hospital | Le dice que su hija también estaba enferma (**intrusión**) |
| 4 | Eun-ji descubre que la cláusula de la aseguradora la redactó la misma empresa | Encuentra el nombre del médico que la firmó (**revelación**) |
| 5 | Devuelve el dinero vendiendo lo único que le queda y vuelve a declarar | La empresa ofrece el doble; ella pregunta cuánto vale su hijo (**deadline**) |

**Gancho:** *Pagaron la operación de mi hijo. A cambio pedían que traicionara a once mujeres.*

---

### M5. DOS MADRES, UN HIJO ★ALTO
> ⚠️ **Reescrito por completo.** La versión anterior de este arquetipo replicaba la secuencia específica del formato `Mother` (Nippon TV) —maestra suplente, fingir la muerte de la niña, fuga en tren, cacería mediática— que es **IP licenciada activamente**. Lo que sigue usa la mecánica de las dos madres **sin ninguno de esos dispositivos**.

**Premisa:** Una mujer cría durante años a un niño que no dio a luz — porque se lo dejaron, porque la madre no volvió, porque nadie más quiso. Cuando el niño ya la llama madre, **la biológica regresa con la ley de su lado y una razón que no se puede despreciar**. Ninguna de las dos está equivocada. Ese es el problema.

**Mecanismo:** El conflicto no tiene villana. La audiencia se ve obligada a elegir y no puede — y eso es exactamente lo que la retiene. Emoción: angustia + ternura + indignación repartida.

**Señal [IND en estructura]:** La mecánica de las dos madres es el motor materno más exportado del mundo. La hermana estructural `Kadın` (Turquía) se emitió en España como `Mujer` (Antena 3, 2020) con **datos Kantar reales [IND]**: estreno 1.406.000 espectadores / 12,8% share; **media de segunda temporada ~2,2 millones / 18%**; picos por encima del 20% y de 3 millones. Primera serie turca en prime time español; permitió a Atresmedia superar a Mediaset.

**Adaptación:** **Cha Yeon-ju**, 39, dueña de una lavandería, crió durante ocho años a **Im Ha-rin**, 9, que llegó con dos años y una bolsa de ropa. Nunca pudo adoptarla legalmente: le faltaba un requisito de ingresos. **Ku Se-yeong**, 31, la madre biológica, vuelve — no es un monstruo: estuvo tres años presa por encubrir a un hombre y quiere recuperar los años que le quitaron. Legalmente le asiste el derecho. Emocionalmente no le asiste nada.

| # | Avanza | Cliffhanger |
|---|---|---|
| 1 | Ocho años de una vida cotidiana que parece firme | Una mujer joven espera a la salida del colegio y la niña la mira dos segundos de más (**intrusión**) |
| 2 | Se-yeong no exige: pide. Y trae papeles en regla | Yeon-ju descubre que nunca completó la adopción (**revelación**) |
| 3 | Régimen de visitas; la niña vuelve cada vez más callada | Ha-rin le pide a Yeon-ju que deje de ir a buscarla (**reversal**) |
| 4 | Yeon-ju investiga por qué Se-yeong estuvo presa | Fue por proteger a la niña de su propio padre (**revelación**) |
| 5 | La audiencia; Yeon-ju puede hundirla con lo que sabe y no lo hace | La jueza pregunta a la niña, y la niña dice un solo nombre (**deadline**) |

**Gancho:** *Crié ocho años a una niña que no parí… Su madre volvió con papeles.*

---

### M6. EL BEBÉ ROBADO Y LA BÚSQUEDA DE DÉCADAS ★ALTO

**Premisa:** Parto en contexto de vulnerabilidad. Alguien sustituye o vende al bebé. A la madre le dicen que murió — a veces con tumba falsa. Salto de veinte años: las dos líneas viven en paralelo y se cruzan sin saberlo.

**Mecanismo:** Angustia de pérdida + esperanza obsesiva + la ironía dramática más potente que existe. Cada escena cotidiana se carga de tensión sin gastar trama.

**Señal [IND — la mejor curva documentada del catálogo]:** `Senhora do Destino` (Globo, 2004-05), IBOPE beat a beat: estreno 52 → **55 en el primer encuentro madre-hija** → **58 en la pelea con la villana** → pico 65 en el penúltimo capítulo.
Precedente fundacional: `El derecho de nacer` (radionovela cubana, Félix B. Caignet, 1948) — citada como récord de audiencia de su época y elegida en 2008 la telenovela más influyente de Latinoamérica **[cifra sin metodología publicada: trátala como señal histórica, no como dato]**.
Versión turca: `Paramparça` (2014-17), enfermera que cambia dos bebés porque los apellidos se parecían — móvil banal, no maligno, y por eso más creíble y más cruel. Lideró la temporada turca 2014/15; las cifras de exportación que circulan (+50 países) son **[AUTO — promocionales]**.

**Adaptación:** **Gwak Mi-ryeong**, 26, da a luz en un hospital de provincia durante un tifón. La enfermera **Pyo Sang-hee** entrega su hija a una familia que paga. Le dicen que nació muerta. Veintitrés años después, Mi-ryeong tiene un pequeño restaurante y contrata a una camarera nueva: **Pyo Chae-won**, 23 — la hija que la enfermera crió como propia.

| # | Avanza | Cliffhanger |
|---|---|---|
| 1 | El tifón, el parto, la tumba sin nombre | Veintitrés años después, una chica entra a pedir trabajo (**intrusión**) |
| 2 | Proximidad ignorante: la protege sin saber por qué, y se pelean | Mi-ryeong ve una marca de nacimiento que conoce (**revelación**) |
| 3 | Busca a la enfermera; la enfermera es la madre de la chica | La enfermera niega todo y desaparece esa noche (**deadline**) |
| 4 | La chica cree que Mi-ryeong quiere robarle a su madre | Chae-won se hace la prueba a escondidas **para desmentirla** (**reversal**) |
| 5 | La verdad en la mesa; la enfermera vuelve por su cuenta | La chica elige a quién llama madre (**revelación**) |

**Gancho:** *Me dijeron que mi hija nació muerta. Veintitrés años después me pidió trabajo.*

> 🎯 El ajuste de cuentas con la ladrona rinde más que el reencuentro (dato IBOPE). Que esté viva, presente y con una razón comprensible.

---

### M7. EL ÓRGANO NEGADO ★ALTO

**Premisa:** El progenitor que abandonó en la infancia —sin pensión, sin contacto— formó familia nueva. Décadas después enferma. Su familia contacta al hijo abandonado porque es el único compatible. El hijo se niega. Lo acusan de asesino por omisión.

**Mecanismo:** Indignación moral **sin ambigüedad**. El público no duda; el conflicto es puramente de castigo. Genera participación masiva: la audiencia va a *ejecutar la sentencia* en comentarios.

**Señal [VERIF — el techo de Reddit]:** **+18.000 upvotes** en r/AITAH, recogido por Newsweek (diciembre 2024). El comentario más celebrado es la idea de convertir el chantaje en una cifra: cuantificar los años impagados y ponerle precio al órgano. Hay versiones en TikTok y Facebook con el mismo esqueleto: retelling activo.

**Adaptación:** **Ju Hyun-woo**, 31, mecánico. A los seis años su padre **Ju Man-sik**, 60, se fue y nunca pagó una pensión. Ahora Man-sik necesita un trasplante y su hija nueva no es compatible. La madrastra busca a Hyun-woo. Su propia madre le pide que done, *"para que no cargues con esa culpa"*.

| # | Avanza | Cliffhanger |
|---|---|---|
| 1 | Una mujer desconocida entra a su taller con una carpeta médica | Es la esposa del padre que lo abandonó (**intrusión**) |
| 2 | La familia nueva lo corteja: cenas, regalos, una hermana que no sabía que tenía | Le piden la prueba de compatibilidad (**revelación**) |
| 3 | Es compatible. Su madre le pide que done | Hyun-woo pregunta cuánto vale un riñón (**reversal**) |
| 4 | Presenta la cuenta: doce años de pensión, con intereses | El padre acepta pagar (**deadline**) |
| 5 | El dinero llega. Se lo da íntegro a su madre y no dona | *"Mi padre me enseñó que uno no le debe nada a quien se fue"* (**revelación**) |

**Gancho:** *Mi padre me abandonó a los seis. A los treinta y uno vino por mi riñón.*

---

### M8. EL HIJO DESCARTADO QUE TRIUNFÓ ★ALTO
> *(golden child vs scapegoat + el fondo robado)*

**Premisa:** Dos hermanos, inversión parental radicalmente asimétrica — o directamente le desvían al despreciado el dinero de su educación. Salto de quince años: el favorito colapsa, el despreciado triunfa. Los padres siguen sin reconocerlo y ahora piden que sostenga al favorito.

**Mecanismo:** Vindicación **diferida** — venganza por acumulación de tiempo, no por acción. La más adictiva del catálogo: el espectador espera un momento concreto y sabe cuál es.

**Señal:** El eje del fondo robado tiene cifra: **+14.000 upvotes y ~6.500 comentarios** en r/AmItheAsshole **[VERIF]**. El eje del favoritismo no tiene cifra publicada **[SIN CIFRA]** pero sí señal editorial contundente: Bored Panda construyó **cuatro recopilaciones distintas** sobre el mismo tema. Caso relacionado: padre que le dice al hijo que "él no lo es todo en su vida" y años después pide ayuda → **13.300 upvotes en el post y 18.300 en el comentario top [VERIF]** — el comentario superó al post: el hilo se volvió un ritual de castigo colectivo.

**Adaptación:** **Ma Eun-seo**, 34, y su hermano **Ma Jun-yeong**, 31. Los padres pagaron la carrera de él con el dinero que la abuela dejó para ella. Ella entró a trabajar a los diecisiete. Hoy Eun-seo dirige un laboratorio; Jun-yeong lleva tres negocios quebrados y vive con los padres. Es el cumpleaños setenta del padre.

| # | Avanza | Cliffhanger |
|---|---|---|
| 1 | Cena de cumpleaños: la sientan lejos y sirven primero al hermano | Le piden que financie el cuarto negocio de él (**intrusión**) |
| 2 | Dice que no por primera vez en su vida | La madre le dice que la abuela habría querido que ayudara (**reversal**) |
| 3 | Eun-seo busca el testamento de la abuela | El dinero era suyo y estaba condicionado (**revelación**) |
| 4 | El hermano lo sabía desde los veinte años | Los padres le piden que no lo denuncie, por la familia (**reversal**) |
| 5 | Cobro en la siguiente cena, con los mismos invitados | Paga la cuenta completa y se va (**revelación**) |

**Gancho:** *Mis papás pagaron la carrera de mi hermano con la herencia que era mía.*

---

### M9. LA MADRE QUE VOLVIÓ DEMASIADO TARDE ◐MEDIO

**Premisa:** Una hija criada por otra mujer descubre de adulta que su madre biológica no solo está viva, sino que lleva años cerca — observándola sin decir nada. La hija tiene que decidir si quiere una explicación.

> ⚠️ **Ojo con el precedente.** La combinación específica "madre que entregó a su hija → empresaria de la moda → la contrata sin saber quién es" es de `Cristal` (Delia Fiallo, RCTV 1985) y sus versiones licenciadas `El privilegio de amar` (1998) y `Los hilos del pasado` (2025) — **la misma obra bajo licencia, no tres apariciones de un arquetipo libre**. La versión de abajo **invierte el punto de vista** (narra la hija, no la madre) y elimina el dispositivo de la contratación.

**Mecanismo:** Culpa + anhelo. El arquetipo más adulto del catálogo. **La fase de rechazo es obligatoria**: si la hija perdona rápido, se desinfla.

**Señal:** El motor sigue vigente: TelevisaUnivision estrenó una versión nueva de este esqueleto en 2025, cuarenta años después de la original. Ninguna de las cifras de rating que circulan sobre estas obras tiene metodología publicada **[AUTO]**.

**Adaptación:** **Sim Da-yeon**, 28, jefa de cocina, criada por **Wi Bun-hui**, 64, que la recogió a los tres años y jamás mintió sobre ello. Una clienta habitual del restaurante lleva dos años pidiendo siempre la misma mesa: **Jo Hye-rin**, 47. Da-yeon descubre por qué.

| # | Avanza | Cliffhanger |
|---|---|---|
| 1 | La clienta de la mesa siete deja una propina imposible | Da-yeon la ve llorando en el coche (**intrusión**) |
| 2 | Investiga y encuentra su propio nombre en un expediente | El apellido de la clienta está en la primera línea (**revelación**) |
| 3 | La confronta; Hye-rin no niega nada y eso es peor | Da-yeon le prohíbe volver al restaurante (**reversal**) |
| 4 | Bun-hui, la que la crió, defiende a Hye-rin | Le entrega las cartas que Hye-rin mandó veinticinco años (**revelación**) |
| 5 | Da-yeon le reserva la mesa siete y se sienta enfrente | Le pregunta cuántas veces estuvo a punto de entrar (**deadline**) |

**Gancho:** *Mi madre me abandonó a los tres años… Llevaba dos comiendo en mi restaurante.*

---

### M10. EL PADRE RICO DISFRAZADO DE POBRE ◐MEDIO

**Premisa:** Padre o madre con fortuna se presenta con ropa humilde en el mundo del hijo para ver cómo lo tratan. Lo humillan. Entonces revela quién es.

**Mecanismo:** Circulación orgánica masiva — hay clips en TikTok y YouTube en indonesio, francés, español y coreano con la misma estructura. Funciona porque el espectador está en el secreto desde el segundo cero: puro placer de anticipación.

**Señal [AUTO]:** `The Security Guard is a Trillionaire` (China, julio 2024): un joven emprendedor se topa con su padre "guardia de seguridad" en un evento de alto nivel y siente vergüenza. `Divorce Me? Bow to My Billionaire Daughter!` fue **#1 de FlareFlow** la semana del 16 de julio de 2026. En español existe la variante invertida: `Mi Herencia Huele a Pobre` (ViX MicrO, 37 capítulos).

**Adaptación:** **Yang Ki-cheol**, 66, llega en autobús a la boda de su hijo con su único traje bueno, que tiene doce años. Los consuegros lo mandan a la mesa del fondo y le piden que no salga en las fotos. Ki-cheol es el dueño del grupo que está a punto de comprar la empresa del consuegro.

| # | Avanza | Cliffhanger |
|---|---|---|
| 1 | La humillación en la boda: la mesa del fondo, las fotos | El fotógrafo lo saluda por su nombre completo y con título (**revelación**) |
| 2 | El hijo elige el silencio para no incomodar a su suegro | Ki-cheol cancela su propio regalo de bodas (**reversal**) |
| 3 | El consuegro pide un préstamo a un fondo sin saber de quién es | La reunión la preside Ki-cheol (**intrusión**) |
| 4 | La compra se firma; el hijo se entera por la prensa | El consuegro le exige al hijo que interceda con su padre (**reversal**) |
| 5 | Primer aniversario, mismo salón, mismas mesas | Ki-cheol entra con el mismo traje de doce años (**revelación**) |

**Gancho:** *Me sentaron atrás en la boda de mi hijo… Yo iba a comprar su empresa.*

---

### M11. EL QUE CRIÓ CONTRA EL QUE FIRMÓ ◐MEDIO

**Premisa:** Un adulto —padrastro, madrastra, tío, abuela— hizo la crianza real durante veinte años. Llega la boda. El progenitor biológico, ausente todo ese tiempo, reclama el lugar en la ceremonia por derecho de sangre.

**Mecanismo:** **El único arquetipo del catálogo con versión luminosa que rinde igual o más que la oscura** — valioso para diversificar un canal que si no se vuelve todo veneno.

**Señal:** La versión oscura tiene ~4.700 upvotes en r/AmItheAsshole **[VERIF con matiz: el propio Newsweek llama estimada a la cifra]**. Pero la versión **positiva** —padre biológico que invita al padrastro a caminar juntos— alcanzó **6,9 millones de visualizaciones y 1,3 millones de likes en TikTok** [cifra citada por Newsweek]. La ternura escaló más que la indignación.

**Adaptación:** **Baek Sang-cheol**, 55, crió a **Baek Se-eun**, 26, desde los cinco años. El padre biológico, **Ko Man-seok**, 57, aparece dos meses antes de la boda con un abogado y una lista de exigencias.

| # | Avanza | Cliffhanger |
|---|---|---|
| 1 | El biológico reaparece y la familia se divide | Trae un documento que Sang-cheol nunca firmó (**intrusión**) |
| 2 | Sang-cheol se aparta para no incomodarla | Se-eun lo encuentra devolviendo el traje que había alquilado (**revelación**) |
| 3 | Se-eun descubre por qué el biológico volvió | Está enfermo y necesita algo (**reversal**) |
| 4 | Man-seok se delata solo delante de la familia | Se-eun decide invitarlo igual (**revelación**) |
| 5 | La boda: los dos caminan con ella | El biológico le cede el brazo al que la crió (**deadline**) |

**Gancho:** *Mi papá me crió veinte años. El biológico llegó dos meses antes de la boda.*
*(14 palabras.)*

---

### M12. LA MATRIARCA QUE DESTRUYE A SUS PROPIOS HIJOS ◐MEDIO

**Premisa:** Matriarca que controla patrimonio, apellido y narrativa familiar. Tiene un hijo favorito y uno sacrificable — esa asimetría es el motor completo. Y una mentira que sostiene todo.

**Mecanismo:** Fascinación + odio. El único arquetipo donde el público **disfruta** al antagonista. Requisito no negociable: la villana debe ser **carismática y elegante, no repulsiva**. Debe dar envidia antes de dar asco.

**Señal:** `Cuna de lobos` (Televisa, 1986-87, 170 capítulos): el 5 de junio de 1987 México se paralizó con el final. **⚠️ Cuidado con la cifra:** circula "casi 100 puntos de rating" — el propio canal propietario publica un artículo titulado *"Conoce el mito que rodea el final de Cuna de Lobos"* **[LEYENDA]**. La cifra citada a Excélsior es **73 puntos**: usa esa.
Vigencia: el remake de `La madrastra` (2022) estrenó con **3,1 millones de espectadores y 174% más audiencia que su competencia [IND — Nielsen IBOPE México]**. Diecisiete años después, el mismo esqueleto sigue liderando TV abierta mexicana.

> ⚠️ **Dos avisos.** (1) Ya usaste una matriarca villana en `medula_prestada` — el diferencial aquí debe ser que las víctimas sean **sus propios hijos**, no la nuera. (2) El par "discapacidad física fingida durante años + el marido no murió de lo que dijeron" es la **firma reconocible de Catalina Creel**, e IP viva (Televisa la remakeó en 2019). La versión de abajo cambia el mecanismo de la mentira: no hay enfermedad fingida, hay una **sucesión falsificada**.

**Adaptación:** **Yeo Sang-ok**, 63, presidenta de una firma de cosmética. Anuncia que se retira y que dividirá la empresa entre sus dos hijos según lo que cada uno consiga en un año. Lo que ninguno sabe: la empresa ya está vendida desde hace ocho meses, la competencia es teatro, y el año no es una prueba — es el plazo que necesita para que uno de los dos cargue con una deuda que ella firmó a su nombre.

| # | Avanza | Cliffhanger |
|---|---|---|
| 1 | Anuncia la competencia entre sus dos hijos delante del consejo | El hijo menor encuentra su firma en un contrato que nunca vio (**revelación**) |
| 2 | Los hermanos empiezan a destruirse entre ellos | La madre financia en secreto al que va perdiendo (**reversal**) |
| 3 | El mayor descubre que la empresa ya no es de la familia | La compradora es una sociedad con el apellido de la madre (**revelación**) |
| 4 | Los dos hermanos se alían por primera vez en su vida | Ella les enseña por qué eso también estaba previsto (**intrusión**) |
| 5 | Consejo final: uno de los dos tiene que firmar la deuda | El menor pregunta cuál de los dos fue el sacrificable desde el principio (**deadline**) |

**Gancho:** *Mi madre puso a sus dos hijos a competir. La empresa ya estaba vendida.*

---

## 4. TABLA DE PRIORIZACIÓN

**Las etiquetas de calidad de evidencia se conservan aquí a propósito** — es la sección que más se usa para decidir.

| # | Arquetipo | Fuerza de la señal | Hueco en español | Prioridad |
|---|---|---|---|---|
| M1 | El hijo que eligió al padre rico | 🟢🟢🟢 **47,6% [IND]** del arquetipo hermano + tu propio dato de canal | **Tuyo. El verbo "eligió" casi nadie lo usa** | **MÁXIMA** |
| M6 | El bebé robado | 🟢🟢🟢 Curva **IBOPE beat a beat [IND]** + versión turca exportada | Medio | **MÁXIMA** |
| M5 | Dos madres, un hijo | 🟢🟢🟢 Datos **Kantar España [IND]** de la hermana estructural | Alto | **MÁXIMA** |
| M2 | Madre humillada que era la dueña | 🟢🟢 Dos plataformas rivales clonaron la estructura **[AUTO]** | Alto | ALTA |
| M7 | El órgano negado | 🟢🟢 18.000 upvotes **[VERIF]** = el techo real de Reddit | Alto | ALTA |
| M8 | El hijo descartado que triunfó | 🟢🟢 14.000 upvotes **[VERIF]** + 4 recopilaciones editoriales | Medio | ALTA |
| M4 | Hijo enfermo / moneda de cambio | 🟢🟢 >40% usuarios activos, pero **[AUTO]** no auditado | Medio (ViX ya tiene uno) | ALTA |
| M3 | Padres abandonados en la vejez | 🟢🟢 Demografía y economía **[IND]**, pero **sin título que pruebe el arquetipo** | **Enorme** | ALTA *(apuesta informada)* |
| M12 | Matriarca que destruye a sus hijos | 🟢🟢 73 puntos + remake con **+174% [IND]** en 2022 | Bajo (ya lo usaste) | MEDIA |
| M10 | Padre rico disfrazado de pobre | 🟢🟢 Circulación orgánica en 5+ idiomas | Medio | MEDIA |
| M11 | El que crió vs el que firmó | 🟢 6,9M de vistas en la **versión luminosa** | Alto | MEDIA |
| M9 | La madre que volvió tarde | 🟢 Motor reciclado por Televisa 1985→1998→2025 **(bajo licencia)** | Medio | MEDIA |

---

## 5. REGLAS DE PRODUCCIÓN DEL FORMATO (fuente primaria de plataforma)

1. **Cliffhanger dentro de los tres primeros episodios de un minuto.** — Joey Jia, CEO de ReelShort, a Rolling Stone: *"Si no sigues esta fórmula específica, fracasarás."* Contexto: ReelShort fracasó al lanzarse en EE.UU. en 2022 por *"centrarse demasiado en el arco de personaje e ignorar lo que la gente realmente buscaba"*.
2. **Ciclo completo de tres actos cada 90 segundos.** — DramaBox.
3. **Cada plano es esencialmente un primer plano. Máximo tres personas en cuadro. La emoción es el motor, no la trama.** — DramaBox.
4. **Descubrimiento en redes, consumo en la app.** — ViX MicrO publica tráiler + primeros 5 episodios en YouTube, Instagram, TikTok y Facebook como embudo.
5. **Cuando el niño es la palanca, titula en la voz del niño dirigiéndose al adulto**, no en la voz del adulto. Ese patrón atraviesa FlareFlow, DramaBox, ReelShort y ViX simultáneamente.

**La máquina del género familiar, en una frase (Sixth Tone):**
> El placer no es la venganza en sí, sino que **el protagonista usa recursos enormes para resolver el problema de la falta de piedad filial**. La humillación se paga con poder revelado, no con violencia.

---

## 6. FÓRMULA DE TITULACIÓN DEL NICHO HISPANO

Extraída de ~45 títulos reales verificados en el nicho (2026).

### Estructura canónica: triple movimiento
```
[AGRAVIO en 1ª persona + testigo público] … [BISAGRA] [VINDICACIÓN NO RESUELTA]
```
Casi ningún título que funciona se queda en el agravio. **Todos prometen el giro y lo dejan abierto.**

**Verbo del agravio** (pretérito perfecto simple):
`humilló · me echó · me excluyó · se avergonzó de · me dejaron · me internaron · abandonó · se rió de mí · prefirieron · **eligió** ←tu ventaja`

**Testigo público** (el agravio nunca es privado):
`frente a toda la familia · delante de todos · a los trescientos invitados · en plena fiesta`

**Escenario ritual** (siempre una ceremonia de pertenencia):
`boda · cumpleaños · Navidad · graduación · cena familiar · asilo · lectura del testamento`

**Bisagras de giro** (funcionan literalmente):
`… Entonces hice algo que nunca va a olvidar` · `… Así que tomé una decisión.` · `… pero no sabía lo que yo guardaba…` · `… Dos años después supieron la verdad` · `… su arrepentimiento los devora`

**Recursos del nicho que casi nadie usa bien** — explótalos:
- **Elipsis `…` como bisagra** — está en ~70% de los títulos del nicho. Es la marca del género. *(Los doce ganchos de §3 la usan ahora.)*
- **El insulto literal entre comillas al inicio** — `"Ahí estarás mejor"`, `"No vengas a la boda"`. Muy fuerte y subexplotado.
- **Mayúsculas selectivas** en la palabra emocional.
- **Primera persona posesiva al inicio**: `Mi nuera… / Mis hijos… / Mi hijo…`

---

## 7. RIESGOS Y CAVEATS

- **Cifras de plataformas de microdrama: no auditadas.** Señal relativa de qué fórmula funciona, nunca verdad.
- **Reddit no es fuente de alcance, es fuente de arquetipos.** Techo ~18.000 upvotes en post. Su valor es la densidad de indignación moral.
- **Subreddits de riesgo:** r/AmITheJerk y r/AITAH concentran los casos más espectaculares y también los más probablemente ficticios (varios acusados de ser IA en sus propios comentarios). r/AmItheAsshole es el más fiable.
- **Saturación de IA — el riesgo es el algoritmo, no la audiencia.** Purga de YouTube en enero de 2026 sobre canales de 5-6M de suscriptores; **reducción de distribución**, no solo de monetización. Verifiqué el mismo título clonado en 5+ videos, más versiones en portugués y francés del mismo guion. **Lo que penalizan es repetitivo y sin valor añadido.**
- **No repitas tu propia estructura.** En este catálogo las secuencias de cliffhanger están deliberadamente variadas y **los finales de Parte 5 alternan entre revelación y deadline**. Si produces cuatro series seguidas con la misma secuencia de tipos, te expones al mismo filtro que caza a las granjas.
- **Higiene defensiva:** varios canales del nicho ya incluyen disclaimer visible tipo *"dramatizaciones ficticias, contenido generado digitalmente"*. Cópialo.
- **Sensibilidad de contenido:** M4 (niño enfermo) y M5 (custodia disputada) son los de mayor riesgo de moderación. Violencia **fuera de cuadro** y sufrimiento del niño **sugerido, no explícito**.
- **Riesgo de IP — lo más importante de esta sección.** Tres arquetipos tienen precedentes que son **formatos licenciados activamente**, no folclore libre:
  - **`Mother` / `Anne`** (Nippon TV, 11 adaptaciones oficiales) → no reproduzcas: maestra suplente + fingir la muerte de la niña + fuga en tren + cacería mediática. M5 se reescribió para evitarlo.
  - **`Cristal` / `El privilegio de amar` / `Los hilos del pasado`** (Delia Fiallo, TelevisaUnivision) → no reproduzcas: madre que entregó a su hija + empresaria de la moda + la contrata sin saber quién es. M9 se reescribió para evitarlo.
  - **`Cuna de lobos`** (Televisa, remake 2019) → no reproduzcas: discapacidad física fingida durante años + el marido no murió de lo que dijeron. M12 se reescribió para evitarlo.
  La mecánica general de un arquetipo es libre. **La combinación específica de dispositivos de una obra concreta, no.**
- **No copiar, adaptar.** Todas las semillas están reducidas a arquetipo. Los nombres coreanos propuestos son originales y verificados contra colisiones con figuras públicas.

---

## 8. FUENTES PRINCIPALES

**Medición independiente [IND]:**
- Sensor Tower, *State of Short Drama Apps 2026* — https://sensortower.com/blog/state-of-short-drama-apps-2026-report
- Deloitte TMT Predictions 2026 — https://www.deloitte.com/us/en/insights/industry/technology/technology-media-and-telecom-predictions/2026/short-form-video-series.html
- AppsFlyer vía Expansión (México +170%) — https://expansion.mx/tecnologia/2026/04/10/telenovelas-de-frutas-microdramas-crecen-170-en-mexico-y-redefinen-el-negocio-del-streaming
- Hub Research, *Video Redefined* (41% hispanos EE.UU.) vía Señal News — https://senalnews.com/en/data/microdramas-emerge-as-a-high-growth-strategic-frontier
- Sensor Tower vía ppc.land (LATAM: 23% de descargas globales; +913% instalaciones Q1 2026) — https://ppc.land/reelshort-beats-netflix-daily-time-with-short-drama-installs-up-913-in-latam/
- iResearch / QuestMobile vía Sixth Tone (audiencia mayor china) — https://www.sixthtone.com/news/1016167
- DataEye / CIW (310M de chinos 60+, economía del ultracorto) — https://www.ciw.news/p/how-ai-and-elderly-demographics-created
- `Mujer` en Antena 3, datos Kantar — https://ecoteuve.eleconomista.es/series/noticias/10759902/09/20/Que-esta-pasando-con-Mujer-las-claves-y-las-cifras-del-fenomeno-turco-de-Antena-3.html
- `Seoyoung, My Daughter`, 47,6% AGB Nielsen — https://en.wikipedia.org/wiki/Seoyoung,_My_Daughter
- `Senhora do Destino`, IBOPE beat a beat — https://en.wikipedia.org/wiki/Senhora_do_Destino
- `La madrastra` 2022, +174% Nielsen IBOPE — https://eltiempolatino.com/2022/08/22/cultura/nueva-version-de-la-madrastra-arrasa-en-audiencia-en-su-estreno/

**Plataformas [AUTO]:**
- Rolling Stone / ReelShort (la regla de los tres episodios) — https://www.rollingstone.com/culture/culture-features/vertical-short-industry-hollywood-reelshort-dramabox-1235009933/
- Variety / FlareFlow (>40% usuarios activos; Top 5 Google Play EE.UU.) — https://variety.com/2025/tv/news/microdrama-flareflow-us-top-5-entertainment-apps-1236505761/
- ContentAsia / COL Group — https://www.contentasia.tv/news/col-group-ups-flareflow-microdrama-production-180-series-2026-80-leap-originals-could-mean-est
- PRODU / DramaBox LATAM — https://www.produ.com/ushispanic/noticias/dramabox-expands-its-presence-in-latam-to-produce-more-than-20-locally-adapted-vertical-microdramas-in-mexico-colombia-and-brazil-in-2026/
- Forbes / ViX MicrO — https://www.forbes.com/sites/veronicavillafane/2026/03/31/televisaunivision-bets-its-telenovela-dna-can-win-the-microdrama-race/
- NPR / Crazy Maple (la versión en español logró casi la mitad de las vistas del original) — https://www.npr.org/2025/03/19/nx-s1-5330470/micro-drama-soap-opera-app
- DramaBox, `Think Again! I'm the Hidden Boss Mom` — https://www.dramabox.com/drama/42000010883/Think-Again-Im-the-Hidden-Boss-Mom

**Reddit [VERIF]:**
- Riñón negado al padre ausente, +18.000 upvotes — https://www.newsweek.com/woman-backed-refusing-kidney-donation-father-reddit-1998442
- Fondo universitario robado, +14.000 upvotes — https://www.newsweek.com/reddit-son-demands-college-fund-christmas-gift-1761624
- Padre que reaparece pidiendo ayuda, 13.300 / 18.300 — https://www.newsweek.com/father-son-estranged-broken-relationship-reddit-viral-1775716
- Padrastro vs biológico, versión luminosa 6,9M en TikTok — https://www.newsweek.com/dad-asks-daughter-stepfather-join-walk-down-aisle-emotional-video-viral-tiktok-1645397

**Contexto de formato e IP:**
- Variety, la mecánica de las dos madres y el formato `Mother` — https://variety.com/2023/tv/festivals/nippon-tv-mother-atresmedia-heridas-1235563538/
- C21Media, las 11 adaptaciones de `Mother` — https://www.c21media.net/news/nippon-tv-targets-more-remakes-for-female-led-drama-formats-after-success-of-mother/
- TelevisaUnivision: `Los hilos del pasado` es la nueva versión de `El privilegio de amar`, basada en `Cristal` — https://corporate.televisaunivision.com/press/2025/09/25/vix-anuncia-el-estreno-en-mexico-de-los-hilos-del-pasado-la-nueva-version-de-el-privilegio-de-amar/
- Las Estrellas: el mito del final de `Cuna de lobos` — https://www.lasestrellas.tv/telenovelas/cuna-de-lobos/conoce-el-mito-que-rodea-el-final-de-cuna-de-lobos-de-los-80
- SCMP: `家里家外` es un drama de época en dialecto sichuanés — https://www.scmp.com/economy/china-economy/article/3303344/chinas-hottest-new-show-sichuan-dialect-micro-drama-set-1980s

**Saturación de IA:**
- Purga de YouTube, enero 2026 — https://www.excelsior.com.mx/tecnologia/youtube-elimina-canales-ia-baja-calidad
- Frutinovelas IA, 30M de reproducciones en una semana — https://www.infobae.com/tendencias/2026/04/03/frutinovelas-con-ia-el-fenomeno-viral-que-acumula-millones-de-vistas-y-generan-polemica-en-redes/

---

## 9. REGISTRO DE CORRECCIONES (v1 → v2)

Este documento pasó por una verificación adversarial. Lo que cambió y por qué:

**Críticas:**
1. **M5 reescrito por completo.** La versión anterior replicaba ~8 dispositivos consecutivos del formato `Mother` de Nippon TV, que se licencia territorio por territorio. Se sustituyó por una mecánica de dos madres sin ninguno de esos elementos.
2. **`家里家外` retirado como prueba de M3.** Es un drama de época en dialecto sichuanés sobre una familia reconstituida en los años ochenta, no una historia de abandono filial. El dato de 1.000M de reproducciones es real pero pertenece a otro arquetipo. M3 baja de MÁXIMA a ALTA (apuesta informada).
3. **"Yoon Do-hyun" eliminado.** Es el vocalista de YB, una de las bandas de rock más conocidas de Corea. Renombrado **Yoon Tae-o**.

**Nombres corregidos por colisión o registro:** Yang Deok-su → **Yang Ki-cheol** (evita *Squid Game*); Bae Su-jin → **Pyo Sang-hee** (evita Suzy); Seo Young-ae → **Ham Wol-sun**; Im Da-som → **Im Ha-rin**; Cha So-hee → **Cha Yeon-ju**; Ko Jin-pyo → **Ko Man-seok**; Baek Yu-mi → **Baek Se-eun**; Yeo Chun-ja → **Yeo Sang-ok** (registro elegante, no rural); Yoon Mi-sook, 44 → **Yoon Ji-young**, 44 (los nombres en *-sook* marcan cohorte de 1930-1960).

**Coherencia y lógica:** M1 "veinte años de pensión" para un hijo de 17 → **diecisiete**; M7 "veinticinco años" → **doce** (la obligación termina hacia los 18); M2 el gancho decía "nuera" y la villana era la consuegra → alineado, y la compra del hotel ahora es **a través de una sociedad**, no a nombre de un muerto; M3 el activo oculto y la renta ahora son consistentes entre Partes; M1 se eliminó el subtrama de compatibilidad sanguínea que duplicaba M7.

**Ganchos:** M11 pasó de 17 a 14 palabras; M9 se reescribió para que la narradora sea la víctima, no quien ejecuta el abandono; M10 dejó de quedarse en el agravio y ahora promete la vindicación; **los doce llevan ahora la elipsis** que §6 identifica como marca del género; el gancho oficial de M1 se actualizó a la versión triple.

**Cliffhangers:** reetiquetados (se usaba "deadline" como comodín donde no había reloj); resueltas las repeticiones consecutivas latentes en M2, M6 y M7; **añadido corte de 5 Partes a M12** y tipos a M9, M10 y M11; los finales de Parte 5 ya no son todos "revelación".

**Etiquetas restauradas** en el TL;DR y en la tabla §4, que era donde más falta hacían. Retiradas las etiquetas ad-hoc fuera de la taxonomía.

**Riesgo de IP señalado explícitamente** para `Mother`, `Cristal` y `Cuna de lobos` en §7, y M4 se diferenció del título de ViX (el chantajista pasó de la suegra a la empresa).

**Precisiones:** `Paramparça` "+50 países" ahora marcado [AUTO]; corregida la descripción de la serie china de M2; retirada la "contradicción" del tamaño de mercado (es diferencia metodológica); acotado el Top 5 de FlareFlow a Google Play EE.UU.
