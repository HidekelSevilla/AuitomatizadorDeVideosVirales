# Catálogo de Historias Virales → Adaptaciones para Novela Coreana Melodramática Faceless (shuangwen vertical, es-MX)

## TL;DR
- Se identificaron ~40 arquetipos virales cruzados (Reddit + microdramas verticales chinos + dizi turco + telenovela + K-drama makjang), todos reducibles a la misma columna vertebral que pide tu preset: mujer agraviada/subestimada → secreto o poder oculto → vindicación satisfactoria por partes; los de mayor potencial son "esposa despreciada = heredera secreta", "ADN/hijo oculto que estalla la familia" y "suegra tiránica humillada".
- El motor de viralidad es medible y replicable: brecha de información (Loewenstein 1994) que abre el gancho + emoción de alta activación (indignación/asombro; Berger & Milkman, *Journal of Marketing Research* 49(2):192-205, abril 2012, que estudió la viralidad de casi 7,000 artículos del *New York Times* durante tres meses) que impulsa el compartir; el shuangwen añade el "face-slapping" (el que humilló termina humillado) como recompensa dopaminérgica.
- Recomendación operativa: producir en tandas de 6-8 partes de 60-90 s con cliffhanger de revelación al final de cada parte, priorizar los 10 arquetipos marcados como ★ALTO, y clonar los títulos-fórmula ya probados por ReelShort/DramaBox (según Omdia, comunicado del 23-feb-2026 en MIP London, los ingresos globales de microdrama llegaron a $11 mil millones en 2025 y crecerán a $14 mil millones para fines de 2026, con $3 mil millones generados fuera de China y EE.UU. ya como el mayor mercado internacional).

## Key Findings

**1. Todo se reduce a una sola arquitectura.** Reddit (AITA/ProRevenge/JUSTNOMIL/BORU), los microdramas verticales chinos (duanju), el dizi turco, la telenovela latina y el makjang coreano son variaciones de la misma máquina: protagonista agraviada → información oculta → reversión de poder → castigo público del villano. Tu preset "novela-coreana" ya está calibrado para esto; el trabajo es elegir la semilla y cortarla por partes.

**2. Los microdramas verticales son la fuente MÁS calzada.** El formato 9:16, episodios de 60-120 s, gancho en los primeros 3 segundos, twist y cliffhanger por episodio es idéntico al tuyo. Según Omdia (feb-2026), los microdramas duran "típicamente uno a dos minutos por episodio", su núcleo de audiencia son "mujeres de 25 a 50 años" y el descubrimiento está "impulsado principalmente por YouTube, Instagram y TikTok" —exactamente tu canal de distribución y tu target. ByteDance (Hongguo) clasifica los duanju en temas que son literalmente tu catálogo: "revenge takedowns", "secret identity", "elite family feuds", "switched-at-birth heiress".

**3. El mecanismo psicológico es medible.** La brecha de información de Loewenstein (1994) explica el clic: se abre una pregunta que "duele" no responder. Berger & Milkman (2012) muestran que las emociones de alta activación —ira, ansiedad, asombro— se comparten más; la tristeza (baja activación) se comparte menos, incluso controlando por cuán sorprendente, interesante o útil es el contenido. Traducción para tu guion: nunca cerrar una parte en tristeza pura; cerrar en indignación ("¿cómo se atreve?"), en asombro ("resultó ser…") o en la pregunta abierta ("lo que encontró en el testamento cambió todo").

**4. El shuangwen (爽文) es la capa de recompensa.** "Fantasía de satisfacción": humillación inicial → acumulación de agravios → face-slapping (打脸) donde cada villano recibe su castigo en público, de preferencia frente a quienes despreciaron a la protagonista. Novelupdates y las reseñas de duanju confirman que el placer viral viene de la reversión de estatus ("de cannon fodder / desechada a la que manda"). The Dial documenta que en las plataformas chinas los protagonistas pobres "ascienden a las altas esferas o revelan que eran secretamente ricos desde el principio".

**5. Señales de viralidad concretas (para priorizar).**
- **ReelShort (vistas autoreportadas):** "The Double Life of My Billionaire Husband" ~450-500M vistas (inglés); su versión en español alcanzó casi la mitad de esas vistas (NPR). "True Heiress vs. Fake Queen Bee" 395.2M; "Found A Homeless Billionaire Husband for Christmas" 391.1M; "How to Tame a Silver Fox" 382.3M (cifras de ReelShort vía ContentAsia/Real Reel). "Bound by Honor" 373M (93 episodios). "Miss You After Goodbye" logró el raro #1 simultáneo en ReelShort y DramaBox. "The Long-lost Heiress's Return" era #1 de DramaBox y "Divorce Me? Bow to My Billionaire Daughter!" #1 de FlareFlow a mediados de julio 2026 (verticaldrama.tv).
- **Escala del sector:** ReelShort creció de ~$36M de ingresos en 2023 a ~$1.2 mil millones de gasto bruto de consumidor en 2025 (datos de Appfigures publicados por Business Insider y TechBuzz, febrero 2026). Según Sensor Tower (*State of Short Drama Apps 2025*), en el Q1 2025 ReelShort y DramaBox facturaron $130M y $120M en compras in-app (+31% y +29%), los puestos #1 y #2, juntos "aproximadamente el 70% del gasto in-app global de short-drama en el Q1 2025".
- **Dizi turco:** según el Ministerio de Cultura turco (vía AFP/Turkish Minute, 11-mar-2024), "casi 700 millones de espectadores disfrutan de las telenovelas 'alla turca'" y Turquía es "el segundo mayor exportador de series, solo detrás de Estados Unidos, a casi 170 países". "The Girl Named Feriha" exportada a 70+ países; "Magnificent Century" estimada en 500M+ personas; "Kara Sevda" fue la primera serie turca en ganar un Emmy Internacional (Mejor Telenovela).
- **Reddit:** las historias de melodrama en texto rara vez superan las decenas de miles de upvotes dentro de su subreddit (el liderazgo all-time de Reddit son imágenes de r/pics/r/funny). Usar Reddit por su densidad de arquetipos y "moral outrage", no por cifras masivas.

## Details — Catálogo por categoría

Formato de cada semilla: **Premisa viral** → **Gancho/mecanismo** → **Señal de viralidad** → **Trama adaptada al preset** → **Corte por partes** → **Gancho clickbait honesto**. Prioridad: ★ALTO / ◐MEDIO.

---

### CATEGORÍA A — Esposa despreciada = heredera/genio secreta (★ el arquetipo más rentable)

**A1. "Nunca te divorcies de una heredera secreta" ★ALTO**
- Premisa: esposa tratada como sirvienta/"banco de sangre" durante 3 años por marido y suegra; se divorcia y se revela como heredera multimillonaria.
- Mecanismo: brecha de información (¿quién es ella realmente?) + indignación por el maltrato + face-slapping máximo al divorcio. Es la fórmula insignia de ReelShort ("Never Divorce a Secret Billionaire Heiress", 55 episodios: la esposa es el "banco de sangre" del marido 3 años, se divorcia y se revela heredera).
- Señal: título-fórmula repetido algorítmicamente por ReelShort (junto a "The Double Life of My Billionaire Husband" y "Snatched a Billionaire To Be My Husband", según reconoció su ejecutivo Joey Jia a Rolling Stone: los guiones se generan por lo que ya funcionó).
- Adaptación: Ji-won soporta 3 años de desprecio de su suegra Madam Oh y de su esposo Tae-ho, que la humilla frente a su amante. El día que firma el divorcio, el conglomerado que su esposo intenta comprar resulta ser de su familia; ella es la heredera oculta que había renunciado a su apellido por amor.
- Partes: P1 termina cuando el esposo le exige el divorcio frente a la amante. P2 cuando el abogado del conglomerado la llama "señorita presidenta". P3 cuando la suegra descubre a quién estuvo humillando. P4: la vindicación pública en la junta directiva.
- Clickbait honesto: "Me trataron como sirvienta 3 años. El día del divorcio descubrieron de quién era hija."

**A2. "La esposa contrato que resultó ser genio" ★ALTO**
- Premisa: matrimonio por contrato/conveniencia; la esposa "corriente" resulta ser médica prodigio, hacker o CEO encubierta.
- Mecanismo: doble brecha (¿por qué aceptó el contrato? / ¿qué esconde?) + asombro al revelarse el talento.
- Señal: "CEO que se enamora de mujer ordinaria" y "flash marriage" son plotlines base del duanju (The Dial); "Dr. Wifey Please Touch Me" encabezó el chart de consumo de verticaldrama.tv en julio 2026.
- Adaptación: Se-ra firma un matrimonio contrato con el heredero Kang para saldar la deuda de su padre. La familia la desprecia por "pueblerina" hasta que el abuelo enferma y ningún especialista lo salva: ella, cirujana formada en el extranjero bajo otro nombre, lo opera.
- Partes: P1 cierra en la boda humillante. P2 en el colapso del abuelo. P3 en la revelación de sus manos de cirujana. P4 en la caída de la cuñada que la difamó.
- Clickbait honesto: "Se casó conmigo por contrato para humillarme. No sabían que yo era la única que podía salvar a su abuelo."

**A3. "Divórciate de un multimillonario para casarte con él" ◐MEDIO**
- Premisa: se divorcia del hombre equivocado y su verdadero valor la eleva por encima de la familia que la despreció (título viral de DramaBox "Divorce A Billionaire To Marry Him"; en "Counterattack" de DramaBox, la camarera May Wright se reencuentra con su primer amor magnate y es humillada por los consuegros).
- Adaptación (versión coreana): Mi-sook, viuda humilde, se reencuentra con su primer amor ahora presidente; los suegros de su hijo la agreden en el banquete de cumpleaños antes de saber quién es su pareja.
- Clickbait honesto: "Los papás de mi nuera me golpearon en la fiesta. No sabían con quién me acababa de casar."

---

### CATEGORÍA B — Suegra tiránica / nuera vindicada (★ enorme densidad en Reddit + saas-bahu indio)

**B1. "La suegra que llamó a la policía / servicios sociales contra la nuera" ★ALTO**
- Premisa: JUSTNOMIL — suegra que invade límites, amenaza con quitarle al bebé o inventa que la nuera es mala madre.
- Mecanismo: indignación moral pura (alta activación) + fantasía de "boundary win".
- Señal: r/JUSTNOMIL es un subreddit-fenómeno de retellings virales (canales de YouTube/TikTok dedicados; Bored Panda recopila estas historias en artículos de audiencia masiva). Casos documentados: suegra que amenaza con la "línea de abuso de ancianos", que "cancela" al hijo scapegoat, que inventa amantes del esposo.
- Adaptación: la suegra Madam Yoon miente diciendo que Ha-eun descuida al nieto para quedarse con la custodia y la herencia del hijo. Ha-eun documenta cada abuso; el giro: el testamento del suegro fallecido nombra a Ha-eun, no a la suegra, administradora del legado familiar.
- Partes: P1 cierra con la falsa denuncia. P2 con el esposo poniéndose del lado de su madre. P3 con la lectura del testamento. P4 con la suegra expulsada de la mansión.
- Clickbait honesto: "Mi suegra le dijo a todos que yo era una mala madre. No sabía lo que decía el testamento de mi suegro."

**B2. "La suegra que destruyó algo sagrado" ◐MEDIO**
- Premisa: suegra que rompe/tira algo de valor emocional (vestido de novia, herencia de la madre muerta de la nuera).
- Mecanismo: profanación de lo sagrado → indignación instantánea.
- Adaptación: la suegra tira el único anillo que quedaba de la madre fallecida de la protagonista, llamándolo "chatarra de pobre". Resulta ser una pieza histórica; y la madre "muerta" era de una familia que la suegra había arruinado décadas atrás.
- Clickbait honesto: "Mi suegra tiró a la basura el anillo de mi madre muerta. No sabía cuánto valía… ni de quién era hija yo."

**B3. "Nuera vs. matriarca por el negocio familiar" (saas-bahu / makjang) ◐MEDIO**
- Premisa: la matriarca tiránica maniobra para dejar a la nuera fuera del negocio y del testamento (tradición saas-bahu india, base de "Kyunki Saas Bhi Kabhi Bahu Thi"; makjang coreano de lucha por el negocio familiar).
- Adaptación: la nuera revela ser la verdadera arquitecta financiera que salvó a la empresa; la matriarca queda expuesta por fraude.
- Clickbait honesto: "La matriarca me quería fuera de la empresa. No sabía que yo era la que la había salvado de la quiebra."

---

### CATEGORÍA C — Esposo infiel + regreso triunfal ("revenge glow-up") (★)

**C1. "El esposo humilló a la esposa 3 años por la amante — hasta el regreso" ★ALTO**
- Premisa: marido desprecia a la esposa por la amante durante años; ella reaparece transformada y poderosa (Dailymotion viral: "CEO Humiliated Wife for 3 Years Over Mistress—Until Her Secret Billionaire Heiress Identity").
- Mecanismo: acumulación de agravio + glow-up + face-slapping del marido y la amante juntos.
- Señal: subgénero dominante de TikTok/ReelShort ("He Betrayed Her After 5 Years… Her Revenge Shattered His World"); variante legal viral del abogado infiel cuya esposa CEO posee el 80% del bufete, le congela cuentas y lo destruye legalmente.
- Adaptación: Yeon-woo es humillada por su esposo Do-jin, que exhibe a su amante en cada evento. Tras el divorcio desaparece; regresa como accionista mayoritaria del bufete/empresa de él, congela sus cuentas, presenta cargos y lo destruye legalmente.
- Partes: P1 cierra con la humillación pública. P2 con la desaparición. P3 con el regreso como jefa. P4 con el marido y la amante arruinados.
- Clickbait honesto: "Mi esposo me humilló frente a su amante en cada fiesta. Tres años después volví siendo su jefa."

**C2. "El novio que la dejó por una rica — y ella era la sacrificada" ◐MEDIO**
- Premisa: ella finge traición o se sacrifica para no arruinar el futuro de él; años después ambos son poderosos y él busca venganza sin saber la verdad (ReelShort "We Will Love Again": Alaina finge una aventura para que Noah acepte Oxford; él vuelve millonario buscando venganza hasta descubrir la verdad).
- Adaptación: Su-bin se hace pasar por infiel para que Jun-ho acepte la beca en el extranjero; 6 años después él vuelve como magnate buscando vengarse, hasta descubrir que ella lo protegió.
- Clickbait honesto: "Todos creen que lo engañé. La verdad de por qué lo dejé la supo 6 años tarde."

**C3. "La esposa que descubrió el hijo secreto del esposo con su hermana/mejor amiga" ★ALTO**
- Premisa: infidelidad + hijo oculto con la persona más cercana (ShortMax: "Grace descubrió la aventura de su esposo Raymond con Vanessa y su hijo secreto").
- Mecanismo: doble traición (esposo + amiga/hermana) = indignación máxima.
- Adaptación: Na-rae descubre que su esposo tiene un hijo con su hermana menor, a quien la familia siempre prefirió. El giro shuangwen: Na-rae es en realidad la hija biológica robada de la familia rica, y la hermana la impostora.
- Clickbait honesto: "El hijo secreto de mi esposo era de mi propia hermana. Lo que no sabían era quién era yo realmente."

---

### CATEGORÍA D — Hijo/hija oculta y ADN/paternidad (★ máximo "curiosity gap")

**D1. "La prueba de ADN que destapó el secreto familiar" ★ALTO**
- Premisa: un test de ADN casero revela paternidad falsa, hermanos ocultos o bebés cambiados (hilo viral de r/AskReddit con miles de respuestas recopilado por Bored Panda; Newsweek: post de TIFU con ~9,700 upvotes sobre hermana cambiada al nacer).
- Mecanismo: la brecha de información más pura ("los resultados decían algo imposible"); es literalmente el gancho de Loewenstein.
- Señal: según YouGov (citado por Newsweek), 2 de cada 10 estadounidenses se han hecho un test de ADN casero, 27% reporta que un familiar cercano lo hizo, y de ellos 36% se sorprendió con los resultados y 1 de cada 3 descubrió parientes desconocidos. Género entero de retellings.
- Adaptación: Da-som se hace una prueba de ADN "por diversión" y descubre que no es hija de su familia pobre sino de un conglomerado; fue cambiada al nacer con la actual "heredera" mimada. La familia rica la despreció como sirvienta sin saberlo.
- Partes: P1 cierra con el resultado imposible. P2 con la confrontación a la madre. P3 con la revelación del cambio de bebés. P4 con la impostora expuesta en el aniversario de la empresa.
- Clickbait honesto: "Me hice una prueba de ADN por curiosidad. Descubrí que la familia rica para la que trabajaba era la mía."

**D2. "El secreto de identidad de la abuela / hermanos entregados en adopción" ◐MEDIO**
- Premisa: un test revela que la abuela dio hijos en adopción y mintió diciendo que murieron (historia real viral recopilada por Bored Panda: hermanos "muertos al nacer" reaparecen décadas después vía ADN).
- Adaptación: al morir la abuela, la protagonista descubre un hermano oculto que es en realidad el heredero legítimo desplazado por la rama villana de la familia.
- Clickbait honesto: "En el funeral de mi abuela apareció un hombre. Traía el testamento verdadero."

**D3. "Bebé secreto / embarazo oculto del multimillonario" ★ALTO**
- Premisa: ella queda embarazada de una noche con un magnate; lo cría sola; años después él descubre al hijo ("Secret Baby", género base de ReelShort/DramaBox).
- Mecanismo: brecha ("¿lo sabrá él?") + fantasía de reivindicación de la madre soltera despreciada.
- Adaptación: Ga-eun cría sola a su hijo tras una noche con un desconocido que resulta ser el presidente del grupo que la despidió injustamente. Cuando la empresa intenta quitarle la custodia, el niño ya es el único heredero varón del imperio.
- Clickbait honesto: "Me despidieron embarazada. Cinco años después, mi hijo era el único heredero de su imperio."

---

### CATEGORÍA E — Heredera oculta / herencia negada (★ tu franquicia "heredera_oculta")

**E1. "Los padres escondieron el testamento de la abuela y le dieron todo al hijo dorado" ★ALTO**
- Premisa: BORU/ProRevenge clásico — familia que oculta la herencia a la hija "oveja negra" para dársela al hermano consentido; ella lo descubre y revierte todo.
- Mecanismo: indignación por favoritismo (scapegoat vs golden child, tema masivo de r/raisedbynarcissists) + venganza legal satisfactoria.
- Señal: arquetipo recurrente en compilaciones muy vistas de BORU/ProRevenge en YouTube ("Parents Hid Grandma's Will, Stole $2M, Gave It To Golden Child Brother"). El post AITA más viral de 2023 (recap oficial de Reddit) era del mismo linaje: mujer presionada a pagar la cena de sus suegros con su herencia se niega (comentario top 65.8K upvotes).
- Adaptación: Ha-rin, la hija menospreciada, descubre que sus padres falsificaron el testamento de la abuela para dárselo al hermano dorado. Pero la abuela, que sí la quería, dejó un segundo testamento con un abogado y acciones de control de la empresa a nombre de Ha-rin.
- Partes: P1 cierra con el desprecio en el funeral. P2 con el descubrimiento del testamento falso. P3 con la aparición del abogado y el segundo testamento. P4 con el hermano y los padres dependiendo de ella.
- Clickbait honesto: "Mis papás le dieron toda la herencia a mi hermano. La abuela había dejado un segundo testamento."

**E2. "La heredera real vs. la hija falsa" ★ALTO**
- Premisa: la verdadera heredera regresa a la familia rica pero es humillada mientras la impostora reina (C-drama viral "Rejected by Her Rich Family, the Real Heiress Exposed the Fake Daughter"; "True Heiress vs. Fake Queen Bee", 395.2M vistas en ReelShort).
- Mecanismo: injusticia flagrante + face-slapping de la impostora + brecha (¿cómo probará quién es?).
- Adaptación: So-yeon, criada en la pobreza, es reconocida como la hija biológica de los Hwang, pero la familia adora a Mi-ra, la falsa heredera que ocupó su lugar. So-yeon es genio en algo (finanzas, arte, medicina) y desmantela a Mi-ra en público.
- Partes: P1 cierra con el reconocimiento y el desprecio. P2 con la impostora saboteándola. P3 con la prueba de identidad y el talento. P4 con Mi-ra expulsada.
- Clickbait honesto: "Volví a mi familia rica y me trataron peor que a la sirvienta. No sabían por qué la impostora me tenía miedo."

**E3. "De pobre a heredera declarada por el hombre más rico" ◐MEDIO**
- Premisa: una chica humillada por pobre es declarada heredera del hombre más rico del país en público (Dailymotion viral: "todos la humillaban hasta que el hombre más rico dijo: 'Es mi heredera'").
- Adaptación: mesera humillada en un banquete resulta ser la nieta perdida del magnate anfitrión, que la reconoce frente a todos los que la despreciaron.
- Clickbait honesto: "Me humillaron por pobre en la fiesta. El dueño de todo se levantó y dijo: 'Es mi nieta'."

---

### CATEGORÍA F — Cenicienta moderna / de pobre a poderosa (★ dizi + telenovela)

**F1. "La chica pobre que mintió sobre su identidad en el mundo rico" ★ALTO**
- Premisa: hija de portero/sirvienta entra a la universidad/empresa de élite fingiendo ser rica; romance con el heredero (dizi "The Girl Named Feriha"/"Adını Feriha Koydum", exportada a 70+ países, popular en Bulgaria, Rusia, India y Pakistán).
- Mecanismo: tensión sostenida (¿la descubrirán?) + ascenso social + amor prohibido entre clases.
- Adaptación: Yoo-jin, hija de la conserje, gana una beca a una universidad de élite (encaja con tu franquicia "internado_legado") y oculta su origen. Se enamora del heredero Seo-jun; cuando la exponen y la humillan, su talento (o un secreto de nacimiento) la coloca por encima de todos.
- Partes: P1 cierra al entrar al mundo rico. P2 con el romance. P3 con la exposición humillante. P4 con la revelación que invierte el estatus.
- Clickbait honesto: "Fingí ser rica para encajar en la universidad de élite. El día que me descubrieron, descubrieron algo peor."

**F2. "La sirvienta de la mansión con un secreto" ◐MEDIO**
- Premisa: mujer trabaja como sirvienta en la mansión de la familia que esconde (o que arruinó a la suya); trope dizi de "una criada con un secreto bien guardado".
- Adaptación: Bo-ra entra como sirvienta a la casa del hombre que llevó a su padre a la ruina, para recuperar pruebas; termina enamorada y descubierta.
- Clickbait honesto: "Entré a servir en la casa del hombre que destruyó a mi familia. Nadie sabía por qué."

**F3. "La prima pobre que se vengó de la clase alta que la despreció" (dizi "Zengin ve Yoksul") ◐MEDIO**
- Premisa: prima pobre criada junto a la prima rica, harta de ser "de segunda", entra en un plan de venganza contra la familia rica.
- Adaptación: dos primas, una rica y una pobre; la pobre acepta ayudar a un vengador contra la familia Erdemli-equivalente, pero desarrolla su propio poder y su propia agenda.
- Clickbait honesto: "Me criaron junto a mi prima rica tratándome como sirvienta. Decidí cobrarme cada humillación."

---

### CATEGORÍA G — Venganza laboral / social (★ ProRevenge + MaliciousCompliance)

**G1. "La empleada subestimada que resultó indispensable / dueña" ★ALTO**
- Premisa: jefe abusivo humilla/despide a la empleada que sostenía todo; ella se va y la empresa colapsa, o resulta ser la dueña encubierta.
- Mecanismo: fantasía de justicia laboral (indignación + satisfacción); género central de r/ProRevenge y r/MaliciousCompliance.
- Adaptación: Da-hye es la analista invisible que sostiene la empresa; el nuevo director, sobrino del presidente, la humilla y la despide. Ella se va a la competencia —o revela ser la auditora enviada por la matriz, o la hija del fundador. La empresa se hunde sin ella.
- Partes: P1 cierra con el despido humillante. P2 con el colapso de la empresa. P3 con la revelación de quién era. P4 con el director de rodillas.
- Clickbait honesto: "Me despidieron diciendo que era reemplazable. Tres meses después me rogaron de rodillas."

**G2. "Cumplimiento malicioso: hicieron exactamente lo que pidió el villano" ◐MEDIO**
- Premisa: la protagonista obedece al pie de la letra una orden injusta y eso destruye al villano (r/MaliciousCompliance).
- Adaptación: la suegra le prohíbe a la nuera "meterse en los negocios de la familia"; la nuera —única con la firma que evita la bancarrota— cumple literalmente y no firma. La empresa cae.
- Clickbait honesto: "Mi suegra me prohibió tocar los negocios de la familia. Le hice caso al pie de la letra."

**G3. "Choosing Beggar / Entitled que exige y termina expuesto" ◐MEDIO**
- Premisa: alguien exige algo gratis o con derecho desmedido y es humillado por su avaricia (r/ChoosingBeggars, r/EntitledParents).
- Adaptación: la cuñada exige que la protagonista (repostera/diseñadora) trabaje gratis para su boda y la humilla; la protagonista resulta ser la dueña de la marca de lujo que la cuñada quería.
- Clickbait honesto: "Mi cuñada exigió que le hiciera el pastel de boda gratis. No sabía que yo era la dueña de la marca."

---

### CATEGORÍA H — Matrimonio arreglado / por contrato que florece (◐ base del duanju)

**H1. "Matrimonio contrato que se vuelve real" ◐MEDIO**
- Premisa: matrimonio de conveniencia (por deuda, herencia o negocio) que se convierte en amor real, con la familia intentando sabotearlo ("forced marriages" es plotline top del duanju).
- Adaptación: Ha-neul se casa por contrato con el frío heredero Ji-hu para saldar la deuda del padre; la familia la desprecia, pero él se enamora al descubrir su fuerza; juntos derrotan a la cuñada saboteadora.
- Clickbait honesto: "Me casé por contrato para pagar la deuda de mi papá. No esperaba que él se enamorara de verdad."

**H2. "Boda relámpago con el desconocido equivocado (que resultó ser el correcto)" ◐MEDIO**
- Premisa: dos personas se casan por error/borrachera o confundiendo a la pareja del contrato, y resulta ser el destino (duanju: "se confundieron mutuamente como la pareja del contrato").
- Adaptación: Se-hee, plantada en el altar por su prometido infiel, se casa esa misma noche con un desconocido en un arranque; él resulta ser el presidente del grupo rival de su ex.
- Clickbait honesto: "Me plantaron en el altar. Esa noche me casé con un extraño… dueño de medio país."

**H3. "Matrimonio forzado que esconde una venganza" (dizi "Cesur ve Güzel") ◐MEDIO**
- Premisa: él la corteja/se casa con ella para vengarse de su familia y termina enamorándose (dizi de venganza clásico: seduce a la hija del enemigo).
- Adaptación: Do-hyun seduce a la hija del hombre que arruinó a su padre; el plan se desmorona cuando descubre que ella también fue víctima de esa familia.
- Clickbait honesto: "Se casó conmigo para vengarse de mi padre. No sabía que yo odiaba a mi familia más que él."

---

### CATEGORÍA I — Millonario disfrazado / identidad oculta (◐ inversión de género útil)

**I1. "El esposo con doble vida: 'inútil' de día, magnate en secreto" ◐MEDIO**
- Premisa: el marido despreciado por "pobre/inútil" es en realidad un multimillonario oculto (ReelShort "The Double Life of My Billionaire Husband", ~450-500M vistas, la versión en español logró casi la mitad).
- Adaptación (para tu voz femenina): contado desde la esposa —Yoon-ah defiende a su esposo "fracasado" ante la familia que lo humilla; el día que lo echan, se revela que él es el presidente encubierto que iba a heredar todo. Ella queda vindicada por haber creído en él.
- Clickbait honesto: "Toda mi familia despreciaba a mi esposo por pobre. El día que lo echaron, descubrieron quién era."

**I2. "La abuela/mujer humilde que era la dueña de todo" ◐MEDIO**
- Premisa: una anciana o mujer sencilla es tratada con desprecio y resulta ser la accionista mayoritaria/dueña.
- Adaptación: la madre viuda visita la empresa de su yerno, que la humilla frente a todos; resulta ser la inversora anónima que salvó a esa empresa.
- Clickbait honesto: "Mi yerno me echó de su oficina por 'vieja pobre'. No sabía que yo era su principal accionista."

---

### CATEGORÍA J — Bebés intercambiados / gemelas separadas (◐ telenovela + makjang)

**J1. "Gemelas separadas que intercambian vidas" ◐MEDIO**
- Premisa: gemelas separadas al nacer, una rica y una pobre, intercambian identidades (telenovela "La usurpadora"/Gaby Spanic; "Cómplices al rescate"/Belinda; makjang birth-secret).
- Adaptación: So-hee (pobre) es obligada a suplantar a su gemela rica Soo-ah tras un accidente; descubre los secretos podridos de la familia rica y hace justicia desde dentro.
- Clickbait honesto: "Me obligaron a hacerme pasar por mi gemela rica. Lo que descubrí en esa mansión lo cambió todo."

**J2. "Bebés cambiados al nacer / heredero equivocado" ◐MEDIO**
- Premisa: dos bebés cambiados en el hospital; el heredero criado en la pobreza y viceversa (makjang birth-secret; telenovela clásica).
- Adaptación: revelación de que la "heredera" mimada y la sirvienta fueron cambiadas al nacer; la sirvienta es la legítima.
- Clickbait honesto: "La enfermera confesó en su lecho de muerte: los bebés fueron cambiados. Yo era la heredera."

**J3. "La matriarca que mató para asegurar la herencia de su hijo" ★ALTO (Cuna de lobos)**
- Premisa: matriarca despiadada finge una discapacidad y mata para que su hijo herede; el testamento exige un nieto varón (Catalina Creel, "Cuna de lobos", 170 episodios, exportada a ~185 países para 2015).
- Mecanismo: villana icónica + brecha (¿qué esconde el parche?) + doble juego moral. Es el ADN del makjang latino: primer episodio abre con la matriarca matando a su esposo.
- Adaptación: la suegra villana finge estar ciega/enferma para manipular a la familia; usa a la nuera como "fábrica de herederos"; la nuera descubre que la suegra asesinó al patriarca para que el testamento no cambiara, y la desenmascara.
- Partes: P1 cierra con la muerte "natural" del patriarca. P2 con la nuera notando la incoherencia del parche/enfermedad. P3 con la prueba del asesinato. P4 con la matriarca expuesta y la herencia revertida.
- Clickbait honesto: "Mi suegra fingió estar ciega durante 20 años. Lo que escondía era un asesinato."

---

### CATEGORÍA K — Reencarnación / segunda oportunidad / regreso del pasado (★ shuangwen puro)

**K1. "Renació el día de su humillación para reescribir todo" ★ALTO**
- Premisa: la protagonista muere traicionada y despierta en el pasado, con memoria del futuro, lista para vengarse (base del duanju de venganza: según The Dial, "los dramas de venganza suelen empezar con la muerte de la protagonista, que luego renace lista para vengarse").
- Mecanismo: fantasía de control total + ironía dramática (ella sabe lo que viene, el villano no) + face-slapping premeditado.
- Adaptación: Seo-yeon es asesinada por su esposo y su hermana para robar su herencia; despierta el día de su boda con toda la memoria. Esta vez desmantela el plan antes de que ocurra.
- Partes: P1 cierra con su muerte/traición. P2 con el despertar en el pasado. P3 con el primer contragolpe. P4 con la caída anticipada de los villanos.
- Clickbait honesto: "Mi esposo y mi hermana me mataron por la herencia. Desperté el día de mi boda, con todos los recuerdos."

**K2. "Volvió tras años en prisión/exilio convertida en CEO despiadada" ◐MEDIO**
- Premisa: injustamente encarcelada/arruinada, regresa transformada para vengarse (TikTok viral "3 Years in Jail. She Returns as a Ruthless CEO").
- Adaptación: Ji-a es incriminada por un crimen que cometió la familia de su esposo; sale años después como jefa de un fondo que compra la deuda de todos ellos.
- Clickbait honesto: "Me encerraron por un crimen que no cometí. Salí siendo dueña de todo lo que amaban."

---

### CATEGORÍA L — Amor prohibido entre clases / secreto familiar que separa (◐ dizi + telenovela)

**L1. "Amor prohibido que oculta un secreto de familia" ◐MEDIO**
- Premisa: dos amantes de clases opuestas separados por un secreto (dizi "Kara Sevda"/Endless Love, primer Emmy Internacional turco).
- Adaptación: Ha-eun y el heredero Tae-yang se aman, pero el padre de él arruinó a la familia de ella; el secreto estalla en el compromiso.
- Clickbait honesto: "Me enamoré del heredero. El día del compromiso descubrí lo que su padre le hizo a mi familia."

**L2. "Matrimonio de dos familias enfrentadas (Romeo y Julieta de clases)" ◐MEDIO**
- Premisa: unión que junta a una familia conservadora pobre y una rica moderna, todo estalla (dizi "Kızılcık Şerbeti", dominante en la conversación doméstica turca desde 2022).
- Adaptación: el matrimonio de Doha (familia humilde) y el heredero de una familia poderosa detona choques de clase, orgullo y venganzas cruzadas.
- Clickbait honesto: "Mi boda unió a dos familias que se odiaban. Nadie imaginó cómo terminaría."

---

## Recommendations

**Fase 1 — Validar la fórmula (semanas 1-2).** Producir primero los 10 arquetipos ★ALTO, empezando por los que ya calzan con tus franquicias existentes: A1 (esposa despreciada = heredera secreta) y E1/E2 (heredera oculta / heredera real vs. falsa) para "heredera_oculta"; F1 (Cenicienta que miente su identidad en la universidad de élite) para "internado_legado". Estos concentran el mayor historial de viralidad probada en ReelShort/DramaBox (títulos de 380-500M vistas).

**Fase 2 — Estructura de partes y cliffhangers.** Regla fija por parte: (1) abrir con brecha de información en los primeros 3 segundos; (2) escalar un agravio; (3) cerrar SIEMPRE en revelación o pregunta abierta de alta activación (indignación o asombro), nunca en tristeza (Berger & Milkman: la tristeza se comparte menos). Secuencia canónica de 4 partes: P1 = humillación/agravio; P2 = pista del secreto; P3 = revelación del poder oculto; P4 = face-slapping público. Extender a 6-8 partes intercalando micro-cliffhangers (un villano nuevo, una prueba que aparece).

**Fase 3 — Ganchos de título.** Usar el patrón de ReelShort (literal, específico, con la promesa clara): "[Humillación concreta] + [giro oculto]". Ej.: "Me trataron como sirvienta 3 años. El día del divorcio descubrieron de quién era hija." El propio ejecutivo de ReelShort declaró a Rolling Stone que evitan títulos "literarios" porque "nadie los entendería"; imita esa explicitud.

**Fase 4 — Métricas y umbrales de decisión.** Medir retención en los primeros 3 s y tasa de finalización por parte. Umbral: si una parte cae por debajo de ~50% de retención al cierre, el cliffhanger es débil — reescribir el gancho de cierre. Si un arquetipo ★ALTO no engancha en 2 pruebas, bajarlo a la reserva y subir uno ◐MEDIO. Duplicar apuestas en el arquetipo que gane (los duanju se generan algorítmicamente por rendimiento; imita esa lógica).

**Fase 5 — Variación combinatoria.** Los duanju más fuertes apilan tropes (heredera oculta + ADN + regreso triunfal). Una vez validados los individuales, combinar 2-3 semillas por serie para multiplicar el "curiosity gap" sin inventar nada nuevo. Ejemplo de apilamiento: A1 + D1 + K1 (esposa despreciada que descubre por ADN que es heredera y "renace" con memoria del pasado).

## Caveats
- **Cifras de vistas de microdramas no auditadas.** Las cifras de ReelShort/DramaBox (450-500M, 395.2M, etc.) son autoreportadas por las plataformas o agregadas por blogs de industria (Real Reel, ContentAsia, verticaldrama.tv), no medición independiente. Úsalas como señal relativa de qué fórmula funciona, no como verdad absoluta.
- **Upvotes de Reddit sobreestimados en retellings.** Las historias de melodrama en texto rara vez superan decenas de miles de upvotes; los canales de YouTube/TikTok inflan la percepción. El valor de Reddit es la densidad de arquetipos y la carga de "moral outrage", no el alcance bruto.
- **Cifras de exportación turca son promocionales.** El "~700M espectadores / casi 170 países" proviene de declaraciones del Ministerio de Cultura turco (2024, vía AFP/Turkish Minute), con variaciones entre fuentes (146 vs 170+ países). Trátalas como orden de magnitud.
- **No copiar, adaptar.** Todas las semillas están reducidas a arquetipo/idea (sin reproducir diálogo ni texto con copyright). Los nombres de personajes propuestos son originales. Los títulos de obras (ReelShort, dizis, telenovelas) se citan solo como referencia de premisa/viralidad; no reproducir sus guiones.
- **Sensibilidad de contenido.** Varias semillas fuente originales incluyen agresión sexual (Fatmagül) o crímenes; para el preset melodramático recomiendo sustituir esos detonantes por traición/despojo/humillación social, que rinden igual en indignación sin el riesgo de moderación de plataforma.
- **Regulación.** Las plataformas chinas retiran mensualmente miles de duanju por "venganza excesiva" o "malos valores"; si distribuyes en apps reguladas, calibra la intensidad del face-slapping. Además, Omdia señala que el núcleo de audiencia del formato son mujeres de 25 a 50 años —ajusta el tono y los detonantes de agravio a ese público.