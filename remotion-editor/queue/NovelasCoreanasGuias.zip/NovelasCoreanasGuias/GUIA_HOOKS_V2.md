# GUÍA MAESTRA DE HOOKS Y GUIONES FACELESS v2.0 (es-MX)
### Archivo de conocimiento para el GPT “Auditor de Hooks y Guiones”

**Última verificación técnica:** 14 de julio de 2026  
**Uso:** material de referencia. Las reglas de comportamiento, el flujo y el formato de salida viven en `INSTRUCCIONES_AUDITOR_HOOKS_V2.md`.

---

## 0. PRINCIPIO CENTRAL

Un hook no vuelve viral un video por sí solo. El hook influye principalmente en la decisión inicial de mirar; la distribución sostenida depende además de tema, audiencia, superficie, packaging, satisfacción, shareability, competencia, historial del canal y calidad del cuerpo.

Por eso el GPT debe evaluar cuatro resultados distintos:

1. **STOP:** ¿detiene a la persona correcta?
2. **HOLD:** ¿mantiene atención mediante claridad, tensión y avance?
3. **SATISFY:** ¿cumple la promesa y recompensa el tiempo?
4. **SPREAD:** ¿da una razón para compartir, guardar, comentar o repetir?

Nunca convertir un score prepublicación en “probabilidad de viralidad”.

---

## 1. ETIQUETAS DE EVIDENCIA

No usar `[PROBADO]` como sinónimo de “regla universal”. La fuente y la generalización son cosas distintas.

| Etiqueta | Significado | Uso correcto |
|---|---|---|
| `[RESTRICCIÓN TÉCNICA]` | Límite o comportamiento documentado de una herramienta | Puede tratarse como regla mientras esté vigente |
| `[OFICIAL–DEFINICIÓN]` | La plataforma define una métrica o función | Describe qué es, no garantiza rendimiento |
| `[OFICIAL–RECOMENDACIÓN]` | Buenas prácticas publicadas por una plataforma | Orientación, no ley causal universal |
| `[ACADÉMICO]` | Literatura revisada por pares o trabajo primario | Aplicar dentro de su alcance y límites |
| `[CASO DE CREADOR]` | Proceso o resultado de un creador/canal | Inspiración transferible, no benchmark universal |
| `[BENCHMARK TERCERO]` | Datos de agencia, consultora o muestra privada | Comparar metodología, vertical y muestra |
| `[HEURÍSTICA]` | Regla práctica todavía no calibrada | Hipótesis de trabajo |
| `[VOLÁTIL]` | Precio, límite, función o algoritmo cambiante | Verificar antes de afirmar |
| `[REQUIERE FUENTE]` | Claim factual del guion sin respaldo disponible | No publicar como hecho |

**Reglas duras válidas:** seguridad, veracidad, derechos, restricciones técnicas actuales y coherencia promesa–contenido. Los benchmarks de retención no son reglas duras.

---

## 2. MODELO OPERATIVO: STOP → ORIENT → CONTRACT → PROVE → REWARD → SPREAD

### 2.1 STOP
El primer estado visual/sonoro debe producir saliencia relevante. Movimiento no es obligatorio: una anomalía clara, un objeto decisivo, un antes/después, una cifra demostrable o una situación imposible también pueden detener.

### 2.2 ORIENT
El espectador necesita entender rápidamente:
- de qué trata;
- qué está pasando;
- por qué podría importarle.

Misterio no significa confusión. Se puede ocultar la respuesta sin ocultar la situación.

### 2.3 CONTRACT
El hook establece un contrato de atención: “dame este tiempo y recibirás esta respuesta, emoción, demostración o giro”. Debe ser:
- concreto;
- creíble;
- acotado;
- proporcional al contenido.

### 2.4 PROVE
La prueba temprana confirma que el contenido no es bait. Puede ser:
- evidencia visual;
- mini-reveal;
- primer resultado;
- dato respaldado;
- consecuencia inmediata;
- avance narrativo irreversible.

### 2.5 REWARD
El payoff puede ser informativo, emocional, cómico o narrativo. Un cliffhanger válido puede posponer la resolución total, pero debe pagar al menos una parte del contrato.

### 2.6 SPREAD
La retención no agota la viralidad. Un video se propaga mejor cuando activa al menos un motivo social real:
- utilidad que ayuda a otra persona;
- identidad o “esto soy yo/mi amigo”;
- emoción intensa y congruente;
- sorpresa verificable;
- opinión debatible sin engaño;
- referencia cultural o formato imitable;
- final que merece repetición.

---

## 3. FUNDAMENTO PSICOLÓGICO, SIN SOBREINTERPRETAR

### 3.1 Curiosity gap `[ACADÉMICO]`
La curiosidad aparece cuando la persona percibe una brecha entre lo que sabe y lo que quiere saber. Para diseño de hooks, la brecha suele funcionar mejor cuando combina:
- conocimiento previo suficiente para comprenderla;
- una incógnita específica;
- relevancia;
- respuesta alcanzable;
- credibilidad de que el video la entregará.

No basta con “ocultar algo”. Un gap enorme o vago produce indiferencia, no curiosidad.

### 3.2 Incompletitud y open loops `[ACADÉMICO + HEURÍSTICA]`
La evidencia moderna no respalda tratar el “efecto Zeigarnik” como una ley universal de memoria. Úsalo como analogía narrativa: una meta interrumpida o una pregunta concreta puede sostener atención, especialmente cuando ya existe inversión emocional o causal.

### 3.3 Arousal, emoción y congruencia
Una emoción intensa puede ayudar a compartir, pero una actuación sobreactuada o incongruente reduce confianza. La emoción debe emerger de la información y del personaje, no sustituirla.

### 3.4 Fluidez de procesamiento
Claridad oral, sintaxis breve, un sustantivo concreto y una relación causal visible reducen el esfuerzo de comprensión. La fluidez no significa simplificar el tema hasta volverlo falso.

---

## 4. DEFINICIONES Y UNIDADES DE AUDITORÍA

- **Beat cero:** primer estado visual/sonoro.
- **Primera unidad semántica:** primera idea completa que se entiende al escucharla una vez.
- **Ventana de hook:** inicio hasta que el contrato de atención queda establecido.
- **Premise:** quién/qué ocurre y por qué importa.
- **Proof temprano:** primera evidencia de cumplimiento.
- **Payoff parcial:** recompensa que cierra una subpregunta.
- **Payoff final:** entrega principal prometida.
- **Re-hook:** cambio del estado informativo; no una frase de relleno.
- **Pattern interrupt:** ruptura de expectativa relevante; no ruido aleatorio.
- **Loop:** pregunta, meta o tensión aún activa.
- **Cliffhanger:** interrupción causal en tensión máxima que paga algo y abre algo nuevo.
- **Hook stack:** combinación de VO, texto, frame, evento, prueba y actuación vocal.

---

## 5. TAXONOMÍA EN CUATRO EJES

La taxonomía plana mezcla mecanismos, sintaxis y recursos de producción. Para diagnosticar y reescribir, etiquetar cuatro ejes.

### 5.1 Eje A — mecanismo psicológico

| Mecanismo | Qué activa | Riesgo |
|---|---|---|
| Curiosidad | Incógnita concreta | Vaguedad o bait |
| Sorpresa/contradicción | Ruptura de modelo mental | Falso contrarian |
| Stakes/amenaza | Consecuencia o pérdida | Alarmismo |
| Identidad/relatabilidad | Auto-relevancia y pertenencia | Callout demasiado estrecho |
| Utilidad/resultado | Ganancia práctica | Sonar a curso/anuncio |
| Emoción/empatía | Dolor, ternura, indignación, esperanza | Melodrama sin contexto |
| Autoridad/prueba | Credibilidad y demostración | Credencial inventada |
| Humor/incongruencia | Choque de marcos | Explicar el chiste |

### 5.2 Eje B — forma lingüística
- pregunta específica;
- declaración contraintuitiva;
- contraste A/B;
- imperativo o warning;
- número/lista;
- confesión;
- diálogo;
- condicional “si…”;
- resultado primero.

### 5.3 Eje C — entrada narrativa
- in medias res;
- consecuencia primero;
- antes/después;
- secreto o reveal retenido;
- recap hook;
- reto o prueba;
- cliffhanger como apertura;
- escena extraña con anclaje.

### 5.4 Eje D — ejecución sensorial
- anomalía visual;
- cambio de estado;
- movimiento relevante;
- evidencia en pantalla;
- silencio o pausa;
- pivote de energía vocal;
- texto de compresión;
- corte de escala o perspectiva.

**Diagnóstico recomendado:** “Mecanismo primario + forma + entrada + ejecución”. Ejemplo: `curiosidad + declaración + in medias res + evidencia visual`.

---

## 6. ÍNDICE DE CALIDAD DEL HOOK (ICH)

### 6.1 Escala
Cada criterio aplicable se puntúa 0–4:
- 0: ausente/contradictorio;
- 1: débil;
- 2: funcional;
- 3: fuerte;
- 4: excepcional y específico.

`ICH = puntos obtenidos / máximo aplicable × 100`

Los umbrales son editoriales y deben calibrarse con datos propios:
- 75–100 PUBLICABLE;
- 60–74 AJUSTAR;
- 0–59 REESCRIBIR;
- 90–100 sin bloqueadores: EXCEPCIONAL.

### 6.2 Criterios

1. **Parada inicial**  
   Evalúa saliencia relevante del beat cero y primera unidad; no premia ruido gratuito.

2. **Comprensión inmediata**  
   Tema/situación/dirección entendibles sin contexto previo.

3. **Especificidad y novedad**  
   Sustantivos, objetos, relaciones y consecuencias concretas; evita fórmulas saturadas.

4. **Tensión y stakes**  
   Existe deseo, pérdida, riesgo, contraste o importancia real.

5. **Ajuste audiencia–objetivo**  
   Atrae a la audiencia correcta para alcance, retención, conversión o continuidad.

6. **Contrato de atención**  
   Promesa clara, creíble, acotada y proporcional al tiempo.

7. **Entrega y payoff**  
   Proof temprano y cumplimiento del contrato sin bait.

8. **Alineación multimodal**  
   VO, frame, texto, título y caption son congruentes y complementarios.

9. **Propagación y replay**  
   Motivo plausible para compartir, guardar, comentar o repetir.

10. **Ejecución TTS**  
    Oralidad, duración, pronunciación, emoción, respiración, tags y compatibilidad de voz.

### 6.3 N/A y confianza
No inventar visuales, cuerpo ni audiencia para llenar casillas. Marcar N/A y normalizar denominador.

- **Confianza baja:** hook aislado o varios supuestos.
- **Confianza media:** guion + plataforma/duración, sin visual/audio.
- **Confianza alta:** paquete con guion, objetivo, audiencia, packaging, visual y/o audio.

### 6.4 Bloqueadores y topes
- Claim importante sin fuente: NO PUBLICABLE.
- Promesa ausente del guion: máximo 49/100.
- Intro/setup antes del hook: máximo 59/100.
- Desinformación o garantía engañosa: NO PUBLICABLE.
- Voz real sin derechos o falsa atribución: NO PUBLICABLE.

---

## 7. TIMING: MEDIR SEGUNDOS, NO SOLO PALABRAS

### 7.1 Estimación textual
Usar 2.5 palabras/segundo como punto de partida con ±20%. Una emoción intensa, una pausa o una voz lenta cambia la duración.

- Cinco a nueve palabras suelen ser un objetivo razonable para una unidad de hasta tres segundos.
- Catorce palabras a 2.5 palabras/segundo duran aproximadamente 5.6 segundos antes de sumar pausas.
- Por eso “≤14 palabras” puede ser techo de frase, no regla de hook de tres segundos.

El render real es la autoridad.

### 7.2 Shorts
No imponer la misma arquitectura a todos los videos.

| Duración | Diseño recomendado `[HEURÍSTICA]` |
|---|---|
| ≤20 s | Hook + proof/reveal + payoff; puede no necesitar re-hook separado |
| 21–45 s | Un cambio informativo claro en la transición natural |
| 46–90 s | Uno o dos re-hooks en cambios de beat |
| 91–120 s | Dos o tres movimientos, sin acumular demasiados loops |

### 7.3 Largos
- El inicio debe continuar la promesa del título/thumbnail.
- El patrón de retención y las transiciones narrativas mandan sobre minutos prefijados.
- Minuto tres, minuto seis o segundo treinta son referencias de casos de creadores, no relojes universales.

### 7.4 Presupuesto de loops
- ≤20 s: uno principal.
- 21–60 s: uno principal + uno secundario como máximo.
- 61–120 s: dos o tres.
- Largo: dos a cuatro activos según complejidad.

Abrir un loop nuevo antes de cerrar el anterior puede funcionar, pero acumular deuda narrativa destruye satisfacción.

---

## 8. HOOK STACK MULTIMODAL

### 8.1 VO
Abre la pregunta, conflicto, contraste o promesa. Debe sonar natural en una sola escucha.

### 8.2 Texto en pantalla
Comprime la idea en pocas palabras. No repetir automáticamente el VO. Puede destacar:
- objeto;
- cifra;
- contradicción;
- consecuencia;
- etiqueta de contexto.

Las zonas seguras cambian por interfaz; validar en preview de la plataforma.

### 8.3 Frame cero
Debe contener información legible, no solo estética. Opciones faceless:
- objeto decisivo en close-up;
- contador/rango/mapa/UI;
- antes/después;
- evidencia marcada;
- cambio físico visible;
- silueta en conflicto;
- acción ya iniciada.

### 8.4 Evento inicial
Movimiento o corte solo cuenta si ayuda a interpretar o elevar la tensión. Un paneo gratuito no es scroll-stop relevante.

### 8.5 Proof temprano
Mostrar algo que reduzca el riesgo de bait: dato fuente, pantalla, transformación, carta, arma, mensaje, resultado, mapa, test o consecuencia.

### 8.6 Audio
La actuación debe complementar el mecanismo. El volumen no sustituye stakes.

---

## 9. RE-HOOKS, PAYOFFS Y CLIFFHANGERS

### 9.1 Test de “delta informativo”
Una línea es re-hook solo si hace al menos una:
- revela información nueva;
- revierte una interpretación;
- eleva una consecuencia;
- cambia la meta;
- paga una subpregunta;
- introduce una evidencia concreta;
- abre una nueva pregunta específica y causal.

No cuentan por sí solas:
- “pero eso no es todo”;
- “espera a ver lo siguiente”;
- “y aquí viene lo mejor”;
- “no vas a creerlo”.

### 9.2 Payoff ladder
Para no exigir resolución total demasiado pronto:
1. **Confirmación:** el video demuestra que sí trata de lo prometido.
2. **Mini-payoff:** entrega un avance o respuesta parcial.
3. **Payoff principal:** cumple el contrato central.
4. **Aftertaste:** eco emocional, utilidad, CTA o nuevo loop legítimo.

### 9.3 Cliffhanger de calidad
Debe:
- surgir de causalidad, no de un corte arbitrario;
- conectar con el loop principal;
- cambiar o elevar stakes;
- pagar una parte;
- abrir una pregunta específica;
- poder resumirse en una línea de tensión.

---

## 10. ANALYTICS Y DIAGNÓSTICO

### 10.1 No usar benchmarks universales como veredicto
Comparar cada video contra:
- misma plataforma y superficie;
- mismo rango de duración;
- vertical/objetivo similares;
- fuente de tráfico comparable;
- baseline reciente del propio canal.

En YouTube, la propia herramienta de retención permite comparar videos de duración similar y la retención típica del canal. En Shorts, las vistas brutas cuentan inicios/replays; para saber quién decidió continuar, priorizar `Engaged views` y la métrica de permanencia disponible.

### 10.2 Separar cuatro diagnósticos

| Capa | Métricas posibles | Pregunta |
|---|---|---|
| Hook | stayed-to-watch, engaged views, retención 1/3/5 s, primer dip | ¿La apertura detuvo y orientó? |
| Cuerpo | AVD, APV, completion, dips | ¿El contenido sostuvo y avanzó? |
| Propagación | shares/sends, saves, replays, comentarios | ¿Dio un motivo social? |
| Conversión | follows, perfil, clics, leads | ¿Atrajo a la persona correcta? |

### 10.3 Árbol de hipótesis

| Patrón | Hipótesis principales | No concluir automáticamente |
|---|---|---|
| Caída inmediata | frame irrelevante, audio lento, confusión, audiencia equivocada, promesa débil | “el texto del hook es el único culpable” |
| Buen inicio, caída tras promesa | body lento, proof tardío, overpromise | “hay que hacer el hook más agresivo” |
| Buen AVD, pocos shares | valor consumible pero poco transferible/identitario | “el algoritmo no lo mostró” |
| Pocos stops, muchos shares entre quienes miran | payoff fuerte, apertura débil o mala distribución | “todo el video está mal” |
| Spike | replay, share, interés o confusión | “el momento es perfecto” |
| Dip puntual | abandono, skip, repetición innecesaria, CTA temprano | “todo lo anterior falló” |

### 10.4 Score observado
No fijar un 60/40 universal entre score estático y analytics. Calibrar por canal. Usar percentiles o z-scores dentro de cohortes y conservar subíndices separados.

---

## 11. ELEVENLABS v3 — MANUAL ACTUALIZADO

### 11.1 Estado y límites `[VOLÁTIL]`
- Eleven v3 salió de alpha y quedó generalmente disponible el 2 de febrero de 2026.
- Soporta más de setenta idiomas, incluido español.
- Límite documentado actual: 5,000 caracteres por solicitud de TTS.
- Para tiempo real, la familia Flash sigue siendo la opción orientada a baja latencia.
- Precios, créditos, límites y compatibilidad de clones deben verificarse antes de publicarlos en la guía.

### 11.2 Principios oficiales relevantes
- La voz elegida es el parámetro más importante.
- La respuesta a audio tags depende de la voz y su material de entrenamiento.
- `Creative`: más expresivo, más riesgo de artefactos/alucinaciones.
- `Natural`: punto de partida equilibrado.
- `Robust`: más estable y menos responsivo a dirección emocional.
- v3 no admite SSML break tags; usar texto, puntuación y tags.
- Elipsis añade pausa/peso; mayúsculas añaden énfasis.
- Normalizar números, fechas y símbolos sigue siendo prudente cuando la lectura exacta importa.

### 11.3 Registro de tags por certeza

**Nivel A — documentados en la guía de prompting:**  
`[laughs]`, `[laughs harder]`, `[starts laughing]`, `[wheezing]`, `[whispers]`, `[sighs]`, `[exhales]`, `[sarcastic]`, `[curious]`, `[excited]`, `[crying]`, `[snorts]`, `[mischievously]`, `[swallows]`, `[gulps]`.

**Nivel B — presentes en el prompt oficial Enhance o ejemplos oficiales:**  
`[happy]`, `[sad]`, `[angry]`, `[whisper]`, `[annoyed]`, `[appalled]`, `[thoughtful]`, `[surprised]`, `[laughing]`, `[chuckles]`, `[clears throat]`, `[short pause]`, `[long pause]`, `[exhales sharply]`, `[inhales deeply]`, además de direcciones semejantes.

**Nivel C — experimentales, libres o dependientes de voz:**  
Acentos, direcciones como `[dramatically]`, `[slowly]`, tags de persona y combinaciones no documentadas. Usar solo con prueba de audio.

**No usar:** tags físicos o de escena como `[standing]`, `[grinning]`, `[pacing]`, `[music]`.

La lista oficial es no exhaustiva; “oficial” no significa que una tag funcione igual con todas las voces.

### 11.4 Matriz mecanismo → actuación

| Mecanismo | Trayectoria vocal recomendada | Tags candidatos | Riesgo |
|---|---|---|---|
| Curiosidad | cercanía → ligera elevación | `[curious]`, `[whispers]` | susurro que pierde claridad |
| Warning | firmeza controlada → proof | `[thoughtful]`, `[appalled]` | gritar desde la primera palabra |
| Shock/reveal | setup limpio → pivote súbito | `[surprised]` en el reveal | actuar sorpresa antes del dato |
| Conflicto/venganza | tensión contenida → determinación | `[angry]` tras el pivote | rabia plana y caricaturesca |
| Confesión/empatía | íntimo → quiebre mínimo | `[sad]`, `[sighs]`, `[crying]` en clímax | llanto sin stakes claros |
| Humor | deadpan → remate | `[sarcastic]`, `[mischievously]`, `[chuckles]` | explicar el chiste |
| Autoridad/explainer | estable → énfasis puntual | sin tag o `[thoughtful]` | energía de vendedor |
| Awe/misterio | amplitud → pausa → detalle | probar `[thoughtful]`/`[whispers]` | solemnidad artificial |

### 11.5 No imponer “emoción distinta” en todo re-hook
El re-hook exige información nueva. La voz puede:
- cambiar de emoción;
- subir intensidad;
- bajar a intimidad;
- acelerar;
- pausar;
- mantener emoción y cambiar intención.

Elegir según causalidad, no por cumplir una regla mecánica.

### 11.6 Estrategia de tomas
Para un hook crítico:
1. Natural sin tag o con dirección mínima.
2. Natural con tag en el pivote semántico.
3. Creative controlada.
4. Opcional: variante de puntuación/ritmo.

No tratar “menos de 250 caracteres” como restricción técnica oficial. Los inputs cortos pueden variar, pero se resuelve con prueba por voz, contexto y múltiples tomas.

### 11.7 QA de audio
- duración real y palabra donde termina el segundo tres;
- pronunciación de nombres, cifras y siglas;
- énfasis correcto;
- respiración y pausas;
- naturalidad emocional;
- artefactos o sonidos no deseados;
- encaje con corte, subtítulo y frame;
- consistencia entre partes de una serie.

---

## 12. PLAYBOOKS POR VERTICAL

### 12.1 MANHWA

**Promesa de audiencia:** inversión de poder, sistema/regresión, humillación y recompensa de justicia.

**Mecanismos fuertes:** conflicto + contraste jerárquico + secreto + in medias res.

**Riesgo de saturación:** “lo humillaron por ser rango F y despertó un sistema prohibido” es reconocible pero genérico. La especificidad debe venir de:
- mecanismo del sistema;
- costo del poder;
- relación con el traidor;
- límite temporal;
- visual decisivo.

**Fórmulas estructurales:**
1. Humillación concreta → regla inesperada del sistema → consecuencia inmediata.
2. Regresión al instante exacto → decisión diferente → nuevo riesgo.
3. Todos interpretan A → el visual prueba B.
4. Villano afirma poder → protagonista muestra una evidencia imposible.

**Ejemplos de ficción:**
- “Su hermano lo dejó morir. El sistema solo le permitió copiar una habilidad.”
- “Regresó cinco minutos antes de la traición… sin poder cambiar de arma.”

**TTS:** tensión contenida; evitar grito constante. Pivote de `[whispers]` o neutral a `[angry]` solo cuando cambia el poder.

**Recap de partes:** stakes + estado actual + nueva amenaza. No recapitular cronológicamente.

### 12.2 NOVELA COREANA / K-DRAMA

**Promesa de audiencia:** traición íntima, ironía dramática, falsa derrota y reversión social/emocional.

**Mecanismos fuertes:** confesión + stakes relacionales + identidad/recurso oculto.

**Riesgo de saturación:** divorcio + amante + heredera secreta sin detalle nuevo. Variar:
- quién posee la evidencia;
- qué perdió la protagonista;
- qué decisión tomó ella;
- cuál es el costo de revelar su identidad.

**Fórmulas:**
1. Acto de traición ya ocurrido → reacción inesperadamente fría → evidencia retenida.
2. Falsa rendición → condición oculta → inversión de poder.
3. Pérdida irreversible aparente → prueba de que alguien mintió.

**Ejemplos de ficción:**
- “Firmé el divorcio. Él no vio el segundo documento bajo mi mano.”
- “El hospital cerró mi expediente… ayer alguien respondió con la voz de mi hija.”

**TTS:** dolor contenido primero; quiebre solo cuando existe contexto. No comenzar con `[crying]` por defecto.

#### 12.2.1 LA MÁQUINA DEL GANCHO (fórmula del canal, validada)

El gancho hablado de escena 1 es SIEMPRE **dos golpes encadenados**, nunca uno:

```
[sacrificio o inversión concreta que YA hizo la protagonista]
+ [traición ejecutada por la persona más íntima, que reencuadra el primer golpe]
```

- "Le pagué todo y embarazó a mi mejor amiga."
- "Mi hijo eligió a su padre rico. Tres días después estaba lavando platos."
- "Doné mi sangre para salvar a la hermana de mi esposo. Días después metió a otra mujer a nuestra cama."
- "Mi hermana me ahogó en la tina, mi esposo le sostuvo la puerta. Al morir renací el día de mi boda."

Reglas: el segundo golpe **reencuadra** el primero (no lo continúa) · el agravio ya está EJECUTADO, nunca es amenaza ni contexto · el traidor es de la casa (esposo, hermana, hijo, suegra, mejor amiga) · la inversión es concreta y medible (dinero, sangre, años, un hijo) · máximo un nombre propio · nunca spoilea el giro.

El vector no es solo hermanas: sirve igual con **hijo, esposo, suegra, nuera, mejor amiga, cuñado, la madre biológica**. Lo que se mantiene fijo es la máquina, no el parentesco.

#### 12.2.2 GANCHO HABLADO ≠ TÍTULO DE PORTADA `[DATO PROPIO — Facebook Reels, jul 2026, vistas de portada]`

Retención Parte 1 → Parte 2 medida en el canal:

| Serie | P1 → P2 | Retención | Tipo de título |
|---|---|---|---|
| ROBARON MI PROPIA SANGRE | 36 → 21 mil | 58% | secreto abierto |
| HEREDERA OCULTA | 77 → 44 mil | 57% | secreto abierto |
| MI HIJO ELIGIÓ A SU PADRE RICO | 77 → 18 mil | 23% | frase cerrada |
| MI HERMANA ROBÓ MI VIDA | 76 → 10 mil | 13% | frase cerrada |

Los tres P1 fuertes topan en 76-77 mil: eso es techo de distribución, no diferencia de calidad. La diferencia está en la Parte 2.

**Regla dura:** la acusación de dos golpes va en el VOICEOVER de la escena 1 y en la descripción del post. La PORTADA lleva una marca de 2-3 palabras que nombra un secreto sin resolverlo (`HEREDERA OCULTA`, `LA CONDENA PRESTADA`, `EL VIENTRE PRESTADO`). Un título que es sujeto + verbo + objeto ya contó la historia: gana el clic de P1 y pierde la serie.

**Portadas:** cara humana grande, contrastada y legible en miniatura, en TODAS las Partes. `LE PAGUÉ SU VIDA` hizo 28 → **63** → 34 mil: la P1 era un escritorio con papeles (sin rostro) y la P2 dos mujeres confrontándose. `ROBARON MI PROPIA SANGRE P5` (documento sobre una hornilla, sin rostro) es el peor dato de la parrilla con 4.1 mil. La portada conceptual/objeto cuesta aproximadamente la mitad de las vistas. La Parte final necesita la portada MÁS fuerte, no la más simbólica.

**Longitud:** 5 Partes. A la quinta la serie ya opera al 10-12% del P1 (ROBARON: 36 → 4.1 mil).

### 12.3 HUESITO

**Promesa de audiencia:** lógica corporal absurda desde el POV de un esqueleto.

**Mecanismos fuertes:** pregunta + incongruencia + identidad del personaje + remate literal.

**Riesgo de saturación:** repetir “¿Qué pasaría si…? Spoiler…” sin nueva mecánica. Variar:
- órgano ausente;
- problema humano;
- ventaja/desventaja;
- consecuencia visual;
- tipo de remate.

**Fórmulas:**
1. Problema humano → limitación esquelética → resultado opuesto.
2. Consejo corporal popular → Huesito lo toma literalmente.
3. Ventaja aparente → costo absurdo.

**Ejemplos:**
- “¿Un esqueleto puede ahogarse? Descubrí que el problema no eran los pulmones.”
- “Me dijeron que escuchara a mi corazón. Técnicamente… no ayudó.”

**TTS:** setup deadpan, pausa mínima, remate `[sarcastic]` o `[mischievously]`.

### 12.4 HISTORIAS / DOCUMENTAL

**Promesa de audiencia:** entender un misterio, decisión o consecuencia histórica con evidencia.

**Mecanismos fuertes:** contraste temporal + objeto/evidencia + stakes humanos + contradicción documentada.

**Riesgo crítico:** simplificación falsa y causalidad única. Evitar “Roma cayó por una moneda” o “un pueblo predijo su fin” sin soporte específico.

**Fórmulas:**
1. Objeto concreto → qué parecía significar → qué prueba realmente.
2. Explicación popular → evidencia que la matiza → consecuencia humana.
3. Decisión pequeña → cadena causal verificable.

**Plantillas, no claims:**
- “[REQUIERE FUENTE] Durante siglos se interpretó como X; este hallazgo obligó a revisar Y.”
- “[REQUIERE FUENTE] La explicación escolar menciona A, pero los registros muestran también B.”

**TTS:** autoridad tranquila, asombro moderado, pausa antes de la evidencia. Evitar tono de tráiler si el dato no lo justifica.

### 12.5 DATOS CURIOSOS / CIENCIA

**Promesa de audiencia:** fenómeno real, comprensible, sorprendente y verificable.

**Mecanismos fuertes:** auto-relevancia + demostración + escala física + contradicción precisa.

**Riesgo crítico:** convertir un matiz científico en afirmación absoluta. Claims como decisiones inconscientes “medio segundo antes”, reemplazo total del esqueleto o analogías de ácido requieren contexto y fuente.

**Fórmulas:**
1. Fenómeno corporal → evidencia → por qué no lo percibes.
2. Creencia común → límite real → demostración.
3. Número con unidad → comparación cotidiana → caveat.

**Plantillas:**
- “[REQUIERE FUENTE] Tu cuerpo produce X; lo importante no es que ocurra, sino por qué casi nunca lo notas.”
- “[REQUIERE FUENTE] Este experimento midió X, pero no demuestra automáticamente Y.”

**TTS:** curiosidad o ironía ligera; no sarcasmo sobre temas médicos sensibles.

### 12.6 CRIPTO-CLARO / FINANZAS

**Promesa de audiencia:** claridad, riesgo y decisiones informadas; no enriquecimiento garantizado.

**Mecanismos fuertes:** costo visible + comparación + prueba + contrato de tiempo realista.

**Riesgo crítico:** cifras desactualizadas, falsa autoridad, miedo, garantía, causalidad simple y consejos personalizados.

**Fórmulas:**
1. Costo o riesgo específico → cálculo visible → acción educativa.
2. Dos tasas comparables → diferencia neta → caveat.
3. Error operativo documentado → cómo detectarlo → cómo reducir riesgo.

**Ejemplos estructurales:**
- “[REQUIERE DATOS ACTUALES] Tu cuenta paga X y la inflación del periodo fue Y; esta es la diferencia real.”
- “Antes de comprar un token, revisa estas dos fuentes. La segunda evita un error común.”

**TTS:** claridad y control. `Natural` suele superar la urgencia teatral. Un disclaimer no corrige una promesa falsa.

---

## 13. BANCO DE FÓRMULAS: USAR COMO ANDAMIO, NO COMO SALIDA

### 13.1 Fórmulas útiles
- “Todos interpretaron {A}. Este detalle demuestra {B}.”
- “El problema no fue {causa obvia}; fue {mecanismo específico}.”
- “Parecía una victoria hasta que {costo concreto}.”
- “En {tiempo realista} verás {resultado demostrable}.”
- “Esta evidencia responde {pregunta}, pero abre {riesgo}.”
- “Yo también creía {suposición}; el primer dato la rompió.”
- “La decisión ocurrió antes de {evento}; esta fue la consecuencia.”

### 13.2 Detector de cliché
Penalizar o mutar:
- “Todo lo que sabes está mal.”
- “Nadie te dice esto.”
- “La número tres no te va a gustar.”
- “No vas a creer lo que pasó.”
- “Pero eso no es todo.”
- “Lo peor no fue X, fue Y” cuando Y sigue vago.

### 13.3 Regla de mutación
Una fórmula solo se considera adaptada si cambia al menos dos:
- objeto;
- relación;
- consecuencia;
- límite temporal;
- evidencia;
- perspectiva;
- sintaxis;
- acción visual.

---

## 14. CTA Y CONTINUIDAD

- No insertar CTA antes del primer valor.
- Para alcance: CTA mínimo o inexistente cuando rompe el loop.
- Para conversión: conectar CTA con el payoff (“usa esta lista…”, “guarda el cálculo…”).
- Para serie: el cliffhanger abre la parte siguiente; el CTA solo indica cómo continuar.
- “Comenta parte dos” no reemplaza un cierre narrativo.
- Proteger una línea compartible o guardable cuando encaje con el objetivo.

---

## 15. EXPERIMENTACIÓN Y CALIBRACIÓN

### 15.1 Exploración vs A/B
- **Exploración:** tres mecanismos distintos para encontrar direcciones.
- **A/B causal:** cambiar una sola variable: primera palabra, nivel de especificidad, frame, tag, pausa o proof.

### 15.2 Hipótesis de prueba
Cada prueba debe declarar:
- variable modificada;
- resultado esperado;
- métrica primaria;
- cohorte;
- criterio de decisión;
- riesgo de confusión.

### 15.3 Calibración del GPT
Construir un set de 30–50 casos por vertical con:
- guion y visual;
- score humano doble;
- analytics reales;
- resultado por plataforma/duración;
- notas de edición.

Medir:
- consistencia del GPT al repetir el mismo caso;
- acuerdo con editores humanos;
- correlación del subscore STOP con retención temprana;
- correlación de SATISFY con AVD/APV;
- correlación de SPREAD con shares/saves;
- errores por vertical.

Ajustar umbrales solo después de observar datos suficientes. No entrenar la rúbrica para perseguir una sola métrica.

---

## 16. ESQUEMA DE DATOS PARA EL SWIPE FILE PROPIO

Campos recomendados:

```text
hook_id
fecha
plataforma
superficie
vertical
objetivo
audiencia
duracion_objetivo
duracion_real
titulo
thumbnail_descripcion
frame_cero
vo_hook
texto_pantalla
mecanismo
forma
entrada_narrativa
ejecucion_sensorial
voz_id
modelo_tts
stability
tags
tomas_generadas
icha_prepublicacion
retencion_1s
retencion_3s
retencion_5s
stayed_to_watch_o_engaged_views
avd
apv
completion
replay_rate
share_send_rate
save_rate
comment_rate
follow_conversion
notas_de_curva
resultado
```

Comparar siempre dentro de cohortes, no mezclar un Short de quince segundos con un documental de doce minutos.

---

## 17. CONTROL DE FUENTES Y VERSIONES

Cada claim externo importante debe tener:
- ID de claim;
- texto exacto;
- fuente;
- tipo de evidencia;
- fecha de publicación;
- fecha de última verificación;
- alcance: orgánico/pagado, plataforma, formato, país;
- limitaciones;
- estado: vigente, dudoso, retirado o reemplazado.

Mover a un apéndice volátil:
- precios;
- límites de caracteres;
- planes;
- nombres de métricas;
- supuestas ponderaciones algorítmicas;
- benchmarks de agencias;
- modelos TTS recomendados.

No usar expresiones como “view jail”, “throttle severo” o “el algoritmo pesa X%” sin fuente primaria específica y alcance definido.

---

## 18. REFERENCIAS NÚCLEO PARA REVERIFICAR

- ElevenLabs: página de modelos, mejores prácticas de Text to Speech, guía de prompting v3, publicación de disponibilidad general y pricing.
- OpenAI: creación y edición de GPTs; separación entre instrucciones y archivos de conocimiento.
- YouTube Help: retención de audiencia, retención típica, Shorts, Engaged views y stayed-to-watch.
- Documentación oficial de TikTok/Meta: separar creative guidance de anuncios y comportamiento orgánico.
- Loewenstein: teoría de information gap.
- Revisión/meta-análisis moderno sobre Zeigarnik/Ovsiankina.
- Estudios de propagación y shareability; no reducir viralidad a retención.

---

## 19. CHECKLIST FINAL DEL GPT

Antes de marcar PUBLICABLE, confirmar:

- [ ] No promete viralidad.
- [ ] Audiencia, objetivo y superficie están declarados o asumidos.
- [ ] No hay claim importante sin fuente.
- [ ] La primera unidad se evalúa por segundos, no solo palabras.
- [ ] El guion contiene lo prometido.
- [ ] Existe proof temprano.
- [ ] Las capas son complementarias.
- [ ] No se premió un cliché por tener “dos triggers”.
- [ ] Los re-hooks cambian información.
- [ ] El cliffhanger paga algo.
- [ ] La actuación TTS coincide con voz y contenido.
- [ ] Los tags fueron probados en varias tomas.
- [ ] Los benchmarks se compararon con la cohorte correcta.
- [ ] El diagnóstico distingue hook, cuerpo, propagación y conversión.
