# medula_prestada — Títulos y hashtags para Facebook Reels

**Regla base (verificada, julio 2026):** en Facebook Reels los hashtags SÍ ayudan al descubrimiento (a diferencia del feed normal), pero el consenso es **3-5 máximo** y más de 3 en un post normal juega en contra. El descubrimiento de Facebook hoy es sobre todo por **IA que lee el texto del caption**, no por indexado de hashtags → **el título/caption con palabras clave pesa más que los hashtags**.

**Formato de cada Parte:**
- **PANTALLA** = texto quemado en el video (corto, legible en 3 s, es el que retiene).
- **CAPTION** = descripción del Reel (lleva las palabras clave que lee la IA de Meta + el número de Parte para el binge).
- **HASHTAGS** = 5, mezcla de género + nicho + marca de serie.

**Hashtag de marca fijo:** `#MedulaPrestada` en las 8. Es el que hace que quien engancha encuentre las otras Partes.

---

## PARTE 1 — La donadora

- **PANTALLA:** `Doné mi médula. Me echaron esa noche.`
- **CAPTION:** Doné mi médula para salvar a la hermana de mi esposo. Seis semanas después, otra mujer dormía en mi cama y mi suegra me sacó a la lluvia. Parte 1 de 8.
- **HASHTAGS:** `#NovelaCoreana #HistoriasDeVenganza #Suegras #MedulaPrestada #Reels`

## PARTE 2 — La hija que ya tenían

- **PANTALLA:** `La amante de mi esposo vivía en esa casa.`
- **CAPTION:** El hombre más rico del país me metió en su casa esa misma noche. Y por la escalera bajó descalza la mujer que dormía en mi cama. Parte 2 de 8.
- **HASHTAGS:** `#NovelaCoreana #DramaCoreano #Infidelidad #MedulaPrestada #Reels`

## PARTE 3 — La página arrancada

- **PANTALLA:** `Fui al hospital donde nací. Yo estaba muerta.`
- **CAPTION:** Busqué mi fecha en el libro del hospital y encontré otro nombre y una palabra escrita a mano: fallecida. Con el número de mi carnet. Parte 3 de 8.
- **HASHTAGS:** `#NovelaCoreana #HistoriasDeVenganza #IdentidadRobada #MedulaPrestada #Reels`

## PARTE 4 — El hombre que volvió

- **PANTALLA:** `Le pregunté de qué tipo era mi sangre.`
- **CAPTION:** Mi esposo volvió a buscarme cuando supo quién era yo. En el jardín le hice una pregunta que no debía saber contestar. Contestó sin pensar. Parte 4 de 8.
- **HASHTAGS:** `#NovelaCoreana #DramaCoreano #Traicion #MedulaPrestada #Reels`

## PARTE 5 — La enfermera de esa noche

- **PANTALLA:** `En la caja de mi madre había una credencial.`
- **CAPTION:** Mi madre me dijo toda la vida que limpiaba oficinas. En la única caja que quedó de ella encontré una credencial de enfermera con el sello del hospital donde nací. Parte 5 de 8.
- **HASHTAGS:** `#NovelaCoreana #HistoriasQueAtrapan #Madres #MedulaPrestada #Reels`

## PARTE 6 — El recibo

- **PANTALLA:** `Firmé que no era nadie para salvarla.`
- **CAPTION:** Mi suegra me puso un precio: entrar al quirófano a cambio de mi carnet y de mi nombre. Firmé. Y la que se estaba muriendo despertó sabiendo algo. Parte 6 de 8.
- **HASHTAGS:** `#NovelaCoreana #HistoriasDeVenganza #Suegras #MedulaPrestada #Reels`

## PARTE 7 — Tres minutos

- **PANTALLA:** `Entré por la puerta por donde me sacaron.`
- **CAPTION:** El día de su boda volví a la casa que me echó a la lluvia. Ahora estaba llena de flores. Y el que me abrió la puerta de servicio fue mi esposo. Parte 7 de 8.
- **HASHTAGS:** `#NovelaCoreana #DramaCoreano #Bodas #MedulaPrestada #Reels`

## PARTE 8 — La firma (final)

- **PANTALLA:** `Le pedí a la novia una gota de sangre.`
- **CAPTION:** Delante de trescientos invitados le pedí a la novia una sola gota de sangre. No quiso. Y todos entendieron lo mismo al mismo tiempo. Final de la temporada 1. Parte 8 de 8.
- **HASHTAGS:** `#NovelaCoreana #HistoriasDeVenganza #FinalExplosivo #MedulaPrestada #Reels`

---

## Notas de uso

1. **El texto en pantalla no debe repetir el voiceover** de la escena 1: compite. Que comprima la idea (objeto + consecuencia).
2. **Primeros 3 segundos:** el título quemado tiene que estar arriba, fuera de la zona donde Facebook pone el nombre del perfil y el caption (zona segura: tercio central-alto).
3. **Los 5 hashtags** van en el caption, al final, nunca dentro del texto en pantalla.
4. **No prometas lo que el video no paga**: cada título de arriba está sacado de una escena que sí ocurre en esa Parte.
5. **Serie:** repetir `#MedulaPrestada` + "Parte X de 8" en las 8 es lo que convierte una vista suelta en un maratón.
