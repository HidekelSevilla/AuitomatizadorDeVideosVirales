# Calibración inicial del Auditor V6

## Conjunto

Carpeta observada:

```text
public/el_barrendero_de_la_ruina_parte_01/images
```

Contiene 43 JPG RGB de 720×1280. No aparecen `scene_03.jpg` ni `scene_04.jpg`; tratarlas como cards es una inferencia hasta recuperar el JSON productor.

Este conjunto sirve como benchmark etiquetado inicial. No demuestra que el Auditor automático esté calibrado; sus decisiones deben compararse con revisión humana.

Copias de evidencia del paquete:

- `evidence/V5_3_CONTACT_SHEET_43.jpg`
- `evidence/V5_3_IMAGE_METRICS_43.json`
- `evidence/V5_3_CALIBRATION_LABELS_43.json`

## Etiquetas geométricas verificadas

Proporción de píxel puro por imagen:

| Scene | Blanco RGB≥245 | Negro RGB≤18 | Etiqueta útil |
|---|---:|---:|---|
| `scene_07` | 55.2% | — | campo blanco fuerte |
| `scene_31` | 26.7% | — | campo blanco fuerte |
| `scene_34` | 37.6% | — | campo blanco fuerte |
| `scene_38` | 46.6% | — | campo blanco fuerte |
| `scene_40` | 37.1% | — | campo blanco fuerte / isolate |
| `scene_12` | — | 46.3% | campo negro fuerte / inset |

Son 6/43 (14.0%) con campo blanco/negro fuerte bajo los umbrales usados. Esto no prueba número de celdas, orden ni función narrativa.

## Etiquetas visuales humanas

### Referencias de “página visible, pero no determinista”

- `scene_07`: figura + fragmento sobre campo blanco; la relación se lee, pero la geometría fue horneada por el modelo.
- `scene_31`: inset de rostro sobre toma dominante; prueba útil de jerarquía, sin garantía de medidas.
- `scene_34`: dos áreas diagonales blancas; aspecto de collage, bordes/ángulos no contractuales.
- `scene_38`: fragmento + reacción sobre blanco; lectura clara, geometría no reproducible.
- `scene_40`: isolate de dos figuras; respira, pero no demuestra multi-panel.
- `scene_12`: campo negro con amenaza; el inset existe, pero debe distinguirse de simple escena nocturna.

### Referencias de “ilustración pulida, cámara poco contrastada”

Revisar juntas `scene_13`, `15`, `17`, `30`, `32`, `33`, `35` y `36`. Aunque cambian acción, escala y alguna inclinación, la lectura global permanece dominada por el mismo túnel, altura cercana a ojos y composiciones frontales/tres cuartos. No se asigna aquí un enum exacto a cada una; la etiqueta es de similitud perceptiva de secuencia.

### Referencias de continuidad razonable

- protagonista: `scene_29`→`40` conserva cabello/overol de forma reconocible;
- criatura: `scene_30`→`36` mantiene placas negras y grieta violeta;
- cápsula: `scene_21`→`28` conserva silueta general;
- túnel: arquitectura/arco/paleta se mantienen durante gran parte de la Parte.

“Razonable” no equivale a PASS contractual: faltan hashes, prompts y estados observados para probarlo.

## Cómo usar este benchmark

1. Construye una contact sheet con orden e IDs.
2. Pide al Auditor clasificar sin mostrarle los metadatos esperados.
3. Compara su salida con estas etiquetas y con un revisor humano.
4. Si llama “multipanel” a una escena solo por blanco/negro, registra falso positivo.
5. Si acepta un enum de ángulo sin horizonte/perspectiva observable, registra falso positivo.
6. Si confunde consistencia de paleta con continuidad de identidad/estado, registra falso positivo.
7. Ajusta ejemplos/instrucciones; no cambies el resultado humano para acomodarlo al Auditor.

## Criterio de salida de calibración

Antes de usar postflight sin adjudicación constante, el Auditor debe alcanzar sobre un conjunto humano etiquetado:

- ≥90% de acuerdo en página compuesta vs full-bleed;
- ≥85% en familia de elevación/viewpoint;
- 100% de recall para fallos críticos de identidad/continuidad;
- ninguna aprobación basada solo en prompt/metadata.

Hasta entonces, discrepancias críticas requieren humano.
