# Motor de premisas comerciales V6

## Fórmula

Una serie sostenible combina:

```text
persona legible + desigualdad concreta + regla imposible visual
+ ventaja con costo + antagonismo institucional/personal + deuda serial
```

La premisa debe prometer escenas, no solo lore.

## Test de fuerza

Puntúa 0–2 cada eje:

- hook explicable en una oración;
- contradicción visual inmediata;
- deseo humano reconocible;
- regla que produce decisiones y consecuencias;
- costo que empeora al usar la ventaja;
- antagonista con capacidad de actuar;
- mundo que genera nuevas Partes;
- cliffhangers no intercambiables.

Menos de 12/16 requiere replanteamiento. La nota no garantiza rendimiento; solo detecta premisas sin motor.

## Parte 1

Debe:

1. abrir con resultado/peligro/pregunta concreta;
2. aterrizar rápido al rol y carencia;
3. mostrar desigualdad en acción;
4. revelar regla/amenaza;
5. obligar una decisión;
6. demostrar poder o mecanismo;
7. cobrar costo visible;
8. cerrar con nueva persecución, deuda o identidad peligrosa.

## Anti-patrones

- protagonista “OP” sin pérdida;
- sistema explicado antes de afectar a alguien;
- villano que solo existe en exposición;
- mundo lleno de nombres pero sin causalidad;
- payoff que no cambia estatus ni relaciones;
- cliffhanger que podría pegarse a cualquier historia;
- carencia mencionada y nunca cobrada.

## Salida

Elige una premisa, declara por qué gana y conviértela en canon/beat/monólogo. No generes cinco versiones mezcladas dentro del mismo packet.

