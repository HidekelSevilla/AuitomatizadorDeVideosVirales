# Prompts de ángulos y referencias V6

## Sintaxis recomendada

```text
SHOT: [elevation] [viewpoint] [scale] from [distance/height], [occupancy].
[Nominal subject] [finite verb] [target/result].
[Eyes/mouth/body or action contacts].
[Screen direction, layers, axis and scale anchor].
[Location, time, dominant light source and bounce].
[Manhwa style anchor]. No readable text.
```

## Contrapicado observable

```text
SHOT: worm's-eye rear three-quarter full shot from 35 cm above the wet floor, the standing figure occupying 62% of frame. The young cleaner braces between the child and the plated creature, shoulders forward and both palms open toward screen-right. Floor reflections and converging tunnel columns rise behind him; the low horizon stays below his knees. Amber work light enters from rear-left and violet threat light from front-right. Hand-drawn Korean manhwa webtoon illustration, 2D cel shading, crisp inked lineart, no readable text.
```

## Picado de geografía

```text
SHOT: bird's-eye wide master from 14 meters above, level roll, all figures occupying under 20%. The cracked lane divides the cleaner screen-left from the trapped worker and child screen-right while the creature remains beyond them near the broken column. The exit, warning tape and convoy lane form three readable zones on one ground plane. Rain-dark concrete reflects amber ceiling lamps and one violet source. Korean manhwa webtoon background-rich illustration, crisp inked lineart, no readable text.
```

## OTS relacional

```text
SHOT: over-the-shoulder medium shot behind the captain, eye-level, Seo occupying 42% beyond her raised scanner. The captain's armored shoulder and physical device frame the foreground while Seo stops two meters away, jaw tight and hands lowered. Rifle barrels remain separated in the background and point toward him. Cold scanner light crosses from foreground-left; amber tunnel light stays behind Seo. Hand-drawn Korean manhwa webtoon illustration, controlled cel shading, crisp inked lineart, no readable text.
```

## Referencia de identidad sin composición

Antecede el prompt con:

```text
Use the provided reference only for the same face, hair, body proportions and outfit. Create a new pose, crop, camera elevation, viewpoint, composition and background exactly as specified below.
```

## Plate compatible

Solo usa `LOCATION+GEOMETRY_LOCK` si la plate comparte elevación/viewpoint. Si no, omítela y describe en 10–18 palabras los materiales, elementos fijos, hora y luz. No escribas “same place” sin anclas observables.

## Celda para precomposición

El prompt produce arte full-frame limpio. Nunca le expliques al modelo que será slot A/B ni le pidas márgenes. `focal_point` y el blueprint hacen el crop después.

