# Evals y gates de release V6

## Regla de honestidad

`PROMPT_RELEASE_V6` solo certifica intención. **Sin JPG reales, observaciones de precomposición, JSON productor y postflight no se puede declarar `RENDER_RELEASE_V6`**, sea `mode:PILOT` o `mode:PRODUCTION`. Este documento define cómo obtener esa evidencia; no afirma que V6 ya la tenga.

## Unidad de prueba: piloto de 10 escenas

El piloto usa 10 momentos representativos del mismo relato y conserva una contraparte V5.3 comparable. Debe cubrir:

- al menos 4 escenas de gramática de página elegidas por función narrativa entre `WHITE_ISOLATE`, `BLACK_INSET`, `STACKED_2`, `ASYM_2` y `STACKED_3`;
- al menos 6 firmas de cámara perceptualmente distintas, incluyendo `TRUE_LONG`, cenital/birds-eye, low-angle, perfil/lateral, macro/fragmento y over-the-shoulder;
- un personaje recurrente en al menos 3 escenas;
- al menos un cambio causal de estado y una interacción actor→target.

Una escena puede cubrir más de un caso. La selección se congela antes de generar para impedir escoger solo los resultados favorables.

## Paquete mínimo de evidencia

Por escena/celda se requiere:

1. JSON productor versionado y su SHA-256;
2. `page_blueprint.template` y geometría esperada cuando sea compuesta; full-bleed usa el canvas completo implícito;
3. `shot_ledger` esperado y motivo narrativo;
4. prompt exacto, modelo, configuración, seed si existe, job ID e historial append-only `attempt_history`;
5. referencias con rol, vista compatible y SHA-256;
6. imagen cruda y SHA-256;
7. manifiesto real de precomposición y SHA-256, encadenado al hash del proyecto, `page_blueprint`, fuentes y JPG final;
8. JPG final 720×1280 y SHA-256;
9. resultados de píxel, VLM y revisión humana;
10. historial de intentos y códigos de fallo.

Preflight además exige `obligation_map`: cobertura exacta packet→`shot_id`→prompt, sin fuentes huérfanas. Esta evidencia textual no sustituye G3/G4 sobre píxeles.

Falta de cualquiera de los puntos 1–8 bloquea release; no se reconstruyen datos de memoria.

## Matriz de release

| Gate | Cómo se mide | Piloto de 10 | Producción |
|---|---|---:|---:|
| G0 Procedencia | Cobertura de hashes y campos del paquete mínimo | **100%** | **100% de cada escena** |
| G1 Geometría determinista | Precompositor externo vs manifiesto; límites, celdas, bordes y gutters | **10/10** | **100%** |
| G2 Firma de cámara observada | Comparación expected→observed por VLM + humano | **≥9/10 (90%)** | **≥90% por episodio y en cada ventana móvil de 20 escenas** |
| G3 Gramática semántica de página | Conteo/orden/contenido de celdas, no solo color | **4/4 casos designados** | **100% de layouts no-full-bleed** |
| G4 Identidad y continuidad | Inspección de locks y cadena de estado | **0 errores críticos** | **0 errores críticos** |
| G5 Crop y legibilidad móvil del arte | Final + preview 360×640 | **10/10** | **100%** |
| G6 Artefactos técnicos | Manos/rostros, duplicados, bordes, seams, texto espurio | **0 críticos/mayores; ≤1 menor aceptado** | **0 críticos/mayores; ≤2% menores aceptados y documentados** |
| G7 Preferencia humana ciega | A/B V5.3 vs V6 | **PASS obligatorio** | PASS inicial y después de cambios de modelo/compositor |
| G8 Límite de intentos | `generation_attempt` por `shot_id`; composición aparte por `scene_id` | **≤3** | **≤3** |

Todos los gates son HARD a nivel agregado. `RENDER_RELEASE_V6` exige que cada fuente/página tenga `asset_status:PASS`, cero fallos críticos o mayores sin resolver y que cada gate alcance su propio umbral; un promedio nunca compensa identidad/continuidad/procedencia rota.

Los valores de `v6_contract.thresholds` pueden endurecer estos mínimos, nunca rebajarlos. El validador rechaza, entre otros, cámara <90%, A/B <5×10 o <66% de votos/<70% de pares, más de tres generaciones, menos de tres templates y porcentajes de página inferiores al modo declarado.

## Protocolos de medición

### G1 — Geometría

- El JPG final debe medir exactamente 720×1280.
- Cada borde de celda, gutter y límite del page field coincide con el manifiesto con tolerancia máxima de ±2 px a 720×1280.
- Fuera de celdas, ≥99% de los píxeles del page field quedan a ΔRGB≤3 del color declarado; antialias de bordes se excluye mediante una banda de 2 px.
- Cada fuente de panel cubre su celda sin bandas involuntarias y sin upscaling mayor a 1.15×.
- `FULL_BLEED` usa todo el canvas de forma implícita y no necesita `page_blueprint`. No se reclasifica un fallo multi-panel como full-bleed para aprobarlo.

La métrica de blanco/negro prueba campo de página, no número ni significado de paneles; G3 evalúa eso por separado.

### G2 — Firma de cámara

La firma esperada se congela antes de generación: escala, elevación, `viewpoint`, roll, `occupancy_range_pct`, sujeto focal y eje. VLM y revisor humano clasifican el JPG de forma independiente.

Cada fuente registra `camera_result: MATCH|ACCEPTABLE_VARIANCE|MISS|NOT_OBSERVED`. `MATCH` exige escala, elevación, viewpoint, sujeto y roll compatibles y ocupación dentro de banda. `ACCEPTABLE_VARIANCE` conserva la intención narrativa pero no cuenta dentro del ≥90%; `MISS` o `NOT_OBSERVED` dejan la fuente en retake. `observers.vlm` y `observers.human` guardan IDs independientes, resultado y evidencia concreta; si discrepan, `observers.adjudicator` registra un segundo humano y la decisión final. El validador comprueba completitud y aritmética de esos registros, no puede demostrar por sí solo que la inspección ocurrió. Editar la firma después de ver el JPG crea nueva versión e intento; no corrige retroactivamente el fallo.

Además, el piloto debe conservar al menos 6 firmas distintas y no repetir la misma firma completa más de 2 escenas consecutivas. Esto prueba contraste perceptible, no variedad nominal.

### G3 — Panel/página semántico

Para cada layout designado se verifica:

- número exacto de celdas y orden de lectura;
- cada celda contiene el momento y sujeto asignados;
- ningún personaje u objeto atraviesa gutters salvo que el template lo permita;
- un composite muestra instantes distinguibles, no la misma ilustración duplicada;
- el campo blanco/negro sigue siendo página, no cielo, explosión, niebla u oscuridad ambiental.

Píxel valida geometría; VLM propone la lectura semántica; humano confirma los cuatro casos del piloto y todo layout no-full-bleed en producción.

### G4 — Identidad y continuidad

Un error es **crítico** si cambia identidad, rostro/peinado identificador, outfit bloqueado, herida/marca/poder, dueño/estado de prop, ocupante, ubicación/hora, dirección causal, cardinalidad, actor, target o resultado narrado. También es crítico anticipar un estado antes de su causa o perderlo sin transición.

Se exige cero errores críticos en piloto y producción. Un error menor —por ejemplo, un detalle decorativo no canónico— no puede afectar lectura, identidad ni causalidad y debe repararse antes del master final.

### G5 — Crop y legibilidad

- Final contractual: 720×1280; preview obligatoria: 360×640.
- Rostros, manos causales, punto de contacto, prop decisivo y texto requerido no quedan cortados y mantienen al menos 4% de margen dentro de su celda, salvo crop narrativo explícito como `MACRO`.
- UI horneada contractual: 100% de coincidencia OCR y revisión humana; ningún texto legible inventado. Captions/overlays del editor quedan fuera de V6 porque no se modifica ni renderiza Remotion.
- En preview 360×640, cinco segundos de observación sin zoom bastan para identificar sujeto, acción/target y función de cada celda.
- Las páginas compuestas quedan estáticas (`editor_motion.enabled:false`); la auditoría de geometría usa el JPG final previo al editor.

### G7 — A/B humano ciego

Cinco revisores ven 10 pares V5.3/V6 en teléfono o viewport 360×640. Orden y etiquetas A/B se aleatorizan por par; no se revela versión. La pregunta forzada es: «¿Cuál se ve más publicable y profesional sin perder claridad, identidad ni lectura?» También etiquetan causa: cámara, composición, paneles, continuidad, crop o artefacto.

PASS requiere simultáneamente:

- V6 obtiene al menos 33 de 50 votos; y
- V6 gana por mayoría de revisores en al menos 7 de los 10 pares; y
- ningún par ganado contiene un error crítico oculto por preferencia estética.

Empate o incumplimiento es `F_HUMAN_PREFERENCE`, no un PASS parcial. `RENDER_AUDIT_V6.human_ab` guarda IDs de revisores, asignación aleatoria, votos y adjudicación. El validador comprueba completitud y aritmética de ese registro; no puede probar por sí solo que los humanos miraron las imágenes.

## Intentos y reparación selectiva

La primera generación es `generation_attempt:1` por `shot_id`. Se permiten dos regeneraciones adicionales, máximo 3. Cada registro conserva `attempt_history[1..N]` con job ID, ruta, hash y status; el último elemento coincide con la fuente actual. Rutas o hashes idénticos entre dos `shot_id` bloquean porque no prueban tomas distintas. `composition_revision` se cuenta aparte por `scene_id`; recomponer los mismos hashes no consume intento de generación. Se repara el objeto mínimo y se preservan assets que ya pasaron.

Después de cada intento se ejecutan de nuevo los gates afectados y sus dependencias. Si cambia estado/identidad, se revalidan las escenas descendientes. Al fallar el intento 3, la fuente queda `HUMAN_REVIEW_V6`; nunca se fuerza PASS ni se reinicia el contador cambiando el nombre del archivo.

## Códigos de fallo y escalamiento

| Código | Detección | Primera reparación | Escalamiento tras intento 3 |
|---|---|---|---|
| `F_PROVENANCE_MISSING` | JSON, hash, job ID o artefacto ausente | Recuperar desde ingestión; no regenerar a ciegas | Dueño de ingestión/pipeline; release bloqueado |
| `F_LAYOUT_GEOMETRY` | Límites/gutters/page field fuera de tolerancia | Recombinar la misma fuente en precompositor | Dueño del precompositor externo |
| `F_PANEL_SEMANTICS` | Conteo, orden o momento de celda incorrecto | Regenerar solo la celda fallida | Director visual + revisor humano |
| `F_CAMERA_SIGNATURE` | Cámara observada no coincide | Ajustar prompt de cámara y regenerar esa celda | Director visual; revisar template de shot |
| `F_REFERENCE_CAMERA_CONFLICT` | Referencia impone vista incompatible | Sustituir por referencia multivista compatible | Dueño de assets/identidad |
| `F_IDENTITY_DRIFT` | Rostro/outfit/marca/entidad incorrectos | Regenerar con identity lock y refs correctas | Dueño de assets + Director; bloquear descendientes |
| `F_PROP_STATE_DRIFT` / `F_MOMENT_POSITION_DRIFT` / `F_FUTURE_STATE_LEAK` | Estado, posición o causalidad rota | Corregir plan/estado y regenerar desde el punto de cambio | Showrunner + Director; no alterar monólogo/canon bloqueados |
| `F_CROP_UNSAFE` | Elemento causal cortado o fuera de safe area | Reencuadrar/recomponer antes de regenerar | Compositor + Director |
| `F_TEXT_UNREADABLE` | OCR, tamaño, contraste o texto espurio falla | Rehacer texto en compositor; evitar texto generado | Editor/compositor |
| `F_RENDER_ARTIFACT` | Anatomía, duplicado, seam o corrupción | Regenerar solo asset/celda afectada | Revisión humana + proveedor/modelo |
| `F_HUMAN_PREFERENCE` | A/B no alcanza el umbral | Analizar etiquetas y reparar patrón dominante | Revisión creativa; nuevo piloto versionado |

## Estados permitidos

- `PACKET_READY_V6`: packet válido.
- `PROMPT_RELEASE_V6`: contrato/prompts listos; no implica calidad visual.
- `RETAKE_REQUIRED_V6`: postflight falló y quedan intentos.
- `HUMAN_REVIEW_V6`: tercer intento, baja confianza o discrepancia crítica.
- `RENDER_RELEASE_V6`: todos los gates del `mode` declarado pasan.
- `BLOCKED_INPUT`, `BLOCKED_CANON`, `BLOCKED_MONOLOGUE`, `BLOCKED_VALIDATOR`, `BLOCKED_RENDER_INPUT`.

El reporte final lista, por `scene_id` y celda: expected, observed, evidencia, código, intento, reparación y resultado. Frases como «se ve más dinámico» o «el prompt pide cenital» nunca sustituyen una medición del render.
