# Auditoría V5.3 → V6

## Dictamen

V5.3 mejoró mucho la **intención de preproducción**, pero el resultado observado no demuestra que esa intención llegue al píxel. El problema principal no es falta de términos como `TOP_DOWN`, `WHITE_COMPOSITE_2` o `TRUE_LONG`; es que hoy no existe un circuito cerrado **plan → generación → composición → render → medición → reparación**.

V6 debe ser una versión de ejecución y verificación, no otra ampliación de vocabulario. Hasta renderizar un piloto y superar `EVALS_V6.md`, cualquier mejora descrita aquí es una **predicción de diseño**, no un éxito probado.

## Evidencia observada

Artefactos reproducibles: `evidence/V5_3_CONTACT_SHEET_43.jpg` y `evidence/V5_3_IMAGE_METRICS_43.json`, generados sin modificar los JPG fuente.

| Evidencia | Hallazgo | Lo que sí permite concluir | Lo que no permite concluir |
|---|---|---|---|
| Inventario de imágenes | 43 JPG RGB, todos de 720×1280 | El lote es uniforme en formato y resolución | Que sea resolución maestra o que conserve zonas seguras |
| Secuencia de archivos | No aparecen `scene_03` ni `scene_04` | Faltan en la carpeta inspeccionada | **Inferencia:** podrían ser cards resueltas por el editor; no está confirmado sin JSON/manifiesto de render |
| Medición de píxeles | Exactamente `scene_07`, `scene_31`, `scene_34`, `scene_38` y `scene_40` tienen ≥10% de blanco puro; `scene_12` tiene ≥20% de negro puro | 6/43 (14.0%) muestran tratamiento fuerte de campo blanco/negro bajo esos umbrales | Cuántos paneles semánticos existen, si tienen el layout pedido o si la secuencia interna es correcta |
| Hoja de contacto | Visualmente predominan ilustraciones full-bleed del túnel, a nivel de ojos y de frente o tres cuartos; solo hay unas pocas páginas inequívocas | La variedad percibida es baja y la gramática de página no domina el resultado | Un conteo exacto de ángulos; esta es observación visual, no clasificación exhaustiva |
| Auditor V5.3 | Se declara compuerta de **preproducción**, limita el estado a `PROMPT_RELEASE` y prohíbe afirmar que vio renders | V5.3 no podía certificar el acabado final por diseño | Que un PASS de prompts equivalga a PASS visual |
| Contrato/runtime actual | `visual_plan` no es consumido por Remotion; los tipos/render actuales presentan un JPG a pantalla completa con `objectFit: cover` | La geometría descrita en metadatos no es ejecutable dentro del editor actual | Que pedir más márgenes o paneles al generador haga determinista el layout |
| Trazabilidad | No se encontró el JSON productor de este lote | No puede reconstruirse qué pidió exactamente cada escena | Atribuir la causa al Director, al generador o a la ingestión; esa causalidad queda **desconocida** |

La medición blanco/negro es evidencia geométrica y de color. No debe usarse como sustituto de una evaluación semántica del número de paneles, cámara, identidad o causalidad visual.

## Scorecard del resultado V5.3 observado

| Dimensión | Peso | Nota | Aporte |
|---|---:|---:|---:|
| Claridad narrativa | 20% | 7/10 | 1.40 |
| Identidad y continuidad | 15% | 6/10 | 0.90 |
| Variedad de cámara | 20% | 3/10 | 0.60 |
| Gramática de panel/página | 20% | 3/10 | 0.60 |
| Acabado profesional | 15% | 5/10 | 0.75 |
| Verificación y procedencia | 10% | 1/10 | 0.10 |
| **Total ponderado** | **100%** | **4.35/10 → 4.4/10** | |

Las notas son una evaluación del lote observado, no de todo el potencial de V5.3. La predicción es que un precompositor externo determinista y QA post-generación elevarán panel/página, cámara y verificación; esa predicción debe validarse con imágenes V6.

## Lo que V3.2 y V5.3 ya resolvían en papel

V3.2 ya incluía dirección y variedad de cámara, `references.scenes` con ángulo forzado, planos maestros, continuidad de puesta en escena, respiros blanco/negro, panel enmarcado y multi-panel. Sus ejemplos también cubrían pelea legible, cambio de sujeto, plates y props.

V5.3 añadió una gramática mucho más estricta: layouts, escalas y fases de acción; fidelidad voz→imagen; estados de continuidad; performance poses; firmas de identidad; compatibilidad de referencias; límites de prompt; validador y un auditor que recalcula gates. También hizo algo correcto y honesto: separar `PROMPT_RELEASE` de `RENDER_RELEASE`.

Por tanto, el diagnóstico no es «faltan instrucciones». Es «las instrucciones no tienen suficiente autoridad mecánica ni evidencia postflight».

## Causas raíz

### Confirmadas por evidencia

1. **Brecha contrato–render.** El plan visual existe como intención, pero el renderer actual no lo compone: muestra una imagen fullscreen con crop `cover`.
2. **QA detenido antes del resultado.** El auditor V5.3 solo puede validar datos y prompts; no inspecciona imágenes ni video.
3. **Procedencia incompleta.** Sin el JSON productor no se puede comparar intención, prompt enviado, referencias, respuesta del modelo e imagen ingerida.
4. **Validación de etiquetas, no de observación.** Un campo puede decir `BIRDS_EYE` o `WHITE_COMPOSITE_2` aunque el JPG no lo materialice.

### Inferencias que V6 debe probar

1. **Sesgo de referencias hacia el ángulo conocido.** Reutilizar una referencia frontal o una escena anterior puede preservar identidad a costa de clonar cámara.
2. **Baja obediencia del generador a layouts complejos.** Pedir bordes, gutters y varios paneles dentro de una sola generación puede degradarse a una ilustración full-bleed.
3. **Repetición por falta de contraste entre tomas.** Elegir cada cámara de forma aislada no garantiza diferencias perceptibles con la toma anterior y siguiente.

Estas tres son hipótesis razonables, no atribuciones causales del lote, porque falta el JSON productor y el log de generación.

## Por qué añadir más vocabulario no basta

- El modelo puede repetir una etiqueta sin dibujar su geometría.
- `objectFit: cover` puede destruir márgenes, texto, manos o contactos aunque el JPG original estuviera bien.
- Una referencia de identidad también impone pose, perspectiva y encuadre si no se separan sus funciones.
- Los validadores preflight comprueban coherencia declarada; no observan cámara, paneles ni acabado.
- Sin hashes y job IDs no se sabe si el render corresponde al JSON auditado.
- Sin feedback por código de fallo, la regeneración vuelve a intentar todo y puede romper continuidad ya correcta.

## Requisitos de diseño V6

### 1. Layout determinista y ejecutable — P0

El JSON debe declarar geometría consumida por un precompositor externo real: `page_blueprint.template`, canvas, `slots`, `reading_order`, bordes, `gutter_px`, `background`, `fit`, `focal_point` y `safe_area`. Ese paso escribe el JPG final `images/scene_XX.jpg`; Remotion permanece sin cambios. `FULL_BLEED` sigue permitido mediante canvas completo implícito.

Los layouts blanco/negro y multi-panel no pueden depender únicamente de que el generador «dibuje una página». La geometría la controla `compose_pages_v6.py`; el generador produce el contenido de cada celda. Si se omite la precomposición, cualquier promesa de paneles deterministas permanece sin cumplir.

### 2. Intención y contraste de cámara — P0

Cada celda debe tener un `shot_ledger` verificable: escala, elevación, viewpoint, roll, banda de ocupación, sujeto focal, eje y dirección de movimiento. Además debe declarar la diferencia buscada frente a la toma anterior. No se premia variedad aleatoria: cada cambio debe servir geografía, emoción, información o impacto.

El plan bloquea la firma antes de generar. Cambiarla después requiere versión, motivo y nuevo hash; no puede editarse para hacer coincidir el resultado fallido.

### 3. Compatibilidad cámara–referencia — P0

Separar referencias de **identidad**, **pose/estado**, **escenario** y **momento**. Cada referencia declara vistas compatibles. Una base frontal no puede ser la única referencia de una toma dorsal, cenital o escorzada; se usa una hoja multivista compatible o se genera un nuevo ancla de identidad. Una scene reference solo hereda el mismo momento/eje cuando eso es intencional.

### 4. Locks de continuidad — P0

Mantener inmutables rostro, cabello, outfit, marcas, heridas, props, ocupantes, hora/luz, posiciones y estado causal. La cámara puede cambiar sin cambiar esos hechos. Cada imagen observa `state_before → action → state_after`; un fallo de continuidad invalida también los descendientes que hereden ese estado.

### 5. Postflight de tres capas — P0

1. **Píxel/geometría:** resolución, bordes, celdas, gutters, campo blanco/negro, crop y hashes.
2. **VLM:** panel count semántico, firma de cámara observada, actor/acción/target, identidad y continuidad. Nunca usar solo el porcentaje de blanco/negro para probar paneles.
3. **Humano en móvil:** legibilidad, acabado, intención de cámara, continuidad y preferencia ciega frente a V5.3.

Ninguna capa sustituye a las otras. El VLM propone evidencia; el humano resuelve discrepancias críticas.

### 6. Regeneración selectiva — P0

Cada fallo produce un código y señala el mínimo objeto reparable: celda, imagen, crop, referencia, layout o estado. Se conserva todo lo que pasó. El intento inicial cuenta como 1 y hay un máximo de 3 generaciones por `shot_id`; al tercer fallo se escala. `composition_revision` se cuenta aparte por `scene_id`: recomponer los mismos hashes no consume generación. Nunca se declara PASS a la fuerza ni se regenera el episodio completo.

### 7. Procedencia completa — P0

Por fuente: hash del packet/JSON, prompt exacto, firma esperada, referencias y hashes, modelo/configuración/seed o job ID e imagen cruda. Por página: manifiesto de composición y JPG final. La cobertura debe ser 100%. Sin JSON productor y hashes no existe `RENDER_RELEASE_V6`.

### 8. Resolución móvil y crop seguro — P0

El JPG final contractual se conserva en 720×1280. Rostros, manos causales, contactos, UI y texto requerido permanecen dentro de la celda y de zonas seguras. El precompositor debe evitar upscaling, registrar el crop efectivo y validar también una preview de 360×640 sin zoom.

## Definición de terminado

V6 no está validado cuando el schema, los GPTs o los prompts están listos. Está validado únicamente cuando:

1. el precompositor externo consume la geometría y escribe el JPG final sin modificar Remotion;
2. un piloto de 10 escenas conserva JSON, referencias y hashes;
3. los renders se miden con píxel, VLM y humano;
4. supera todos los gates de `EVALS_V6.md` dentro de tres generaciones por `shot_id`; y
5. la prueba ciega prefiere V6 frente al lote V5.3.
