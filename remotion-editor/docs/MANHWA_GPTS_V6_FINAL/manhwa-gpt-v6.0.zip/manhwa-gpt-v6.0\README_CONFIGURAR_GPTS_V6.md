# Configurar los tres GPT Manhwa V6

## Antes de empezar

V6 reemplaza la configuración V5.3 para sesiones nuevas. Crea tres GPT/chats nuevos y no mezcles documentos V3.x, V4.x o V5.x en Knowledge: las etiquetas parecen compatibles, pero los estados y responsabilidades no lo son.

Esta versión **no modifica Remotion**. Mantén el proyecto/editor como está. V6 entrega JPG finales 720×1280 con los mismos nombres; las páginas multipanel se precomponen externamente antes de entrar al editor.

## Archivos runtime

Guarda en File Library y adjunta en cada chat que valide:

- `scripts/validate_v6.py`;
- packet/JSON/manifiestos reales de esa sesión;
- para componer fuera del editor: `scripts/compose_pages_v6.py`;
- para inventario/contact sheet postflight: `scripts/make_contact_sheet_v6.py`.

Knowledge no garantiza que un `.py` exista como ejecutable. El GPT debe listar `/mnt/data`, localizarlo por contenido y usar la ruta real. Si falta el script canónico, `BLOCKED_VALIDATOR`; nunca reconstruir snippets ni fingir stdout.

## GPT 1 — Showrunner V6

Pega en Instructions:

- `gpt_1_showrunner/00_INSTRUCCIONES_SHOWRUNNER_V6.md`

Sube a Knowledge:

- `shared/01_CONTRATO_STORY_PACKET_V6.md`
- `shared/04_MOTOR_PREMISAS_COMERCIALES_V6.md`
- `gpt_1_showrunner/01_OBLIGACIONES_VISUALES_NARRATIVAS_V6.md`
- `gpt_1_showrunner/02_REFERENCIA_NARRATIVA_COMERCIAL_V6.md`
- `examples/STORY_PACKET_V6_MINIMO.md`
- `MANIFEST_V6.md`

Activa Análisis de datos. Entrada: concepto/canon o packet anterior. Salida: archivo completo `STORY_PACKET_V6` con `PACKET_READY_V6`. No crea JSON/cámara/layout.

## GPT 2 — Director Visual V6

Pega en Instructions:

- `gpt_2_director/00_INSTRUCCIONES_DIRECTOR_VISUAL_V6.md`

Sube a Knowledge:

- `shared/00_ARQUITECTURA_V6.md`
- `shared/01_CONTRATO_STORY_PACKET_V6.md`
- `shared/02_CONTRATO_VISUAL_JSON_V6.md`
- `shared/03_REFERENCIAS_Y_CONTINUIDAD_V6.md`
- `shared/05_CONTRATO_BASE_PIPELINE_V6.md`
- `gpt_2_director/01_GRAMATICA_VISUAL_EJECUTABLE_V6.md`
- `gpt_2_director/02_PROMPTS_ANGULOS_Y_REFERENCIAS_V6.md`
- `EVALS_V6.md`
- `examples/STORY_PACKET_PILOT_10_V6.md`
- `examples/PILOT_10_SCENES_V6.json`
- `templates/GENERATION_MANIFEST_V6.json`
- `MANIFEST_V6.md`

Adjunta en el chat: Story Packet completo y `validate_v6.py`; P2+ también referencias/manifiesto de assets aprobados. Salida: JSON V6 con `obligation_map`, prompts por source y `PROMPT_RELEASE_V6` real.

## GPT 3 — Auditor V6

Pega en Instructions:

- `gpt_3_auditor/00_INSTRUCCIONES_AUDITOR_DOBLE_GATE_V6.md`

Sube a Knowledge:

- `shared/00_ARQUITECTURA_V6.md`
- `shared/01_CONTRATO_STORY_PACKET_V6.md`
- `shared/02_CONTRATO_VISUAL_JSON_V6.md`
- `shared/03_REFERENCIAS_Y_CONTINUIDAD_V6.md`
- `shared/05_CONTRATO_BASE_PIPELINE_V6.md`
- `gpt_3_auditor/01_QA_POST_GENERACION_V6.md`
- `gpt_2_director/01_GRAMATICA_VISUAL_EJECUTABLE_V6.md`
- `EVALS_V6.md`
- `CALIBRACION_AUDITOR_43_IMAGENES_V6.md`
- `examples/STORY_PACKET_PILOT_10_V6.md`
- `examples/PILOT_10_SCENES_V6.json`
- `templates/GENERATION_MANIFEST_V6.json`
- `templates/RENDER_AUDIT_V6.json`
- `MANIFEST_V6.md`

Gate 1 adjunta packet + JSON + validador. Gate 2 añade todos los JPG fuente/finales, `GENERATION_MANIFEST_V6.json` y `RENDER_AUDIT_V6.json`. El Auditor no puede emitir `RENDER_RELEASE_V6` si no vio los archivos reales.

## Flujo P1

1. Showrunner crea y valida packet.
2. Director crea JSON desde cero y pasa preflight.
3. Genera fuentes full-bleed y celdas.
4. Registra prompt/model/settings/job/ruta/hash y `attempt_history` en generation manifest.
5. Ejecuta precomposición externa para escenas multipanel y conserva cada `scene_XX.composition.json`.
6. Auditor inspecciona fuentes y JPG finales, genera retakes selectivos y pasa postflight.
7. Solo `RENDER_RELEASE_V6` entra al Remotion actual.

## Prueba obligatoria antes de una Parte completa

Haz primero el piloto de diez escenas definido en `EVALS_V6.md`. V6 no se considera demostrada por tener documentos/validator; necesita imágenes reales, ≥90% de cámara observada, 100% de geometría/procedencia, cero continuidad crítica y comparación ciega favorable.

`validate_v6.py` comprueba estructura, locks, archivos, dimensiones, rutas, hashes, geometría, aritmética y completitud de las observaciones. No ejecuta visión artificial ni puede demostrar que una persona miró el JPG: el Auditor/VLM y revisores humanos deben producir esas observaciones desde los píxeles reales. Un registro inventado sigue siendo fraude de evidencia, aunque tenga JSON válido.

## Comandos locales

Instala la única dependencia de herramientas visuales (el validador usa solo stdlib):

```powershell
python -m pip install -r .\requirements-v6.txt
```

```powershell
python .\scripts\validate_v6.py --packet-only .\STORY_PACKET_V6.md
python .\scripts\validate_v6.py --preflight .\PROYECTO_V6.json
python .\scripts\compose_pages_v6.py .\PROYECTO_V6.json .\public\slug --output-dir .\public\slug\images
python .\scripts\make_contact_sheet_v6.py .\public\slug\images --output .\contact-sheet.jpg --metrics .\image-metrics.json
python .\scripts\validate_v6.py --postflight .\public\slug\PROYECTO_V6.json .\public\slug\GENERATION_MANIFEST_V6.json .\public\slug\RENDER_AUDIT_V6.json
```

Usa las rutas reales de tu máquina. Para postflight, conserva una copia byte-idéntica del JSON productor y del Story Packet enlazado en la raíz del proyecto público: las rutas `images/...` y `production_lock.story_packet_path` se resuelven desde la carpeta que contiene ese JSON. Conserva también los manifiestos `.composition.json`. El precompositor es externo al editor y no debe sobrescribir fuentes bajo `images/cells/`.
