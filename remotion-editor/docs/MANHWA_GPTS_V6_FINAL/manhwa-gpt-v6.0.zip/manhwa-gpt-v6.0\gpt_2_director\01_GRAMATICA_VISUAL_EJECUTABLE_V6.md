# Gramática visual ejecutable V6

## 1. La unidad real es la transición

Una lista de ángulos no crea dirección. Para cada corte elige:

- `MATCH`: conserva orientación, escala o eje para que el espectador compare una acción/estado.
- `CONTRAST`: cambia al menos dos dimensiones para revelar nueva información o energía.

Dimensiones: sujeto dominante, escala, elevación, viewpoint y roll. Cambiar solo luz/color no paga contraste de cámara.

## 2. Intención por cámara

| Necesidad | Familias útiles | Prueba visible |
|---|---|---|
| Orientar geografía | wide/master, high, bird's-eye | salida, amenaza y sujetos ubicables |
| Dar dominio | low/worm's-eye | horizonte bajo y volumen ascendente |
| Dar vulnerabilidad | high/top-down | sujeto reducido y suelo dominante |
| Mostrar relación | OTS/profile/two-shot | eyeline y distancia entre sujetos |
| Subjetividad | POV/rear/OTS | receptor y línea de mirada |
| Descubrir información | insert/macro/POV | objeto causal legible |
| Impacto | contact/low/Dutch motivado | punto, dirección y resultado |
| Consecuencia | wide/high/reaction | estado cambiado y costo |

El enum no basta: el horizonte, la proporción y el staging deben demostrarlo en la imagen.

## 3. Ritmo de página

- `FULL_BLEED`: escala, impacto, master, payoff.
- `STACKED_2`: causa→efecto, mirada→descubrimiento, antes→después.
- `ASYM_2`: una toma dominante + una prueba/fragmento subordinado.
- `STACKED_3`: progresión simple de tres beats, máximo dos páginas por Parte salvo justificación.
- `WHITE_ISOLATE`: decisión, soledad, reacción con baja densidad.
- `BLACK_INSET`: amenaza, presencia, muerte o silencio.

Una página compuesta no crea tiempo por sí sola: cada slot sigue siendo una fuente con instante y claim definidos.

## 4. Patrón de variedad motivada

Ejemplo de amenaza:

```text
MASTER HIGH (orientar) → POV/OTS MATCH (descubrir)
→ LOW PROFILE CONTRAST (dar dominio a amenaza)
→ CLOSE REACTION CONTRAST (costo humano)
```

Ejemplo de acción:

```text
WIDE MASTER → FULL PROFILE anticipation → GROUND_LEVEL trajectory
→ MEDIUM CONTACT → HIGH WIDE consequence → OTS reaction
```

No copies estos patrones si el beat no los necesita. Declara la función de cada corte.

## 5. Anti-gaming

FAIL:

- metadata LOW pero horizonte a nivel de ojos;
- `DUTCH` usado como único cambio en una serie de frontales;
- plate frontal adjunta a un prompt cenital;
- close llamado “panel” sin geometría;
- dos subpaneles horneados por el modelo;
- tres celdas demasiado pequeñas para leer acción;
- mismo sujeto centrado, misma distancia y misma luz con enums distintos;
- cuota de ángulos sin relación con beat;
- página blanca decorativa que no cambia densidad ni lectura.

