# Referencia narrativa comercial V6

## Claridad para audiencia fría

En los primeros segundos deben responderse o abrirse con precisión:

- ¿quién es la persona central?
- ¿qué acaba de pasar o qué va a perder?
- ¿qué pregunta obliga a seguir?

Un hook no es “acción intensa”; es una promesa específica con imagen posible.

## Cadena causal

Entre beats debe poder insertarse “por eso”. Si solo cabe “y luego”, falta causalidad.

```text
regla → riesgo → decisión → acción → resultado → costo → nueva amenaza
```

Cada revelación modifica lo que el protagonista sabe, puede hacer, debe pagar o teme perder.

## Economía del monólogo

- una idea nueva por frase;
- verbos concretos antes que adjetivos;
- explicar después de mostrar el efecto cuando sea posible;
- repetir solo si cambia significado;
- nombres propios cuando ya existe una función comprensible;
- líneas cortas en contacto/impacto; líneas algo más largas en orientación.

## Acción narrable

Una frase filmable contiene actor, verbo y objeto/target o resultado físico. Evita:

- “todo cambió” sin cambio;
- “sentí poder” sin fuente/efecto;
- “fue terrible” sin amenaza concreta;
- plural ambiguo;
- pronombre con dos antecedentes.

## Poder y costo

El primer uso de poder debe mostrar:

1. fuente;
2. acción corporal;
3. efecto en el mundo;
4. testigo o consecuencia social;
5. costo persistente.

Un aura decorativa no paga una mecánica.

## Continuidad serial

Cada Parte hereda estados aprobados, no vuelve a cero. Lleva forward:

- lesiones/marcas/poder;
- relaciones y secretos;
- props/posesiones;
- ubicación/tiempo si continúa el momento;
- preguntas abiertas y deudas;
- qué antagonistas ya observaron al protagonista.

La Parte siguiente abre pagando al menos una consecuencia del cliffhanger anterior antes de añadir otra.

