# Contrato base del pipeline V6

## Propósito

`shared/02_CONTRATO_VISUAL_JSON_V6.md` define la capa nueva. Este archivo fija el esqueleto mínimo que sigue usando el pipeline/editor actual. V6 no elimina campos de producción existentes ni requiere cambios en Remotion.

## Raíz mínima

```json
{
  "v6_contract": {},
  "production_lock": {},
  "project": {},
  "pipeline": {},
  "obligation_map": [],
  "characters": {},
  "ingredients": {},
  "escenarios": {},
  "scenes": [],
  "editing": {},
  "tts_export": {},
  "full_script": "",
  "audio": {}
}
```

Colecciones vacías pueden omitirse cuando no aplican. No omitas `project`, `pipeline`, `scenes`, `editing`, `tts_export` ni `full_script` en producción.

## project

```json
{
  "title": "Título Parte 1",
  "preset": "manhwa",
  "serie": "slug_serie_estable",
  "slug": "slug_parte_01",
  "language": "es-419",
  "aspect_ratio": "9:16",
  "fps": 30,
  "part": 1
}
```

HARD: `preset:"manhwa"`, `aspect_ratio:"9:16"`, `fps:30`, slug seguro y `part` entero ≥1.

## production_lock

Enlaza bytes reales:

```json
{
  "v6_version": "6.0",
  "story_packet_path": "STORY_PACKET_V6.md",
  "story_packet_sha256": "64_hex",
  "monologue_sha256": "64_hex",
  "approved_voice_id": "voz_real",
  "input_asset_manifest_sha256": null
}
```

`story_packet_path` es relativo al JSON productor; preflight abre ese archivo, valida su estructura, comprueba su SHA-256 y exige que `MONOLOGO_LOCKED` coincida con `full_script`. No se corrige un hash para que pase: se vuelve a usar el archivo correcto.

## pipeline

```json
{
  "image_generation": {"tool": "grok"},
  "animation": {"tool": "grok"},
  "tts": {"tool": "elevenlabs", "language": "es-419"},
  "editing": {"tool": "capcut"}
}
```

Los nombres conservan el contrato compatible V5.3. Aunque `animation.tool` permanezca declarado, todos los panels usan `render_mode:"static"` y cero `animation_prompt`; V6 no solicita animación generativa.

## characters / ingredients / escenarios

Cada recurso recurrente declara:

- ID estable y `display_name` humano;
- `prompt_signature` inglesa estable cuando sea identificable;
- `mode: generate|existing`;
- ruta relativa segura bajo `assets/`;
- tipo y estado/pose/view;
- prompt de generación o referencia real;
- SHA-256 cuando sea `existing` o esté aprobado.

Una view añade `camera_signature {elevation,viewpoint}` para poder comprobar compatibilidad con `references_v6`.

## scenes

### Panel full-bleed

```json
{
  "id": "scene_01",
  "type": "panel",
  "render_mode": "static",
  "references": {},
  "visual": {
    "source": "images/scene_01.jpg",
    "image_prompt": "...",
    "shot_ledger": {},
    "references_v6": [],
    "continuity_lock": {}
  },
  "voiceover": {"text": "Texto exacto."},
  "captions": {"text": "Texto exacto.", "highlight_words": []},
  "editor_motion": {"enabled": true, "preset": "slow_push_in", "zoom": 1.04, "pan": 2},
  "transition_in": "cut"
}
```

### Panel compuesto

Igual, pero `visual.page_blueprint` contiene los slots y cada slot su prompt/shot/referencias/continuidad. `editor_motion` queda exactamente:

```json
{"enabled": false, "preset": "static", "zoom": 1, "pan": 0}
```

### Narrative card

```json
{
  "id": "scene_03",
  "type": "narrative_card",
  "card": {"mode": "editor", "text": "FRASE BREVE"},
  "voiceover": {"text": "FRASE BREVE"},
  "captions": {"text": "FRASE BREVE"},
  "transition_in": "cut"
}
```

No lleva `render_mode`, `visual`, `references`, `shot_ledger`, `page_blueprint` ni motion.

## Voz y texto

- `full_script` es la concatenación contractual de `voiceover.text` en orden.
- `captions.text` conserva contenido de voz sin tags autorizados; no inventa otra frase.
- Cards contienen 2–7 palabras y texto de editor, no lettering generado.
- Paneles son `render_mode:"static"`; cero `animation_prompt`.

## editing

```json
{
  "caption_style": {"enabled": true, "max_words_on_screen": 4},
  "panel_motion": {
    "enabled": true,
    "apply_to": "all_panels",
    "static_zoom": 1.04,
    "static_pan": 4,
    "cycle": ["bottom_to_top", "top_to_bottom", "slow_push_in"]
  }
}
```

El override por escena manda. Páginas compuestas siempre quedan estáticas.

## tts_export y audio

Declara voz aprobada, proveedor, archivo maestro, ritmo/velocidad y cola final. Audio inexistente se omite; no se inventan rutas. La duración real se deriva de TTS, no de una estimación del Director.

## IDs, rutas y orden

- IDs únicos y ordenados; `scene_XX` con padding consistente.
- Una referencia apunta a un ID existente.
- Rutas relativas, sin drive, URI, `..` ni salida de `public/<slug>`/`assets`.
- El nombre del JPG final coincide exactamente con `scene_id`.
- Cards pueden no tener JPG; eso se registra en manifests para no contarlas como missing render.
