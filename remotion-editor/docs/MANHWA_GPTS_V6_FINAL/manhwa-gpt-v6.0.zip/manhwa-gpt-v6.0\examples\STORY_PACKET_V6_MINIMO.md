# STORY_PACKET_V6 — Ejemplo mínimo parser-ready

## META

```yaml
handoff_version: "6.0"
packet_status: PACKET_READY_V6
series_id: ejemplo_tunel
part_number: 1
approved_voice_id: VOICE_TEST_ONLY
language: es-MX
target_runtime_seconds: 5
runtime_range_seconds: [4, 7]
```

## MACHINE_LOCK_V6

```yaml
monologue_sha256: 0459391f768f2b7a72d3305f232fbfbccfdcd9cfba21d163eac97ef940c58925
character_count: 68
spoken_word_count: 13
```

```json
{
  "voice_visual_lock": [
    {
      "atom_id": "A001",
      "text_exact": "El túnel se abrió bajo mis pies.",
      "kind": "EVENT",
      "claims": [{
        "actor_id": "environment",
        "action": "opens tunnel floor",
        "receiver_or_target_id": "narrator",
        "source_id": "tunnel_floor",
        "direction": "below->narrator",
        "result": "a fissure opens beneath the narrator",
        "causal_participants": ["narrator"],
        "required_visual_tokens": ["tunnel floor splitting below both boots"],
        "resolved_from_atom_id": null
      }],
      "must_show": ["narrator"],
      "offscreen_policy": {"mode": "FORBIDDEN", "allowed_ids": [], "reason": "literal danger"}
    },
    {
      "atom_id": "A002",
      "text_exact": "Algo respiró detrás de la columna.",
      "kind": "EVENT",
      "claims": [{
        "actor_id": "unknown_creature",
        "action": "breathes behind",
        "receiver_or_target_id": "column",
        "source_id": "unknown_creature",
        "direction": "behind_column->narrator",
        "result": "breath reveals an unseen presence",
        "causal_participants": [],
        "required_visual_tokens": ["condensed breath emerging from behind the column"],
        "resolved_from_atom_id": null
      }],
      "must_show": [],
      "offscreen_policy": {"mode": "ALLOWED_FILMABLE", "allowed_ids": ["unknown_creature"], "reason": "breath makes absence observable"}
    }
  ]
}
```

## PREMISA_COMERCIAL

Un trabajador atrapado bajo una ciudad descubre que algo vive dentro de la infraestructura que repara.

## STORY_BEATS

```yaml
- beat_id: B01
  function: HOOK
  atom_ids: [A001, A002]
  question_opened: "¿qué respira detrás de la columna?"
  answer_paid: "el suelo ya no es seguro"
  causal_bridge: "la grieta revela una presencia"
  escalation_axis: "proximidad de amenaza"
```

## visual_obligations

```json
[
  {
    "obligation_id": "VO_B01_01",
    "beat_id": "B01",
    "atom_ids": ["A001"],
    "must_show": ["narrator"],
    "required_relationship": "the same tunnel floor opens directly beneath both boots",
    "information_priority": "ACT",
    "density": "MEDIUM",
    "must_be_own_source": true,
    "may_share_page": true,
    "continuity_changes": ["tunnel_floor.state: intact->open"],
    "prohibited_substitution": ["reaction without the opening floor"]
  },
  {
    "obligation_id": "VO_B01_02",
    "beat_id": "B01",
    "atom_ids": ["A002"],
    "must_show": [],
    "required_relationship": "condensed breath emerges from behind the same column toward the narrator",
    "information_priority": "DISCOVER",
    "density": "LOW",
    "must_be_own_source": true,
    "may_share_page": true,
    "continuity_changes": [],
    "prohibited_substitution": ["generic fog with no column relationship"]
  }
]
```

## CONTINUITY_LEDGER

```yaml
tunnel_floor.state:
  initial: intact
  after_A001: open
weather: dry interior
lighting_id: tunnel_amber_block_1
narrator.outfit: gray maintenance coverall
```

## MONOLOGO_LOCKED

```text
El túnel se abrió bajo mis pies.

Algo respiró detrás de la columna.
```

## QA_SHOWRUNNER

```yaml
hash_algorithm: UTF-8 + NFC + LF + no trailing LF
voice_visual_lock_coverage: 2/2
visual_obligations_without_camera: PASS
causal_chain: PASS
packet_status: PACKET_READY_V6
```
