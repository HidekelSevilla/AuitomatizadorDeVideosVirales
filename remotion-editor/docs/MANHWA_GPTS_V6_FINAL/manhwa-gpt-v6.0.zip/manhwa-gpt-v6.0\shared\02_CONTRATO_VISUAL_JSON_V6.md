# Contrato visual JSON V6

## 1. Raíz

V6 extiende el JSON de producción existente sin exigir cambios al renderer:

```json
{
  "v6_contract": {
    "version": "6.0",
    "mode": "PRODUCTION",
    "canvas": {"width": 720, "height": 1280},
    "thresholds": {
      "min_non_eye_level_pct": 20,
      "min_non_frontal_pct": 35,
      "max_identical_signature_run": 2,
      "min_composed_page_pct": 25,
      "max_composed_page_pct": 35,
      "min_distinct_composed_templates": 3,
      "max_generation_attempts": 3
    }
  },
  "project": {},
  "obligation_map": [],
  "scenes": []
}
```

`mode` es `PILOT` o `PRODUCTION`. Los umbrales de un piloto pueden ser menores, pero nunca se presentan como prueba de producción.

## 2. obligation_map — enlace narración→fuente

La raíz incluye una fila por cada `visual_obligation` del Story Packet enlazado:

```json
{
  "obligation_id": "VO_B01_01",
  "atom_ids": ["A001"],
  "must_show": ["narrator"],
  "required_relationship": "the same tunnel floor opens directly beneath both boots",
  "source_shot_ids": ["scene_01"],
  "prompt_evidence": [
    {
      "shot_id": "scene_01",
      "required_terms": ["tunnel floor splitting", "both boots"]
    }
  ]
}
```

HARD: cobertura exacta de obligaciones, `atom_ids`/`must_show`/relación copiados del packet, cada fuente asignada al menos una vez y dos o más términos concretos realmente presentes en cada prompt. Esto prueba trazabilidad declarada; postflight todavía debe demostrar el hecho en píxeles.

## 3. Tipos de escena

- `narrative_card`: card del editor, sin fuente de imagen ni `shot_ledger`.
- `panel` `FULL_BLEED`: una fuente final en `images/scene_XX.jpg`.
- `panel` compuesto: dos o tres fuentes bajo `images/cells/`; el precompositor externo produce `images/scene_XX.jpg`.

Un panel compuesto lleva `editor_motion.enabled:false`; mover o ampliar la página final puede cortar gutters y bordes.

## 4. shot_ledger

Cada fuente, no solo cada scene, declara:

```json
{
  "shot_id": "scene_12_A",
  "sequence_id": "SEQ_THREAT_01",
  "purpose": "DISCOVERY",
  "dominant_subject": "resto_perro_negro",
  "scale": "WIDE_MASTER",
  "elevation": "LOW",
  "viewpoint": "PROFILE",
  "roll": "LEVEL",
  "occupancy_pct": 38,
  "occupancy_range_pct": [32, 44],
  "human_subject_visible": false,
  "quota_eligible": true,
  "camera_intent": "make the trapped threat feel dominant",
  "change_mode": "CONTRAST",
  "change_from_shot_id": "scene_11_A",
  "change_reason": "switch from Seo's reaction to the threat's physical scale",
  "axis_id": "tunnel_hazard_axis_A",
  "screen_direction": "threat faces screen-left"
}
```

Enums canónicos:

- `purpose`: `MASTER`, `DISCOVERY`, `POV`, `RELATION`, `REACTION`, `INSERT`, `ANTICIPATION`, `TRAJECTORY`, `CONTACT`, `IMPACT`, `CONSEQUENCE`, `ISOLATION`, `PUNCTUATION`.
- `scale`: `MACRO`, `EXTREME_CLOSE`, `CLOSE`, `MEDIUM`, `FULL`, `WIDE_MASTER`, `TRUE_LONG`.
- `elevation`: `EYE_LEVEL`, `LOW`, `HIGH`, `BIRDS_EYE`, `TOP_DOWN`, `WORMS_EYE`, `KNEE_LEVEL`, `GROUND_LEVEL`.
- `viewpoint`: `FRONT`, `THREE_QUARTER_FRONT`, `PROFILE`, `OTS`, `POV`, `REAR`, `REAR_THREE_QUARTER`.
- `roll`: `LEVEL`, `DUTCH`.
- `change_mode`: `START`, `MATCH`, `CONTRAST`.

Reglas:

- `camera_intent` explica efecto narrativo, no repite el enum.
- `START` solo vale para la primera fuente de un `sequence_id`; usa `change_from_shot_id:null`.
- `MATCH`/`CONTRAST` apuntan a la fuente anterior mediante `change_from_shot_id`.
- `CONTRAST` cambia al menos dos entre escala, elevación, viewpoint, roll y sujeto dominante.
- `MATCH` conserva continuidad con razón explícita; no paga variedad.
- No hay más de dos firmas idénticas consecutivas sin excepción narrativa marcada.
- En producción, sobre fuentes `quota_eligible:true` y `human_subject_visible:true`, al menos 20% no son `EYE_LEVEL` y 35% no son frontales.
- Cada Parte demuestra al menos una toma observada de cada familia: alta/cenital; baja/ras de suelo; OTS/POV; perfil/espalda.
- Los porcentajes se verifican de nuevo sobre imágenes reales.

## 5. FULL_BLEED

```json
{
  "id": "scene_09",
  "type": "panel",
  "visual": {
    "source": "images/scene_09.jpg",
    "image_prompt": "...",
    "shot_ledger": {},
    "references_v6": [],
    "continuity_lock": {}
  }
}
```

## 6. page_blueprint

La geometría usa valores normalizados 0–1:

```json
{
  "id": "scene_12",
  "type": "panel",
  "editor_motion": {"enabled": false, "preset": "static", "zoom": 1, "pan": 0},
  "visual": {
    "image_prompt": "Resumen semántico de la página; no se envía al generador.",
    "page_blueprint": {
      "version": "6.0",
      "composition_revision": 1,
      "template": "ASYM_2",
      "background": "#ffffff",
      "reading_order": ["A", "B"],
      "gutter_px": 24,
      "safe_area": {"left": 0.04, "right": 0.04, "top": 0.04, "bottom": 0.16},
      "slots": [
        {
          "id": "A",
          "source": "images/cells/scene_12_A.jpg",
          "prompt": "...un solo instante, sin bordes ni gutters...",
          "x": 0.06, "y": 0.05, "w": 0.88, "h": 0.32,
          "fit": "cover",
          "focal_point": {"x": 0.50, "y": 0.42},
          "shape": "rect",
          "z": 1,
          "rotation_deg": 0,
          "border_px": 4,
          "border_color": "#111111",
          "radius_px": 0,
          "shot_ledger": {},
          "references_v6": [],
          "continuity_lock": {}
        },
        {
          "id": "B",
          "source": "images/cells/scene_12_B.jpg",
          "prompt": "...otro instante simple, sin bordes ni gutters...",
          "x": 0.06, "y": 0.42, "w": 0.88, "h": 0.38,
          "fit": "cover",
          "focal_point": {"x": 0.50, "y": 0.50},
          "shape": "diagonal_left",
          "z": 2,
          "rotation_deg": 0,
          "border_px": 4,
          "border_color": "#111111",
          "radius_px": 0,
          "shot_ledger": {},
          "references_v6": [],
          "continuity_lock": {}
        }
      ]
    }
  }
}
```

Templates: `FULL_BLEED`, `STACKED_2`, `ASYM_2`, `STACKED_3`, `BLACK_INSET`, `WHITE_ISOLATE`.

Cardinalidad HARD: `STACKED_2` y `ASYM_2` tienen exactamente 2 slots; `STACKED_3`, exactamente 3; `BLACK_INSET` y `WHITE_ISOLATE`, exactamente 1. El nombre del template no sustituye esta comprobación.

`composition_revision` empieza en 1 por `scene_id` y aumenta al recomponer; nunca consume `generation_attempt`.

Shapes: `rect`, `rounded`, `circle`, `diagonal_left`, `diagonal_right`.

Gates geométricos por slot en lienzo 720×1280:

- 1–3 slots, todos dentro del canvas;
- `reading_order` enumera cada slot exactamente una vez;
- `safe_area` reserva bordes y zona inferior; cada slot queda dentro de ella;
- `gutter_px` es la distancia mínima entre slots no superpuestos;
- ancho efectivo ≥260 px;
- alto efectivo ≥240 px;
- área ≥12% del lienzo;
- superposición ≤15% en templates ordinarios;
- `ASYM_2` nunca supera 35% de superposición; por encima de 15% declara `overlap_intent`;
- rutas relativas seguras, sin `..` ni rutas absolutas;
- cada fuente de celda es un archivo maestro 720×1280 distinto; no se reutiliza ruta ni hash entre `shot_id`;
- `background` y `border_color` usan `#RRGGBB` o `#RRGGBBAA`; border/radius son enteros no negativos;
- el bounding box tras `rotation_deg` permanece dentro de `safe_area`;
- cara, mano causal, target y dirección quedan dentro del crop;
- `focal_point` 0–1 y pérdida de crop aprobada en postflight;
- máximo dos páginas `STACKED_3` por Parte salvo historia que lo justifique.

El prompt de cada slot describe solo arte. No menciona página blanca, panel A/B, marco, gutter, collage ni posición de slot.

## 7. Ritmo de página

La distribución sigue función narrativa y además evita que el recurso resulte invisible:

- 25–35% de escenas `panel` usan una página no `FULL_BLEED`;
- al menos tres templates no-full-bleed durante la Parte;
- aparecen en inicio, medio y final, no agrupadas como cuota;
- `FULL_BLEED` reserva impactos, masters y escalas que necesitan área;
- `WHITE_ISOLATE`/`BLACK_INSET` sirven a silencio, emoción o amenaza;
- `STACKED_2`/`ASYM_2` sirven a causa→efecto, mirada→objeto o relación;
- `STACKED_3` solo para progresión legible de tres microinstantes simples.

Si una obligación no cabe de manera legible, se divide en escenas; nunca se encoge hasta hacerla decorativa.

## 8. Legibilidad móvil

- prueba final al 25% de escala;
- rostro causal ≥48 px de alto en la página final cuando deba leerse emoción;
- objeto/prop causal ≥32 px en su menor dimensión;
- ningún elemento obligatorio bajo captions o fuera del slot;
- líneas de acción y siluetas siguen separadas;
- texto permitido se compone en editor, no dentro de una celda pequeña, salvo UI contractual y revisada.

La legibilidad de captions/overlays del editor queda fuera del postflight de imágenes V6 porque esta versión no modifica ni renderiza Remotion. Solo se audita arte y UI horneada contractual en los JPG entregados.

## 9. Condiciones de release

Preflight válido entrega `PROMPT_RELEASE_V6`. Tras generar, precomponer y observar los archivos reales, cada fuente/página declara `asset_status: PASS|RETAKE|HUMAN_REVIEW` y `camera_result: MATCH|ACCEPTABLE_VARIANCE|MISS|NOT_OBSERVED`.

`RENDER_RELEASE_V6` exige todas las fuentes/páginas en `PASS`, cero fallos críticos o mayores sin resolver, cámara `MATCH` en al menos 90% y solo `ACCEPTABLE_VARIANCE` en el resto. `MISS`/`NOT_OBSERVED` bloquean. Los fallos menores solo se aceptan dentro del límite agregado explícito de `EVALS_V6.md`.
