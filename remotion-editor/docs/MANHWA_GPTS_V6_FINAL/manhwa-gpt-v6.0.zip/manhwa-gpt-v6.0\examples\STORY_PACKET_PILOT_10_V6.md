# STORY_PACKET_V6 — Piloto de 10 escenas

## META

```yaml
handoff_version: "6.0"
packet_status: PACKET_READY_V6
series_id: el_barrendero_de_la_ruina
part_number: 1
approved_voice_id: pilot_voice_es_419
language: es-419
target_runtime_seconds: 29
runtime_range_seconds: [26, 34]
```

## MACHINE_LOCK_V6

```yaml
monologue_sha256: a5ca3c5dab19fd9aa89c421f15116819aeeb6eab254e0c24ccf079771eee707e
character_count: 464
spoken_word_count: 79
approved_voice_tags: []
forbidden_future_state_leaks:
  - creature_full_body_before_A005
  - exit_before_A008
  - lamp_flickering_before_A009
  - survival_decision_before_A010
payoff_atom_id: A010
cliffhanger_atom_id: A010
```

```json
{
  "voice_visual_lock": [
    {
      "atom_id": "A001",
      "text_exact": "El túnel se abrió bajo mis pies.",
      "kind": "EVENT",
      "claims": [
        {
          "actor_id": "tunnel_floor",
          "action": "opens beneath",
          "receiver_or_target_id": "hero",
          "source_id": "collapsed_tunnel",
          "direction": "floor_below->hero_feet",
          "result": "the tunnel floor opens directly beneath the hero",
          "causal_participants": ["hero"],
          "required_visual_tokens": ["broken tunnel floor beneath both of the hero's feet"],
          "resolved_from_atom_id": null
        }
      ],
      "must_show": ["hero", "tunnel_floor"],
      "offscreen_policy": {
        "mode": "FORBIDDEN",
        "allowed_ids": [],
        "reason": "the physical danger is the hook"
      }
    },
    {
      "atom_id": "A002",
      "text_exact": "Algo respiró detrás de la columna.",
      "kind": "EVENT",
      "claims": [
        {
          "actor_id": "unknown_creature",
          "action": "breathes behind",
          "receiver_or_target_id": "concrete_column",
          "source_id": "unknown_creature",
          "direction": "behind_column->hero",
          "result": "breath reveals a concealed living presence",
          "causal_participants": [],
          "required_visual_tokens": ["observable breath or displaced dust emerging from behind the concrete column"],
          "resolved_from_atom_id": null
        }
      ],
      "must_show": ["concrete_column"],
      "offscreen_policy": {
        "mode": "ALLOWED_FILMABLE",
        "allowed_ids": ["unknown_creature"],
        "reason": "its breath makes the hidden creature observable without revealing its body"
      }
    },
    {
      "atom_id": "A003",
      "text_exact": "Una placa oxidada tenía mi apellido.",
      "kind": "DISCOVERY",
      "claims": [
        {
          "actor_id": "rusted_badge",
          "action": "bears identifying surname",
          "receiver_or_target_id": "hero",
          "source_id": "rusted_badge",
          "direction": "badge_identity->hero_identity",
          "result": "the hero recognizes his own surname on an old badge",
          "causal_participants": ["hero", "rusted_badge"],
          "required_visual_tokens": ["rusted worker badge connected unmistakably to the hero's identity"],
          "resolved_from_atom_id": null
        }
      ],
      "must_show": ["hero", "rusted_badge"],
      "offscreen_policy": {
        "mode": "FORBIDDEN",
        "allowed_ids": [],
        "reason": "the identity connection is story evidence"
      }
    },
    {
      "atom_id": "A004",
      "text_exact": "Desde arriba, yo parecía una pieza dentro de una trampa.",
      "kind": "STATE",
      "claims": [
        {
          "actor_id": "hero",
          "action": "appears trapped within",
          "receiver_or_target_id": "branching_tunnel_geography",
          "source_id": "hero",
          "direction": "tunnel_geometry->encloses_hero",
          "result": "the tunnel's branching structure makes the hero look contained like a game piece",
          "causal_participants": ["hero", "collapsed_tunnel"],
          "required_visual_tokens": ["small hero visibly enclosed by trap-like branching tunnel paths"],
          "resolved_from_atom_id": "A001"
        }
      ],
      "must_show": ["hero", "collapsed_tunnel"],
      "offscreen_policy": {
        "mode": "FORBIDDEN",
        "allowed_ids": [],
        "reason": "the spatial relationship carries the meaning"
      }
    },
    {
      "atom_id": "A005",
      "text_exact": "Dos ojos se encendieron antes de que apareciera el cuerpo.",
      "kind": "REVEAL",
      "claims": [
        {
          "actor_id": "tunnel_creature_eyes",
          "action": "ignite before body reveal",
          "receiver_or_target_id": "hero",
          "source_id": "tunnel_creature",
          "direction": "behind_column->hero",
          "result": "two luminous eyes become visible while the creature's body remains hidden",
          "causal_participants": ["tunnel_creature"],
          "required_visual_tokens": ["exactly two luminous eyes", "creature body still concealed"],
          "resolved_from_atom_id": "A002"
        }
      ],
      "must_show": ["tunnel_creature_eyes", "concrete_column"],
      "offscreen_policy": {
        "mode": "ALLOWED_FILMABLE",
        "allowed_ids": ["tunnel_creature_body"],
        "reason": "the body must remain concealed at this reveal stage"
      }
    },
    {
      "atom_id": "A006",
      "text_exact": "Levanté la escoba y la criatura retrocedió.",
      "kind": "ACTION_REACTION",
      "claims": [
        {
          "actor_id": "hero",
          "action": "raises broom defensively",
          "receiver_or_target_id": "tunnel_creature",
          "source_id": "broom",
          "direction": "hero->creature",
          "result": "the broom becomes an improvised defense",
          "causal_participants": ["hero", "broom", "tunnel_creature"],
          "required_visual_tokens": ["hero actively raising the same broom toward the creature"],
          "resolved_from_atom_id": null
        },
        {
          "actor_id": "tunnel_creature",
          "action": "recoils from",
          "receiver_or_target_id": "raised_broom",
          "source_id": "hero_action",
          "direction": "hero->creature->backward",
          "result": "the creature retreats because the hero raises the broom",
          "causal_participants": ["hero", "broom", "tunnel_creature"],
          "required_visual_tokens": ["creature withdrawing in direct response to the raised broom"],
          "resolved_from_atom_id": "A006"
        }
      ],
      "must_show": ["hero", "broom", "tunnel_creature"],
      "offscreen_policy": {
        "mode": "FORBIDDEN",
        "allowed_ids": [],
        "reason": "both action and caused reaction must be readable"
      }
    },
    {
      "atom_id": "A007",
      "text_exact": "Por un segundo, solo escuché mi propia respiración.",
      "kind": "BREATHE",
      "claims": [
        {
          "actor_id": "hero",
          "action": "hears only own breathing",
          "receiver_or_target_id": "hero",
          "source_id": "hero_breath",
          "direction": "hero_breath->hero",
          "result": "a brief silence follows the creature's retreat",
          "causal_participants": ["hero"],
          "required_visual_tokens": ["hero holding still with visible exertion while the surrounding threat pauses"],
          "resolved_from_atom_id": "A006"
        }
      ],
      "must_show": ["hero"],
      "offscreen_policy": {
        "mode": "FORBIDDEN",
        "allowed_ids": [],
        "reason": "the pause belongs to the hero's physical state"
      }
    },
    {
      "atom_id": "A008",
      "text_exact": "Entonces vi la salida al otro lado del abismo.",
      "kind": "DISCOVERY",
      "claims": [
        {
          "actor_id": "hero",
          "action": "discovers exit across",
          "receiver_or_target_id": "tunnel_exit",
          "source_id": "hero_eyeline",
          "direction": "hero->abyss->exit",
          "result": "the hero identifies an escape route beyond the broken span",
          "causal_participants": ["hero", "abyss", "tunnel_exit"],
          "required_visual_tokens": ["unbroken visual relationship from hero across the abyss to the distant exit"],
          "resolved_from_atom_id": "A007"
        }
      ],
      "must_show": ["hero", "abyss", "tunnel_exit"],
      "offscreen_policy": {
        "mode": "FORBIDDEN",
        "allowed_ids": [],
        "reason": "the route and obstacle must be understood together"
      }
    },
    {
      "atom_id": "A009",
      "text_exact": "La lámpara roja parpadeó como una advertencia.",
      "kind": "OMEN",
      "claims": [
        {
          "actor_id": "red_emergency_lamp",
          "action": "flickers warningly",
          "receiver_or_target_id": "hero",
          "source_id": "red_emergency_lamp",
          "direction": "lamp->hero",
          "result": "the failing red light signals that time and safety are running out",
          "causal_participants": ["red_emergency_lamp"],
          "required_visual_tokens": ["same damaged red lamp visibly changing from steady to flickering"],
          "resolved_from_atom_id": null
        }
      ],
      "must_show": ["red_emergency_lamp"],
      "offscreen_policy": {
        "mode": "FORBIDDEN",
        "allowed_ids": [],
        "reason": "the light-state change is the warning"
      }
    },
    {
      "atom_id": "A010",
      "text_exact": "No había venido a limpiar: había venido a sobrevivir.",
      "kind": "DECISION",
      "claims": [
        {
          "actor_id": "hero",
          "action": "redefines mission as survival",
          "receiver_or_target_id": "tunnel_exit",
          "source_id": "accumulated_threat",
          "direction": "hero->exit",
          "result": "the hero commits to surviving rather than continuing routine work",
          "causal_participants": ["hero", "broom", "tunnel_exit"],
          "required_visual_tokens": ["hero stops cleaning, readies the broom and commits toward the dangerous escape route"],
          "resolved_from_atom_id": "A008"
        }
      ],
      "must_show": ["hero", "broom", "tunnel_exit"],
      "offscreen_policy": {
        "mode": "FORBIDDEN",
        "allowed_ids": [],
        "reason": "the final change of intent is the payoff and cliffhanger"
      }
    }
  ]
}
```

## PREMISA_COMERCIAL

Un barrendero municipal atrapado bajo la ciudad descubre una placa con su apellido y comprende que la criatura del túnel lo estaba esperando.

## CANON_NECESARIO

```yaml
hero:
  identity_id: hero
  role: barrendero municipal y narrador
  outfit: blue_work_uniform
  held_props_initial:
    right_hand: broom
    left_hand: empty
rusted_badge:
  identity_id: rusted_badge
  initial_state: on_floor
  identifying_fact: bears_hero_surname
tunnel_creature:
  identity_id: tunnel_creature
  initial_state: hidden_behind_column
  reveal_order: breath_then_two_eyes_then_partial_body
location:
  location_id: collapsed_tunnel
  key_relations: [entry, concrete_column, broken_span, distant_exit]
lighting:
  lighting_id: amber_violet_emergency
red_emergency_lamp:
  initial_state: on
```

## STORY_BEATS

```yaml
- beat_id: B01
  function: HOOK
  atom_ids: [A001, A002]
  question_opened: "¿qué respira detrás de la columna?"
  answer_paid: "el suelo del túnel ya es una amenaza física"
  state_before: {hero.zone: tunnel_entry, creature.state: hidden}
  state_after: {hero.zone: tunnel_entry, creature.state: hidden_but_audible}
  causal_bridge: "la abertura inmoviliza al héroe el tiempo suficiente para oír la respiración"
  escalation_axis: "proximidad de amenaza"
- beat_id: B02
  function: EVIDENCE
  atom_ids: [A003, A004]
  question_opened: "¿por qué una placa antigua lleva su apellido?"
  answer_paid: "el lugar parece construido como una trampa alrededor de él"
  state_before: {badge.state: on_floor, hero.knowledge: unaware}
  state_after: {badge.state: in_left_hand, hero.knowledge: personally_targeted}
  causal_bridge: "reconocer el apellido transforma el derrumbe accidental en una amenaza personal"
  escalation_axis: "implicación personal"
- beat_id: B03
  function: MANIFESTATION
  atom_ids: [A005, A006]
  question_opened: "¿puede el héroe contener a la criatura?"
  answer_paid: "la escoba consigue hacerla retroceder, al menos por ahora"
  state_before: {creature.state: hidden, broom.state: held_for_work}
  state_after: {creature.state: recoiling, broom.state: raised_defensively}
  causal_bridge: "los ojos confirman la amenaza y obligan al héroe a defenderse"
  escalation_axis: "contacto con amenaza"
- beat_id: B04
  function: OPPORTUNITY
  atom_ids: [A007, A008]
  question_opened: "¿dónde está la única salida?"
  answer_paid: "hay una salida visible, pero está más allá del abismo"
  state_before: {hero.knowledge_of_exit: false, creature.state: recoiling}
  state_after: {hero.knowledge_of_exit: true, creature.state: recoiling}
  causal_bridge: "la pausa posterior al retroceso permite al héroe detectar la ruta de escape"
  escalation_axis: "dificultad de escape"
- beat_id: B05
  function: DECISION_CLIFFHANGER
  atom_ids: [A009, A010]
  question_opened: "¿logrará cruzar antes de que la luz y su ventaja desaparezcan?"
  answer_paid: "el héroe abandona su misión de limpieza y elige sobrevivir"
  state_before: {lamp.state: on, hero.intent: routine_work}
  state_after: {lamp.state: flickering, hero.intent: survive}
  causal_bridge: "la advertencia de la lámpara convierte la salida distante en una decisión inmediata"
  escalation_axis: "tiempo disponible"
```

## visual_obligations

```json
[
  {
    "obligation_id": "VO_B01_01",
    "beat_id": "B01",
    "atom_ids": ["A001"],
    "must_show": ["hero", "tunnel_floor"],
    "required_relationship": "the tunnel floor is physically open directly beneath both of the hero's feet",
    "information_priority": "ACT",
    "density": "MEDIUM",
    "must_be_own_source": true,
    "may_share_page": true,
    "continuity_changes": ["tunnel_floor.state: intact->open"],
    "prohibited_substitution": ["generic damaged tunnel", "hero reaction without the opening beneath him"]
  },
  {
    "obligation_id": "VO_B01_02",
    "beat_id": "B01",
    "atom_ids": ["A002"],
    "must_show": ["concrete_column"],
    "required_relationship": "breath or disturbed dust emerges from behind the same column toward the hero while the creature remains concealed",
    "information_priority": "DISCOVER",
    "density": "LOW",
    "must_be_own_source": true,
    "may_share_page": true,
    "continuity_changes": ["creature.state: hidden->hidden_but_audible"],
    "prohibited_substitution": ["unlocated fog", "visible creature body"]
  },
  {
    "obligation_id": "VO_B02_01",
    "beat_id": "B02",
    "atom_ids": ["A003"],
    "must_show": ["hero", "rusted_badge"],
    "required_relationship": "the rusted worker badge is unmistakably connected to the hero's own surname and recognized by him",
    "information_priority": "DISCOVER",
    "density": "MEDIUM",
    "must_be_own_source": true,
    "may_share_page": true,
    "continuity_changes": ["badge.state: on_floor->in_left_hand", "hero.knowledge: unaware->personally_targeted"],
    "prohibited_substitution": ["generic badge", "badge with no identity connection"]
  },
  {
    "obligation_id": "VO_B02_02",
    "beat_id": "B02",
    "atom_ids": ["A004"],
    "must_show": ["hero", "collapsed_tunnel"],
    "required_relationship": "the small hero is visibly enclosed by branching tunnel paths that read as a trap",
    "information_priority": "ORIENT",
    "density": "HIGH",
    "must_be_own_source": true,
    "may_share_page": false,
    "continuity_changes": [],
    "prohibited_substitution": ["hero isolated from the enclosing geography", "generic corridor"]
  },
  {
    "obligation_id": "VO_B03_01",
    "beat_id": "B03",
    "atom_ids": ["A005"],
    "must_show": ["tunnel_creature_eyes", "concrete_column"],
    "required_relationship": "exactly two luminous eyes appear behind the column before any readable creature body",
    "information_priority": "DISCOVER",
    "density": "LOW",
    "must_be_own_source": true,
    "may_share_page": true,
    "continuity_changes": ["creature.state: hidden_but_audible->eyes_visible"],
    "prohibited_substitution": ["full body reveal", "more or fewer than two eyes"]
  },
  {
    "obligation_id": "VO_B03_02",
    "beat_id": "B03",
    "atom_ids": ["A006"],
    "must_show": ["hero", "broom", "tunnel_creature"],
    "required_relationship": "the hero raises the same broom and the creature withdraws as the direct result of that defense",
    "information_priority": "ACT",
    "density": "HIGH",
    "must_be_own_source": true,
    "may_share_page": false,
    "continuity_changes": ["broom.state: held_for_work->raised_defensively", "creature.state: emerging->recoiling"],
    "prohibited_substitution": ["broom already raised", "unmotivated creature retreat", "reaction without the hero's action"]
  },
  {
    "obligation_id": "VO_B04_01",
    "beat_id": "B04",
    "atom_ids": ["A007"],
    "must_show": ["hero"],
    "required_relationship": "the hero holds in a brief exhausted pause while the creature remains withdrawn",
    "information_priority": "BREATHE",
    "density": "LOW",
    "must_be_own_source": true,
    "may_share_page": true,
    "continuity_changes": [],
    "prohibited_substitution": ["active combat", "relaxed hero with no exertion"]
  },
  {
    "obligation_id": "VO_B04_02",
    "beat_id": "B04",
    "atom_ids": ["A008"],
    "must_show": ["hero", "abyss", "tunnel_exit"],
    "required_relationship": "the hero discovers the lit exit beyond the same impassable broken span",
    "information_priority": "DISCOVER",
    "density": "HIGH",
    "must_be_own_source": true,
    "may_share_page": false,
    "continuity_changes": ["hero.knowledge_of_exit: false->true"],
    "prohibited_substitution": ["exit without abyss", "abyss with no visible destination"]
  },
  {
    "obligation_id": "VO_B05_01",
    "beat_id": "B05",
    "atom_ids": ["A009"],
    "must_show": ["red_emergency_lamp"],
    "required_relationship": "the same damaged red lamp changes from steady light to an unstable warning flicker",
    "information_priority": "CONSEQUENCE",
    "density": "LOW",
    "must_be_own_source": true,
    "may_share_page": true,
    "continuity_changes": ["lamp.state: on->flickering"],
    "prohibited_substitution": ["generic red glow", "lamp already off"]
  },
  {
    "obligation_id": "VO_B05_02",
    "beat_id": "B05",
    "atom_ids": ["A010"],
    "must_show": ["hero", "broom", "tunnel_exit"],
    "required_relationship": "the hero stops routine cleaning, readies the broom for survival and commits toward the dangerous exit",
    "information_priority": "DECIDE",
    "density": "MEDIUM",
    "must_be_own_source": true,
    "may_share_page": false,
    "continuity_changes": ["hero.intent: routine_work->survive"],
    "prohibited_substitution": ["hero still cleaning", "passive pose with no relation to the exit"]
  }
]
```

## CONTINUITY_LEDGER

```yaml
sequence_id: SEQ_TUNNEL_PILOT
location_id: collapsed_tunnel
lighting_id: amber_violet_emergency
hero:
  identity_id: hero
  outfit: blue_work_uniform
  zone:
    initial: tunnel_entry
    through_A010: tunnel_entry
  right_hand:
    initial: broom
    after_A006: broom_raised_defensively
  left_hand:
    initial: empty
    after_A003: rusted_badge
  intent:
    initial: routine_work
    after_A010: survive
rusted_badge:
  identity_id: rusted_badge
  initial: on_floor
  after_A003: in_hero_left_hand
  persistence: remains_in_hero_left_hand_through_A010
tunnel_creature:
  identity_id: tunnel_creature
  initial: hidden
  after_A002: hidden_but_audible
  after_A005: eyes_visible_body_concealed
  during_A006: emerging
  after_A006: recoiling
  through_A010: recoiling
red_emergency_lamp:
  identity_id: red_emergency_lamp
  initial: on
  through_A008: on
  after_A009: flickering
tunnel_exit:
  identity_id: tunnel_exit
  reveal_lock: not_visible_before_A008
  after_A008: visible_across_abyss
causal_order:
  - A001_floor_opens
  - A002_hidden_breath
  - A003_badge_recognition
  - A004_trap_understood
  - A005_eyes_reveal
  - A006_broom_causes_retreat
  - A007_silence_pause
  - A008_exit_discovered
  - A009_lamp_warning
  - A010_survival_decision
```

## MONOLOGO_LOCKED

```text
El túnel se abrió bajo mis pies.
Algo respiró detrás de la columna.
Una placa oxidada tenía mi apellido.
Desde arriba, yo parecía una pieza dentro de una trampa.
Dos ojos se encendieron antes de que apareciera el cuerpo.
Levanté la escoba y la criatura retrocedió.
Por un segundo, solo escuché mi propia respiración.
Entonces vi la salida al otro lado del abismo.
La lámpara roja parpadeó como una advertencia.
No había venido a limpiar: había venido a sobrevivir.
```

## QA_SHOWRUNNER

```yaml
hash_algorithm: UTF-8 + NFC + LF + no trailing LF
monologue_matches_pilot_full_script: PASS
atom_count: 10
voice_visual_lock_coverage: 10/10
visual_obligation_coverage: 10/10
pronouns_and_implicit_subjects_resolved: PASS
future_state_leaks: 0
visual_obligations_without_camera_or_layout_prescription: PASS
causal_chain: PASS
runtime_inside_range: PASS
packet_status: PACKET_READY_V6
```
