# Migrar de V5.3 a V6

## Qué se conserva

- canon, monólogo aprobado y voz;
- claims de `voice_visual_lock` que sean factualmente correctos;
- assets/referencias aprobados y sus archivos reales;
- estados de continuidad de la última Parte;
- audio y configuración actual de Remotion.

## Qué no se conserva como PASS

- `visual_plan`, camera enums o cuotas V5.3 sin observación;
- una page layout horneada por el generador;
- imágenes sin prompt/model/referencias/hash;
- PASS o scores declarados por el Director;
- referencias de escena que clonen composición.

## Procedimiento

1. Copia el packet/canon; no edites el original.
2. El Showrunner V6 migra encabezado, visual obligations y locks; valida packet.
3. El Director V6 reconstruye shot/page/reference/continuity ledgers desde cero. No “rellena” campos sobre el JSON viejo.
4. Elige diez momentos y ejecuta piloto.
5. Para cada fuente V5.3 que quieras reutilizar, reconstruye procedencia o márcala `UNVERIFIED`; sin hash/prompts no entra a release.
6. Genera únicamente fuentes requeridas por el piloto.
7. Precompón páginas fuera de Remotion y ejecuta postflight.
8. Solo si el piloto pasa, produce la Parte completa.

## Las imágenes actuales

No borres ni sobrescribas el lote V5.3. Úsalo como benchmark A/B y conjunto etiquetado para calibrar el Auditor. Los JPG `scene_03/04` ausentes no se recrean hasta confirmar en el JSON si eran cards.

## Compatibilidad con el editor

No se toca Remotion. El JPG final conserva:

- ruta `public/<slug>/images/scene_XX.jpg`;
- resolución 720×1280;
- escena estática;
- `editor_motion.enabled:false` para páginas compuestas.

El único paso adicional ocurre antes del editor: `compose_pages_v6.py` crea el raster final a partir de `images/cells/`.

