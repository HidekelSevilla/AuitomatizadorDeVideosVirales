from __future__ import annotations

import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "compose_pages_v6.py"
SPEC = importlib.util.spec_from_file_location("compose_pages_v6", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(MODULE)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def slot(slot_id: str, source: str, **overrides: object) -> dict[str, object]:
    result: dict[str, object] = {
        "id": slot_id,
        "source": source,
        "x": 0.25,
        "y": 0.25,
        "w": 0.5,
        "h": 0.5,
        "fit": "cover",
        "focal_point": {"x": 0.5, "y": 0.5},
        "shape": "rect",
        "z": 1,
        "rotation_deg": 0,
        "border_px": 0,
        "border_color": "#111111",
        "radius_px": 0,
    }
    result.update(overrides)
    return result


def project_for(slots: list[dict[str, object]], **blueprint_overrides: object) -> dict[str, object]:
    blueprint: dict[str, object] = {
        "version": "6.0",
        "template": "ASYM_2" if len(slots) == 2 else "WHITE_ISOLATE",
        "background": "#ffffff",
        "reading_order": [item["id"] for item in slots],
        "slots": slots,
    }
    blueprint.update(blueprint_overrides)
    return {
        "project": {"id": "golden-test"},
        "scenes": [
            {
                "id": "scene_01",
                "type": "panel",
                "editor_motion": {"enabled": False, "preset": "static", "zoom": 1, "pan": 0},
                "visual": {"page_blueprint": blueprint},
            }
        ],
    }


class ComposePagesV6Tests(unittest.TestCase):
    def _write_project(self, root: Path, payload: dict[str, object]) -> Path:
        path = root / "PROJECT.json"
        path.write_text(json.dumps(payload), encoding="utf-8")
        return path

    def test_exact_canvas_colors_z_order_manifest_and_source_immutability(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            public = root / "public" / "slug"
            cells = public / "images" / "cells"
            cells.mkdir(parents=True)
            black = cells / "black.png"
            white = cells / "white.png"
            Image.new("RGB", (720, 1280), "black").save(black)
            Image.new("RGB", (720, 1280), "white").save(white)
            source_hashes = {black: digest(black), white: digest(white)}

            black_slot = slot("black", "images/cells/black.png", z=9)
            white_slot = slot("white", "images/cells/white.png", z=1)
            project = project_for(
                [black_slot, white_slot],
                # If reading_order incorrectly controlled painting, white would win.
                reading_order=["black", "white"],
            )
            project_path = self._write_project(root, project)
            output = public / "images" / "final"

            manifests = MODULE.compose_project(project_path, public, output)
            final_path = output / "scene_01.jpg"
            manifest_path = output / "scene_01.composition.json"
            self.assertTrue(final_path.is_file())
            self.assertTrue(manifest_path.is_file())
            with Image.open(final_path) as image:
                self.assertEqual(image.size, (720, 1280))
                self.assertEqual(image.getpixel((10, 10)), (255, 255, 255))
                self.assertEqual(image.getpixel((360, 640)), (0, 0, 0))

            self.assertEqual({path: digest(path) for path in source_hashes}, source_hashes)
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            self.assertEqual(manifest["project"], "golden-test")
            self.assertEqual(manifest["project_sha256"], digest(project_path))
            self.assertEqual(manifest["blueprint_sha256"], MODULE.sha256_json(project["scenes"][0]["visual"]["page_blueprint"]))
            self.assertEqual(manifest["template"], "ASYM_2")
            self.assertEqual(manifest["reading_order"], ["black", "white"])
            self.assertEqual(manifest["draw_order"], ["white", "black"])
            self.assertEqual(manifest["composition_revision"], 1)
            self.assertEqual(manifest["source_hashes"]["black"], source_hashes[black])
            self.assertEqual(manifest["slots"][0]["source_dimensions"], {"width": 720, "height": 1280})
            self.assertLessEqual(manifest["slots"][0]["scale_factor"], 1.15)
            self.assertEqual(manifest["final_path"], "scene_01.jpg")
            self.assertEqual(manifest["final_sha256"], digest(final_path))
            self.assertEqual(manifests, [manifest])

            first_final_hash = digest(final_path)
            MODULE.compose_project(project_path, public, output)
            revised = json.loads(manifest_path.read_text(encoding="utf-8"))
            self.assertEqual(revised["composition_revision"], 2)
            self.assertEqual(digest(final_path), first_final_hash)
            self.assertEqual({path: digest(path) for path in source_hashes}, source_hashes)

    def test_circle_mask_and_cover_honor_opposite_focal_points(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            public = root / "public"
            source = public / "images" / "cells" / "split.png"
            source.parent.mkdir(parents=True)
            split = Image.new("RGB", (720, 1280), "red")
            ImageDraw.Draw(split).rectangle((0, 640, 719, 1279), fill="blue")
            split.save(source)

            left = slot(
                "left",
                "images/cells/split.png",
                x=0.05,
                y=0.30,
                w=0.40,
                h=0.225,
                shape="circle",
                focal_point={"x": 0.5, "y": 0.0},
                z=1,
            )
            right = slot(
                "right",
                "images/cells/split.png",
                x=0.55,
                y=0.30,
                w=0.40,
                h=0.225,
                shape="circle",
                focal_point={"x": 0.5, "y": 1.0},
                z=2,
            )
            project_path = self._write_project(root, project_for([left, right]))
            output = root / "out"
            MODULE.compose_project(project_path, public, output)

            with Image.open(output / "scene_01.jpg") as image:
                red_center = image.getpixel((180, 528))
                blue_center = image.getpixel((540, 528))
                masked_corner = image.getpixel((40, 388))
            self.assertGreater(red_center[0], 245)
            self.assertLess(red_center[2], 10)
            self.assertGreater(blue_center[2], 245)
            self.assertLess(blue_center[0], 10)
            self.assertEqual(masked_corner, (255, 255, 255))

    def test_rejects_absolute_parent_and_source_output_collision_without_mutation(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            public = root / "public"
            public.mkdir()
            outside = root / "outside.png"
            Image.new("RGB", (32, 32), "red").save(outside)

            unsafe_paths = ["../outside.png", str(outside.resolve())]
            for index, unsafe in enumerate(unsafe_paths):
                with self.subTest(source=unsafe):
                    project = project_for([slot("A", unsafe)])
                    project_path = self._write_project(root, project)
                    output = root / f"unsafe-output-{index}"
                    with self.assertRaises(MODULE.CompositionError):
                        MODULE.compose_project(project_path, public, output)
                    self.assertFalse(output.exists())

            images = public / "images"
            images.mkdir()
            colliding_source = images / "scene_01.jpg"
            Image.new("RGB", (720, 1280), "blue").save(colliding_source, quality=100)
            before = colliding_source.read_bytes()
            collision_project = project_for([slot("A", "images/scene_01.jpg")])
            project_path = self._write_project(root, collision_project)
            with self.assertRaises(MODULE.CompositionError):
                MODULE.compose_project(project_path, public, images)
            self.assertEqual(colliding_source.read_bytes(), before)
            self.assertFalse((images / "scene_01.composition.json").exists())

    def test_full_bleed_and_missing_blueprint_are_skipped(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            public = root / "public"
            public.mkdir()
            project = {
                "scenes": [
                    {"id": "scene_01", "type": "panel", "visual": {"source": "images/scene_01.jpg"}},
                    {
                        "id": "scene_02",
                        "type": "panel",
                        "visual": {"page_blueprint": {"template": "FULL_BLEED"}},
                    },
                    {"id": "scene_03", "type": "narrative_card"},
                ]
            }
            project_path = self._write_project(root, project)
            output = root / "out"
            self.assertEqual(MODULE.compose_project(project_path, public, output), [])
            self.assertFalse(output.exists())

    def test_rejects_wrong_template_cardinality_and_non_master_source(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            public = root / "public"
            source = public / "images" / "cells" / "small.png"
            source.parent.mkdir(parents=True)
            Image.new("RGB", (1, 1), "black").save(source)
            one_slot = slot("A", "images/cells/small.png")

            invalid_cardinality = project_for([one_slot], template="ASYM_2")
            with self.assertRaisesRegex(MODULE.CompositionError, "requires exactly 2"):
                MODULE.compose_project(self._write_project(root, invalid_cardinality), public, root / "out-cardinality")

            invalid_source = project_for([one_slot])
            with self.assertRaisesRegex(MODULE.CompositionError, "must be 720x1280"):
                MODULE.compose_project(self._write_project(root, invalid_source), public, root / "out-dimensions")

    def test_documented_cli_contract_creates_page_and_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            public = root / "public"
            source = public / "images" / "cells" / "A.png"
            source.parent.mkdir(parents=True)
            Image.new("RGB", (720, 1280), "black").save(source)
            project_path = self._write_project(root, project_for([slot("A", "images/cells/A.png")]))
            output = root / "composed"

            result = subprocess.run(
                [sys.executable, str(SCRIPT), str(project_path), str(public), "--output-dir", str(output)],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("COMPOSITION_COMPLETE pages=1", result.stdout)
            self.assertTrue((output / "scene_01.jpg").is_file())
            self.assertTrue((output / "scene_01.composition.json").is_file())


if __name__ == "__main__":
    unittest.main()
