from __future__ import annotations

import hashlib
import importlib.util
import json
import struct
import tempfile
import unittest
import zlib
from pathlib import Path
from typing import Any, Callable, Iterator


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "validate_v6.py"
PILOT = ROOT / "examples" / "PILOT_10_SCENES_V6.json"
PILOT_PACKET = ROOT / "examples" / "STORY_PACKET_PILOT_10_V6.md"
PACKET = ROOT / "examples" / "STORY_PACKET_V6_MINIMO.md"
SPEC = importlib.util.spec_from_file_location("validate_v6", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(MODULE)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_json(path: Path, payload: object) -> bytes:
    raw = (json.dumps(payload, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    return raw


def png_chunk(kind: bytes, payload: bytes) -> bytes:
    body = kind + payload
    checksum = zlib.crc32(body) & 0xFFFFFFFF
    return struct.pack(">I", len(payload)) + body + struct.pack(">I", checksum)


def color_png(seed: int, width: int = 720, height: int = 1280) -> bytes:
    """Create a complete RGB PNG whose pixels and bytes differ for each seed."""
    red = (seed * 47 + 17) % 256
    green = (seed * 83 + 31) % 256
    blue = (seed * 131 + 43) % 256
    pixel = bytes((red, green, blue))
    scanline = b"\x00" + pixel * width
    pixels = zlib.compress(scanline * height, level=9)
    header = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    return (
        b"\x89PNG\r\n\x1a\n"
        + png_chunk(b"IHDR", header)
        + png_chunk(b"IDAT", pixels)
        + png_chunk(b"IEND", b"")
    )


def source_nodes(project: dict[str, Any]) -> Iterator[dict[str, Any]]:
    for scene in project["scenes"]:
        if scene.get("type") != "panel":
            continue
        visual = scene["visual"]
        page = visual.get("page_blueprint")
        if page is None:
            yield visual
        else:
            yield from page["slots"]


def references_for(project: dict[str, Any], scene_id: str, slot_id: str | None) -> list[dict[str, Any]]:
    scene = next(item for item in project["scenes"] if item["id"] == scene_id)
    visual = scene["visual"]
    if slot_id is None:
        return visual["references_v6"]
    slot = next(item for item in visual["page_blueprint"]["slots"] if item["id"] == slot_id)
    return slot["references_v6"]


def copy_linked_packet(root: Path, project: dict[str, Any]) -> Path:
    """Copy the pilot packet byte-for-byte and bind the producer to that copy."""
    packet_bytes = PILOT_PACKET.read_bytes()
    packet_rel = project["production_lock"]["story_packet_path"]
    destination = root.joinpath(*packet_rel.replace("\\", "/").split("/"))
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(packet_bytes)
    if destination.read_bytes() != packet_bytes:
        raise AssertionError("the linked Story Packet copy changed bytes")
    project["production_lock"]["story_packet_sha256"] = sha256_bytes(packet_bytes)
    return destination


class ValidateV6Tests(unittest.TestCase):
    def load_pilot(self) -> dict[str, Any]:
        return json.loads(PILOT.read_text(encoding="utf-8"))

    def write_linked_project(self, root: Path, project: dict[str, Any]) -> tuple[Path, bytes]:
        copy_linked_packet(root, project)
        project_path = root / "PROJECT.json"
        return project_path, write_json(project_path, project)

    def assert_preflight_failure(
        self,
        mutator: Callable[[dict[str, Any]], None],
        expected_text: str,
    ) -> None:
        project = self.load_pilot()
        mutator(project)
        with tempfile.TemporaryDirectory() as directory:
            path, _ = self.write_linked_project(Path(directory), project)
            with self.assertRaises(MODULE.ValidationFailure) as raised:
                MODULE.validate_preflight(path)
        self.assertIn(expected_text, str(raised.exception))

    @staticmethod
    def scale_factor(slot: dict[str, Any]) -> float:
        left = round(slot["x"] * 720)
        top = round(slot["y"] * 1280)
        right = round((slot["x"] + slot["w"]) * 720)
        bottom = round((slot["y"] + slot["h"]) * 1280)
        width_ratio = (right - left) / 720
        height_ratio = (bottom - top) / 1280
        return max(width_ratio, height_ratio) if slot["fit"] == "cover" else min(width_ratio, height_ratio)

    def composition_manifest(
        self,
        project: dict[str, Any],
        project_hash: str,
        scene: dict[str, Any],
        scene_sources: list[dict[str, Any]],
        generated_by_shot: dict[str, dict[str, Any]],
        final_hash: str,
        revision: int,
    ) -> dict[str, Any]:
        blueprint = scene["visual"]["page_blueprint"]
        source_by_slot = {record["slot_id"]: record for record in scene_sources}
        manifest_slots: list[dict[str, Any]] = []
        source_hashes: dict[str, str] = {}
        for slot in blueprint["slots"]:
            record = source_by_slot[slot["id"]]
            source_hash = generated_by_shot[record["shot"]["shot_id"]]["output_sha256"]
            source_hashes[slot["id"]] = source_hash
            manifest_slots.append(
                {
                    "id": slot["id"],
                    "source": slot["source"],
                    "source_sha256": source_hash,
                    "source_dimensions": {"width": 720, "height": 1280},
                    "scale_factor": self.scale_factor(slot),
                    **{key: slot[key] for key in ("x", "y", "w", "h")},
                    "fit": slot["fit"],
                    "focal_point": slot["focal_point"],
                    "shape": slot["shape"],
                    "z": slot["z"],
                    "rotation_deg": slot["rotation_deg"],
                    "border_px": slot["border_px"],
                    "border_color": slot["border_color"],
                    "radius_px": slot["radius_px"],
                }
            )
        original_order = {slot["id"]: index for index, slot in enumerate(blueprint["slots"])}
        draw_order = [
            slot["id"]
            for slot in sorted(blueprint["slots"], key=lambda item: (item["z"], original_order[item["id"]]))
        ]
        return {
            "manifest_type": "MANHWA_PAGE_COMPOSITION_V6",
            "version": "6.0",
            "project": project["project"]["slug"],
            "project_sha256": project_hash,
            "blueprint_sha256": MODULE.sha256_json(blueprint),
            "scene_id": scene["id"],
            "template": blueprint["template"],
            "canvas": {"width": 720, "height": 1280},
            "background": blueprint["background"],
            "composition_revision": revision,
            "reading_order": blueprint["reading_order"],
            "draw_order": draw_order,
            "slots": manifest_slots,
            "source_hashes": source_hashes,
            "final_path": Path(scene["visual"]["source"]).name,
            "final_sha256": final_hash,
        }

    def build_postflight_fixture(
        self,
        root: Path,
    ) -> tuple[Path, Path, Path, dict[str, Any], dict[str, Any]]:
        project = self.load_pilot()
        project_path, project_raw = self.write_linked_project(root, project)
        self.assertTrue(MODULE.validate_preflight(project_path).startswith("PROMPT_RELEASE_V6"))
        validation, context = MODULE.validate_project(project)
        validation.finish("PROMPT_RELEASE_V6")

        manifest_sources: list[dict[str, Any]] = []
        generated_hashes: set[str] = set()
        for source_index, record in enumerate(context["sources"], start=1):
            image_bytes = color_png(source_index)
            image_hash = sha256_bytes(image_bytes)
            self.assertNotIn(image_hash, generated_hashes)
            generated_hashes.add(image_hash)
            output_path = root.joinpath(*record["source"].split("/"))
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_bytes(image_bytes)
            self.assertEqual(MODULE.image_size(output_path), (720, 1280))

            shot_id = record["shot"]["shot_id"]
            job_id = f"job-{shot_id}-attempt-1"
            refs = references_for(project, record["scene_id"], record["slot_id"])
            manifest_sources.append(
                {
                    "shot_id": shot_id,
                    "prompt": record["prompt"],
                    "model": "golden-stdlib-generator",
                    "settings": {"seed": 6000 + source_index, "format": "PNG", "width": 720, "height": 1280},
                    "job_id": job_id,
                    "output_path": record["source"],
                    "output_sha256": image_hash,
                    "generation_attempt": 1,
                    "status": "APPROVED",
                    "attempt_history": [
                        {
                            "attempt": 1,
                            "job_id": job_id,
                            "output_path": record["source"],
                            "output_sha256": image_hash,
                            "status": "APPROVED",
                        }
                    ],
                    "reference_hashes": [ref["sha256"] for ref in refs],
                }
            )
        self.assertEqual(len(generated_hashes), 12)

        manifest: dict[str, Any] = {
            "schema": "GENERATION_MANIFEST_V6",
            "version": "6.0",
            "generated_at": "2026-07-15T00:00:00Z",
            "project_sha256": sha256_bytes(project_raw),
            "sources": manifest_sources,
        }
        manifest_path = root / "GENERATION_MANIFEST.json"
        manifest_raw = write_json(manifest_path, manifest)
        generated_by_shot = {item["shot_id"]: item for item in manifest_sources}

        audit_sources: list[dict[str, Any]] = []
        for record in context["sources"]:
            shot = record["shot"]
            generated = generated_by_shot[shot["shot_id"]]
            audit_sources.append(
                {
                    "shot_id": shot["shot_id"],
                    "output_path": generated["output_path"],
                    "output_sha256": generated["output_sha256"],
                    "asset_status": "PASS",
                    "camera_result": "MATCH",
                    "observed": {
                        "scale": shot["scale"],
                        "elevation": shot["elevation"],
                        "viewpoint": shot["viewpoint"],
                        "roll": shot["roll"],
                        "occupancy_pct": shot["occupancy_pct"],
                        "dominant_subject": shot["dominant_subject"],
                    },
                    "observers": {
                        "vlm": {
                            "reviewer_id": "vlm-audit-v6",
                            "camera_result": "MATCH",
                            "evidence": "pixel review matches all declared camera fields",
                        },
                        "human": {
                            "reviewer_id": "human-audit-v6",
                            "camera_result": "MATCH",
                            "evidence": "independent visual inspection confirms the shot signature",
                        },
                    },
                    "identity_status": "PASS",
                    "continuity_status": "PASS",
                    "crop_status": "PASS",
                    "readability_status": "PASS",
                    "confidence": 0.99,
                    "failure_codes": [],
                }
            )

        audit_pages: list[dict[str, Any]] = []
        final_hashes: set[str] = set()
        for scene_index, scene in enumerate(context["panel_scenes"], start=1):
            scene_sources = [item for item in context["sources"] if item["scene_id"] == scene["id"]]
            shot_ids = [item["shot"]["shot_id"] for item in scene_sources]
            source_hashes = [generated_by_shot[shot_id]["output_sha256"] for shot_id in shot_ids]
            final_path = scene["visual"]["source"]
            page = scene["visual"].get("page_blueprint")
            composition_fields: dict[str, Any] = {}
            if page is None:
                final_hash = source_hashes[0]
                revision = 0
            else:
                final_bytes = color_png(100 + scene_index)
                final_hash = sha256_bytes(final_bytes)
                final_file = root.joinpath(*final_path.split("/"))
                final_file.parent.mkdir(parents=True, exist_ok=True)
                final_file.write_bytes(final_bytes)
                revision = page["composition_revision"]
                composition = self.composition_manifest(
                    project,
                    sha256_bytes(project_raw),
                    scene,
                    scene_sources,
                    generated_by_shot,
                    final_hash,
                    revision,
                )
                composition_rel = f"images/{scene['id']}.composition.json"
                composition_raw = write_json(root.joinpath(*composition_rel.split("/")), composition)
                composition_fields = {
                    "composition_manifest_path": composition_rel,
                    "composition_manifest_sha256": sha256_bytes(composition_raw),
                }
            self.assertNotIn(final_hash, final_hashes)
            final_hashes.add(final_hash)
            audit_pages.append(
                {
                    "scene_id": scene["id"],
                    "final_output_path": final_path,
                    "final_output_sha256": final_hash,
                    "composition_revision": revision,
                    "asset_status": "PASS",
                    "geometry_status": "PASS",
                    "semantics_status": "PASS",
                    "mobile_readability_status": "PASS",
                    "source_shot_ids": shot_ids,
                    "source_hashes": source_hashes,
                    "failure_codes": [],
                    **composition_fields,
                }
            )

        reviewers = [f"reviewer_{index:02d}" for index in range(1, 6)]
        pair_results: list[dict[str, Any]] = []
        for pair_index in range(1, 11):
            pair_results.append(
                {
                    "pair_id": f"pair_{pair_index:02d}",
                    "randomized_order": ["V6", "V5_3"] if pair_index % 2 else ["V5_3", "V6"],
                    "votes": [
                        {
                            "reviewer_id": reviewer,
                            "preferred_version": "V6",
                            "cause": "camera and page grammar are clearer",
                            "critical_error": False,
                        }
                        for reviewer in reviewers
                    ],
                }
            )
        audit: dict[str, Any] = {
            "schema": "RENDER_AUDIT_V6",
            "version": "6.0",
            "project_sha256": sha256_bytes(project_raw),
            "generation_manifest_sha256": sha256_bytes(manifest_raw),
            "sources": audit_sources,
            "pages": audit_pages,
            "human_ab": {
                "required": True,
                "status": "PASS",
                "reviewers": [{"reviewer_id": reviewer} for reviewer in reviewers],
                "pair_results": pair_results,
                "total_votes": 50,
                "v6_votes": 50,
                "v6_pair_wins": 10,
            },
        }
        audit_path = root / "RENDER_AUDIT.json"
        write_json(audit_path, audit)
        return project_path, manifest_path, audit_path, manifest, audit

    def test_packet_golden_passes(self) -> None:
        result = MODULE.validate_packet(PACKET)
        self.assertEqual(result, "PACKET_READY_V6 file=STORY_PACKET_V6_MINIMO.md")

    def test_empty_packet_fails(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            packet = Path(directory) / "EMPTY_PACKET.md"
            packet.write_bytes(b"")
            with self.assertRaises(MODULE.ValidationFailure) as raised:
                MODULE.validate_packet(packet)
        self.assertIn("## META", str(raised.exception))

    def test_pilot_golden_passes_preflight(self) -> None:
        result = MODULE.validate_preflight(PILOT)
        self.assertEqual(result, "PROMPT_RELEASE_V6 mode=PILOT panels=10 sources=12")

    def test_preflight_rejects_threshold_downgrade(self) -> None:
        def downgrade(project: dict[str, Any]) -> None:
            project["v6_contract"]["thresholds"]["min_camera_match_pct"] = 89

        self.assert_preflight_failure(downgrade, "no puede rebajarse por debajo de 90")

    def test_preflight_rejects_missing_obligation_map_or_absent_required_term(self) -> None:
        def remove_map(project: dict[str, Any]) -> None:
            project.pop("obligation_map")

        def invent_unpaid_term(project: dict[str, Any]) -> None:
            evidence = project["obligation_map"][0]["prompt_evidence"][0]
            evidence["required_terms"][0] = "term_that_does_not_exist_in_the_real_prompt"

        for label, mutator, expected in (
            ("missing-map", remove_map, "obligation_map: lista raíz requerida"),
            ("absent-term", invent_unpaid_term, "no aparece en prompt real"),
        ):
            with self.subTest(case=label):
                self.assert_preflight_failure(mutator, expected)

    def test_preflight_rejects_unsafe_scene_id_or_missing_composition_revision(self) -> None:
        def make_scene_id_unsafe(project: dict[str, Any]) -> None:
            project["scenes"][0]["id"] = "../scene_01"

        def remove_revision(project: dict[str, Any]) -> None:
            composed = next(scene for scene in project["scenes"] if scene["visual"].get("page_blueprint"))
            composed["visual"]["page_blueprint"].pop("composition_revision")

        for label, mutator, expected in (
            ("unsafe-scene-id", make_scene_id_unsafe, "ID seguro requerido"),
            ("missing-revision", remove_revision, "composition_revision: entero >=1 requerido"),
        ):
            with self.subTest(case=label):
                self.assert_preflight_failure(mutator, expected)

    def test_preflight_rejects_invalid_page_geometry(self) -> None:
        def break_geometry(project: dict[str, Any]) -> None:
            composed = next(scene for scene in project["scenes"] if scene["visual"].get("page_blueprint"))
            composed["visual"]["page_blueprint"]["slots"][0]["x"] = 0.95

        self.assert_preflight_failure(break_geometry, "slot fuera del canvas normalizado")

    def test_preflight_rejects_reference_camera_conflict(self) -> None:
        def add_conflicting_reference(project: dict[str, Any]) -> None:
            visual = project["scenes"][0]["visual"]
            digest = "a" * 64
            desired = visual["shot_ledger"]
            visual["references_v6"] = [
                {
                    "id": "location-wrong-camera",
                    "role": "LOCATION",
                    "composition_authority": "GEOMETRY_LOCK",
                    "source_path": "references/location-wrong-camera.png",
                    "sha256": digest,
                    "compatible_views": [desired["viewpoint"]],
                    "camera_signature": {"elevation": "EYE_LEVEL", "viewpoint": "FRONT"},
                }
            ]
            visual["continuity_lock"]["approved_reference_hashes"].append(digest)

        self.assert_preflight_failure(add_conflicting_reference, "LOCATION lock incompatible con shot_ledger")

    def test_preflight_rejects_contrast_with_only_one_signature_change(self) -> None:
        def weaken_transition(project: dict[str, Any]) -> None:
            nodes = list(source_nodes(project))
            previous = nodes[0]["shot_ledger"]
            current = nodes[1]["shot_ledger"]
            for key in ("elevation", "viewpoint", "roll", "dominant_subject"):
                current[key] = previous[key]
            current["scale"] = "CLOSE" if previous["scale"] != "CLOSE" else "MEDIUM"

        self.assert_preflight_failure(weaken_transition, "CONTRAST cambia solo 1/5 campos")

    def test_postflight_passes_distinct_pngs_manifests_observers_and_human_ab(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            paths = self.build_postflight_fixture(Path(directory))[:3]
            result = MODULE.validate_postflight(*paths)
        self.assertEqual(result, "RENDER_RELEASE_V6 mode=PILOT camera_match=100.0% pages=10")

    def test_postflight_rejects_changed_output_hash(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            project_path, manifest_path, audit_path, _, audit = self.build_postflight_fixture(root)
            audit["sources"][0]["output_sha256"] = "0" * 64
            write_json(audit_path, audit)
            with self.assertRaises(MODULE.ValidationFailure) as raised:
                MODULE.validate_postflight(project_path, manifest_path, audit_path)
        self.assertIn("render_audit.sources[scene_01].output_sha256", str(raised.exception))

    def test_postflight_rejects_duplicate_source_hash(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            project_path, manifest_path, audit_path, manifest, audit = self.build_postflight_fixture(root)
            first, duplicate = manifest["sources"][:2]
            first_path = root.joinpath(*first["output_path"].split("/"))
            duplicate_path = root.joinpath(*duplicate["output_path"].split("/"))
            duplicate_path.write_bytes(first_path.read_bytes())
            duplicate["output_sha256"] = first["output_sha256"]
            duplicate["attempt_history"][-1]["output_sha256"] = first["output_sha256"]
            duplicate_audit = next(item for item in audit["sources"] if item["shot_id"] == duplicate["shot_id"])
            duplicate_audit["output_sha256"] = first["output_sha256"]
            duplicate_page = next(item for item in audit["pages"] if item["scene_id"] == duplicate["shot_id"])
            duplicate_page["final_output_sha256"] = first["output_sha256"]
            duplicate_page["source_hashes"] = [first["output_sha256"]]
            manifest_raw = write_json(manifest_path, manifest)
            audit["generation_manifest_sha256"] = sha256_bytes(manifest_raw)
            write_json(audit_path, audit)
            with self.assertRaises(MODULE.ValidationFailure) as raised:
                MODULE.validate_postflight(project_path, manifest_path, audit_path)
        self.assertIn("no prueba una toma distinta", str(raised.exception))

    def test_postflight_rejects_camera_miss(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            project_path, manifest_path, audit_path, _, audit = self.build_postflight_fixture(root)
            audit["sources"][0]["camera_result"] = "MISS"
            audit["sources"][0]["observers"]["vlm"]["camera_result"] = "MISS"
            audit["sources"][0]["observers"]["human"]["camera_result"] = "MISS"
            write_json(audit_path, audit)
            with self.assertRaises(MODULE.ValidationFailure) as raised:
                MODULE.validate_postflight(project_path, manifest_path, audit_path)
        self.assertIn("MISS bloquea release", str(raised.exception))

    def test_postflight_rejects_altered_composition_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            project_path, manifest_path, audit_path, _, audit = self.build_postflight_fixture(root)
            composed_page = next(item for item in audit["pages"] if "composition_manifest_path" in item)
            composition_path = root.joinpath(*composed_page["composition_manifest_path"].split("/"))
            composition_path.write_bytes(composition_path.read_bytes() + b"\n")
            with self.assertRaises(MODULE.ValidationFailure) as raised:
                MODULE.validate_postflight(project_path, manifest_path, audit_path)
        self.assertIn("composition_manifest_sha256", str(raised.exception))

    def test_postflight_rejects_v6_winning_pair_with_critical_error_on_v5_3_vote(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            project_path, manifest_path, audit_path, _, audit = self.build_postflight_fixture(root)
            critical_vote = audit["human_ab"]["pair_results"][0]["votes"][0]
            critical_vote["preferred_version"] = "V5_3"
            critical_vote["critical_error"] = True
            audit["human_ab"]["v6_votes"] = 49
            write_json(audit_path, audit)
            with self.assertRaises(MODULE.ValidationFailure) as raised:
                MODULE.validate_postflight(project_path, manifest_path, audit_path)
        self.assertIn("un par ganado por V6 contiene error", str(raised.exception))


if __name__ == "__main__":
    unittest.main()
