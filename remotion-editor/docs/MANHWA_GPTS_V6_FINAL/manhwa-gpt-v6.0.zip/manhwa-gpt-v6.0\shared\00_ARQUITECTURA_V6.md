# Arquitectura Manhwa V6

## Objetivo

V6 convierte la calidad visual en una cadena verificable. Un enum correcto o una frase de cámara ya no equivalen a una imagen correcta. El sistema conserva tres GPT, pero separa cinco artefactos:

1. verdad narrativa (`STORY_PACKET_V6`);
2. enlace verificable obligación→fuente→prompt (`obligation_map`);
3. intención de toma (`shot_ledger`);
4. geometría de página (`page_blueprint`);
5. procedencia real de cada imagen (`GENERATION_MANIFEST_V6`);
6. observación posterior a generación (`RENDER_AUDIT_V6`).

## Restricción de esta edición

V6 **no modifica ni integra código en Remotion**. El editor existente sigue leyendo un JPG final por `scene_id` desde `public/<slug>/images/`.

- Una escena `FULL_BLEED` genera directamente `images/scene_XX.jpg`.
- Una escena con varias celdas genera fuentes en `images/cells/`.
- El precompositor externo `scripts/compose_pages_v6.py` crea el JPG final `scene_XX.jpg` antes de entrar al editor.
- También crea `scene_XX.composition.json`, enlazado por hashes al JSON productor, blueprint, fuentes 720×1280 y JPG final; postflight no acepta observaciones de composición vacías en su lugar.
- Remotion recibe el mismo tipo de archivo que hoy; no conoce `page_blueprint` ni necesita conocerlo.

La documentación no debe prometer paneles deterministas si se omite el paso de precomposición.

## Flujo canónico

```text
Showrunner
  STORY_PACKET_V6 + visual_obligations
        ↓
Director Visual
  JSON V6 + obligation_map + shot_ledger + page_blueprint + prompts por fuente
        ↓  validate_v6.py --preflight
  PROMPT_RELEASE_V6
        ↓
Generación estática
  JPG por fuente + GENERATION_MANIFEST_V6
        ↓
Precomposición externa de páginas
  JPG final 720×1280 por scene_id
        ↓
Auditor postflight
  observación de fuentes y páginas + RENDER_AUDIT_V6
        ↓  validate_v6.py --postflight
  RENDER_RELEASE_V6
        ↓
Remotion actual, sin cambios
```

## Autoridad

1. `MONOLOGO_LOCKED` y canon mandan sobre todo.
2. `visual_obligations` define qué hecho debe ser visible, pero no la cámara.
3. `shot_ledger` define por qué y cómo se filma cada fuente.
4. `page_blueprint` define geometría, no contenido.
5. Los JPG observados mandan sobre prompts y metadatos declarados.
6. Un PASS automático nunca sustituye inspección humana cuando identidad, acción o cámara son ambiguas.

## Estados de entrega

- `PACKET_READY_V6`: packet completo, monólogo y claims bloqueados.
- `PROMPT_RELEASE_V6`: JSON, fuentes, cámara, referencias, continuidad y geometría pasan preflight.
- `RENDER_RELEASE_V6`: archivos reales, hashes, geometría, cámara, identidad, continuidad, crop y legibilidad pasan postflight.
- `RETAKE_REQUIRED_V6`: una o más fuentes deben regenerarse; las aprobadas quedan congeladas por hash.
- `HUMAN_REVIEW_V6`: tres intentos fallaron o el Auditor no puede decidir con confianza.
- `BLOCKED_INPUT`, `BLOCKED_CANON`, `BLOCKED_MONOLOGUE`, `BLOCKED_VALIDATOR`, `BLOCKED_RENDER_INPUT`.

`PROMPT_RELEASE_V6` jamás autoriza publicación. La condición final es `RENDER_RELEASE_V6`.

## Principios no negociables

- No pedir al modelo que dibuje bordes, gutters o una página multipanel completa.
- Una fuente representa un instante simple.
- Cada ángulo tiene intención narrativa observable.
- `MATCH` conserva cámara por continuidad; `CONTRAST` cambia al menos dos dimensiones visuales.
- Referencias de identidad no gobiernan composición.
- Una plate solo gobierna geometría si su firma de cámara coincide con la toma.
- Cada fuente conserva estado, identidad, lugar y luz mediante `continuity_lock`.
- Celdas aprobadas no se regeneran al reparar otra.
- Ninguna celda puede quedar demasiado pequeña o perder cara, manos causales, target o texto permitido al recortarse.
