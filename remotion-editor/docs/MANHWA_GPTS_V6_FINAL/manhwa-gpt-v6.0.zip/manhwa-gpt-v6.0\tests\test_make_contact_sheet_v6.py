from __future__ import annotations

import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "make_contact_sheet_v6.py"
SPEC = importlib.util.spec_from_file_location("make_contact_sheet_v6", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(MODULE)


class ContactSheetTests(unittest.TestCase):
    def test_inventory_reports_dimensions_hashes_and_pixel_ratios(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            Image.new("RGB", (72, 128), "white").save(root / "scene_01.jpg", quality=100)
            Image.new("RGB", (72, 128), "black").save(root / "scene_02.png")
            files = sorted(root.glob("*"), key=MODULE.natural_key)
            data = MODULE.inventory(files, root)
            self.assertEqual(data["file_count"], 2)
            self.assertEqual(data["dimensions"], {"72x128": 2})
            self.assertEqual(len(data["files"][0]["sha256"]), 64)
            self.assertGreater(data["files"][0]["pure_white_ratio"], 0.95)
            self.assertEqual(data["files"][1]["pure_black_ratio"], 1.0)

    def test_sheet_is_created_without_changing_sources(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "scene_01.png"
            Image.new("RGB", (72, 128), "red").save(source)
            before = source.read_bytes()
            output = root / "out" / "sheet.jpg"
            MODULE.make_sheet([source], root, output, columns=1, thumb_width=90)
            self.assertTrue(output.is_file())
            self.assertEqual(source.read_bytes(), before)
            with Image.open(output) as image:
                self.assertEqual(image.width, 90)


if __name__ == "__main__":
    unittest.main()

