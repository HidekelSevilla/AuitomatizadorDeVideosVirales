#!/usr/bin/env python3
"""Build a labeled contact sheet and objective pixel inventory for V6 postflight.

This utility is external to Remotion. It never edits source images.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageFont


SUPPORTED = {".jpg", ".jpeg", ".png", ".webp"}


def natural_key(path: Path) -> list[Any]:
    return [int(part) if part.isdigit() else part.lower() for part in re.split(r"(\d+)", path.as_posix())]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def pixel_ratios(image: Image.Image) -> dict[str, float]:
    rgb = image.convert("RGB")
    total = max(1, rgb.width * rgb.height)
    pure_white = near_white = pure_black = near_black = 0
    for r, g, b in rgb.getdata():
        if r >= 245 and g >= 245 and b >= 245:
            pure_white += 1
        if r >= 235 and g >= 235 and b >= 235:
            near_white += 1
        if r <= 18 and g <= 18 and b <= 18:
            pure_black += 1
        if r <= 30 and g <= 30 and b <= 30:
            near_black += 1
    return {
        "pure_white_ratio": round(pure_white / total, 6),
        "near_white_ratio": round(near_white / total, 6),
        "pure_black_ratio": round(pure_black / total, 6),
        "near_black_ratio": round(near_black / total, 6),
    }


def inventory(files: list[Path], root: Path) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    dimensions: Counter[str] = Counter()
    modes: Counter[str] = Counter()
    for path in files:
        with Image.open(path) as image:
            dimensions[f"{image.width}x{image.height}"] += 1
            modes[image.mode] += 1
            rows.append(
                {
                    "path": path.relative_to(root).as_posix(),
                    "width": image.width,
                    "height": image.height,
                    "mode": image.mode,
                    "bytes": path.stat().st_size,
                    "sha256": sha256(path),
                    **pixel_ratios(image),
                }
            )
    return {
        "file_count": len(rows),
        "dimensions": dict(dimensions),
        "modes": dict(modes),
        "files": rows,
    }


def make_sheet(files: list[Path], root: Path, output: Path, columns: int, thumb_width: int) -> None:
    thumb_height = round(thumb_width * 16 / 9)
    label_height = max(28, round(thumb_width * 0.15))
    rows = (len(files) + columns - 1) // columns
    sheet = Image.new("RGB", (columns * thumb_width, rows * (thumb_height + label_height)), (28, 28, 28))
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.load_default()

    for index, path in enumerate(files):
        with Image.open(path) as source:
            image = source.convert("RGB")
            image.thumbnail((thumb_width, thumb_height), Image.Resampling.LANCZOS)
        column = index % columns
        row = index // columns
        x = column * thumb_width + (thumb_width - image.width) // 2
        y = row * (thumb_height + label_height) + (thumb_height - image.height) // 2
        sheet.paste(image, (x, y))
        label = path.relative_to(root).as_posix()
        if len(label) > 34:
            label = "…" + label[-33:]
        draw.text((column * thumb_width + 5, row * (thumb_height + label_height) + thumb_height + 7), label, fill="white", font=font)

    output.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output, quality=92)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("images_dir", type=Path, help="Directory containing source or final images")
    parser.add_argument("--output", type=Path, required=True, help="Output contact-sheet JPG")
    parser.add_argument("--metrics", type=Path, required=True, help="Output metrics JSON")
    parser.add_argument("--columns", type=int, default=5)
    parser.add_argument("--thumb-width", type=int, default=180)
    parser.add_argument("--recursive", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = args.images_dir.resolve()
    if not root.is_dir():
        raise SystemExit(f"images_dir is not a directory: {root}")
    iterator = root.rglob("*") if args.recursive else root.glob("*")
    files = sorted((path for path in iterator if path.is_file() and path.suffix.lower() in SUPPORTED), key=natural_key)
    if not files:
        raise SystemExit(f"no supported images found under: {root}")
    if args.columns < 1 or args.thumb_width < 64:
        raise SystemExit("columns must be >=1 and thumb-width must be >=64")

    metrics = inventory(files, root)
    args.metrics.parent.mkdir(parents=True, exist_ok=True)
    args.metrics.write_text(json.dumps(metrics, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    make_sheet(files, root, args.output, args.columns, args.thumb_width)
    print(f"CONTACT_SHEET_READY files={len(files)} output={args.output} metrics={args.metrics}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

