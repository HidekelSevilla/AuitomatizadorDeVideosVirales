# QA post-generación V6

## 1. Prueba de cámara observada

- `LOW/WORMS_EYE/GROUND_LEVEL`: horizonte bajo, verticales convergentes y volumen ascendente.
- `HIGH/BIRDS_EYE/TOP_DOWN`: suelo/geografía dominan; no basta sujeto mirando abajo.
- `OTS`: hombro/cabeza foreground + receptor y eyeline legibles.
- `POV`: receptor/objeto se organiza desde posición del observador.
- `PROFILE/REAR`: silueta y orientación inequívocas.
- `DUTCH`: roll visible; no paga elevación.

Si el Auditor solo lee el prompt, la fila queda `NOT_OBSERVED`, no PASS.

## 2. Página

- geometría coincide con blueprint dentro de tolerancia;
- fondo blanco/negro es campo real, no luz de escena;
- número y orden de slots correctos;
- borders/gutters limpios;
- ninguna cara/mano/target se corta;
- captions no tapan evidencia;
- a 25% de escala sigue leyéndose la función de cada celda.

## 3. Continuidad cruzada

Compara fuentes de misma página, `moment_id`, secuencia y vecinas:

- rostro/cabello/proporciones;
- ropa, humedad, heridas, marcas;
- prop y dueño/estado;
- arquitectura y eje;
- hora, clima, fuente y dirección de luz;
- posición antes/después.

## 4. Procedencia

Cada `shot_id` conserva:

- prompt exacto;
- modelo y ajustes;
- referencias y hashes;
- ruta y SHA-256 de salida;
- número de intento;
- `attempt_history` completo con job/ruta/hash/status de cada intento;
- estado y fallo anterior.

Archivo sin procedencia=`F_PROVENANCE_MISSING` aunque se vea correcto.

## 5. Confianza

- ≥0.85: puede PASS si toda evidencia es clara.
- 0.60–0.84: abrir JPG individual y comparar referencias.
- <0.60: revisión humana.

La confianza no compensa un error crítico.

VLM y humano clasifican de forma independiente. Sus IDs/resultados/evidencia viven en `observers`; una discrepancia necesita `adjudicator`. El script valida que el registro esté completo, pero la responsabilidad de mirar los JPG reales sigue siendo humana.

## 6. Retake manifest

```json
{
  "shot_id": "scene_12_A",
  "attempt_next": 2,
  "failure_codes": ["F_CAMERA_SIGNATURE"],
  "keep_hashes": ["sha256:..."],
  "change_only": ["camera phrase", "reference authority"],
  "do_not_change": ["identity", "state", "lighting_id", "page geometry"]
}
```

Una reparación no vuelve a generar la página completa cuando solo falla una celda.
