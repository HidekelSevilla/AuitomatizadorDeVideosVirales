# Obligaciones visuales narrativas V6

## Propósito

Esta capa evita dos errores opuestos: un Director que inventa una composición bonita pero omite el hecho, y un Showrunner que invade la dirección con listas de planos.

## Cómo escribir una obligación

Formula una prueba que una persona pueda observar sin voz:

```text
HECHO: quién hace qué a quién/qué.
RELACIÓN: contacto, dirección, distancia o límite físico.
CAMBIO: estado antes → después.
EVIDENCIA: objetos/participantes inevitables.
NO PAGA: sustituciones temáticas o reacciones insuficientes.
```

Ejemplo:

```yaml
obligation_id: VO_B07_01
beat_id: B07
atom_ids: [A029, A030]
must_show: [kang_muyeol, seo_jun]
required_relationship: la mano rota de Kang toca el pecho de Seo y la corriente nace en Kang
information_priority: ACT
density: HIGH
must_be_own_source: true
may_share_page: false
continuity_changes:
  - seo_jun.power: absent -> inherited
prohibited_substitution:
  - aura ambiental sin fuente
  - solo reacción de Seo
  - cápsula sin los dos participantes
```

## Granularidad

- Una obligación puede cubrir varios átomos solo si caben en un instante.
- Causa y consecuencia separadas deben tener obligaciones separadas.
- `must_be_own_source:true` para contacto, decisión irreversible, revelación, cambio de estado o geografía compleja.
- `may_share_page:true` permite al Director combinar fuentes en una página, no mezclar instantes en una imagen.

## Densidad

- `LOW`: un sujeto/fragmento/objeto y una idea.
- `MEDIUM`: relación de dos sujetos o sujeto+prop.
- `HIGH`: acción causal con varios participantes/entorno.

La densidad orienta tamaño de fuente. Nunca autoriza una celda pequeña para un hecho HIGH.

## Prueba fría

Antes de entregar cada obligación, pregunta: “Si quito narración y efectos, ¿se distingue actor, acción, target, dirección y cambio?” Si no, la obligación está incompleta.
