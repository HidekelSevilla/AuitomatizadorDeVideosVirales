# LLM Council — Manhwa GPT V6

Fecha: 2026-07-15 02:12:30, America/Mexico_City.

> **Aviso de autoridad:** este transcript conserva literalmente propuestas deliberativas que mencionan integrar un compositor en Remotion. El usuario rechazó esa integración después del Council. Esas menciones son históricas y quedan **SUPERSEDED**; la restricción vigente se documenta al final y en `shared/00_ARQUITECTURA_V6.md`. No deben implementarse.

## Pregunta enmarcada

¿Cómo debe diseñarse una V6 del preset de tres GPT para que el episodio generado se lea visiblemente como un webtoon coreano vertical profesional —con composiciones de página/panel inequívocas y ángulos de cámara realmente variados y motivados por la narración— sin perder continuidad, el flujo JSON→Remotion, la generación estática 720×1280 ni la arquitectura Showrunner→Director Visual→Auditor?

Evidencia disponible: tres artefactos V3.2, el paquete completo V5.3, 43 JPG producidos y una contact sheet. Hechos medidos: los 43 JPG son RGB 720×1280; faltan `scene_03` y `scene_04`, probablemente porque son cards del editor (inferencia); V5.3 ya declara cámara y cuotas visuales; no se localizó el JSON que produjo las imágenes. Opciones consideradas: endurecer V5.3; rehacer V6 contract-first con ledgers ejecutables; componer paneles en Remotion; añadir QA posterior a generación y regeneración selectiva; o un híbrido. Está en juego la repetibilidad profesional frente a prompt bloat, desobediencia del modelo, deriva de continuidad y complejidad operativa.

## Respuestas independientes

### Contrarian

The fatal flaw is that V5.3 audits intentions, not pixels. Its validator can prove that JSON contains `WHITE_COMPOSITE_2`, nonfrontal viewpoints, and camera phrases while the image model still returns another eye-level three-quarter tableau. The contact sheet exposes this gap: a few white collage treatments exist, but most of the 43 rasters are single full-bleed tunnel images; the composites resemble pasted cards rather than deliberate Korean scroll rhythm. Because the production JSON and generation provenance are missing, nobody can determine whether failure occurred in directing, generation, or asset ingestion. That alone invalidates any confident diagnosis of V5.3.

Do not merely tighten prompts. V6 should be hybrid:

- Separate the shot contract from the page-layout contract. Generate one narrative instant per 720×1280 source image, with a declared crop-safe focal zone. Remotion must deterministically create gutters, borders, white fields, masks, crops, and one/two/three-panel compositions. Never delegate panel count, border geometry, or reading order to the image model.
- Replace decorative angle quotas with a beat-linked shot ledger: narrative change → camera purpose → scale/elevation/viewpoint/axis → prohibited repetition. Quotas remain secondary safeguards.
- Make the Auditor inspect generated JPGs, not merely JSON: verify actual panel geometry, whitespace ratio, subject scale, viewpoint, continuity, identity, and focal readability. Store JSON hash, exact prompt, model/settings, output hash, and path.
- Selectively regenerate failures with a bounded retry count, then fail closed to human review.
- Prove the system on a 10-scene pilot before producing another 43-image episode.

Deterministic Remotion layouts solve page grammar; they do not solve camera compliance. Without post-generation image QA, V6 is only V5.3 with more schema.

### First Principles

Build V6 as an output-verification system, not another prompt expansion. “Professional webtoon” is visible geometry, rhythm, and shot progression; metadata is only an intention. V5.3 already validates declared layouts, camera signatures, quotas, and prompt wording, but its 4,230-line validator never inspects the resulting pixels. The contact sheet proves that most outputs remain single full-bleed illustrations and only a small minority visibly resemble composed pages. Without the generation JSON, it cannot prove whether the Director failed or the image model ignored instructions.

Preserve the three GPTs, but redefine their deliverables:

- Showrunner emits causal beats plus explicit `visual_obligations`, not camera choices.
- Visual Director must produce a machine-readable shot/page ledger before prompts: `composition_template`, `cells[]`, narrative-purpose enum, shot scale, elevation, viewpoint, subject occupancy, horizon, screen direction, axis, and continuity state. Reject repeated signatures within a rolling window and any angle lacking a beat-linked purpose.
- Remotion deterministically creates gutters, borders, white space, black insets, diagonals, and multi-panel layouts. Generate each cell as a separate static 720×1280 image, then crop/mask it into the final 720×1280 composition. Never delegate panel borders or page geometry to the image model.
- Auditor runs two gates: contract QA before generation and pixel QA afterward. Vision checks actual JPGs against the ledger for composition, camera, placement, continuity, and identity, then emits a `repair_manifest` for selective cell regeneration.

Ship V6 only after a fixed golden episode achieves 100% layout compliance, at least 90% camera-signature compliance, zero critical continuity errors, and a blinded human comparison that unmistakably prefers V6.

### Expansionist

V6 debe ser un híbrido contract-first: dejar de pedirle al generador que “dibuje una página” y convertir a Remotion en el compositor determinista del webtoon. La evidencia es clara: V5.3 ya declara `page_layout`, escala, elevación, viewpoint y cuotas; su validador comprueba JSON y palabras del prompt, mientras el contrato dice que Remotion ignora `visual_plan`. La contact sheet muestra que la diversidad declarada no se tradujo proporcionalmente en diversidad visible. Sin el JSON productor no puede atribuirse la falla al Director o al generador.

El Director V6 debería entregar dos ledgers:

- `shot_ledger`: función narrativa del plano, sujeto dominante, eje, escala, elevación, viewpoint, ocupación esperada y continuidad.
- `page_ledger`: uno a tres paneles con geometría exacta `x/y/w/h`, gutter, borde, máscara, focal point y orden de lectura.

Cada subpanel se genera como arte estático limpio; Remotion lo recorta y compone en un frame final 720×1280. Así los gutters, paneles apilados, insertos, diagonales y silencios blancos son inevitables, no aspiracionales.

La variedad debe medirse como transición narrativa: entre planos consecutivos cambian al menos dos dimensiones visuales, salvo match cut justificado. Cada ángulo necesita `camera_intent`: contrapicado=dominio, picado=vulnerabilidad, OTS=relación, cenital=geografía, macro=información.

El Auditor debe continuar después de generar: inspección píxel/VLM del JPG renderizado contra el ledger—paneles detectables, ocupación, escala, ángulo, identidad y continuidad—con regeneración selectiva del subpanel fallido, congelando los aprobados. Esa compuerta cierra el vacío fundamental de V5.3: validar intenciones sin validar resultados.

### Outsider

A cold viewer sees a polished illustrated slideshow, not a professional vertical webtoon. The contact sheet shows that most frames remain full-bleed, eye-level illustrations; only a handful—such as scenes 07, 31, and 34—visibly use gutters or multiple panels. V5.3’s core failure is categorical: it audits descriptions, not pictures. Its Auditor explicitly stops at preproduction and “does not request or claim to see renders”; its dependency-free validator checks JSON fields and prompt wording. The older V3 artifacts already demanded low, high, OTS, floor-level, and bird’s-eye shots, so adding more camera vocabulary is not a meaningful V6. Because the producing JSON is missing, whether the Director planned poorly or the image model ignored it remains unknown.

V6 should be hybrid and output-enforced:

- Keep Showrunner unchanged.
- Make the Visual Director emit a shot ledger with a narrative reason for every angle, plus a separate Remotion page-layout ledger.
- Generate clean static 720×1280 artwork as panel sources. Remotion must create borders, gutters, white/black fields, overlaps, and asymmetric two-panel pages from deterministic templates. Multi-panel moments should use separate source images per slot, never ask the image model to draw the page architecture.
- Make the existing Auditor run twice: prompt preflight, then post-generation visual QA. Measure actual border count, whitespace, subject occupancy, and layout geometry; use visual inspection to classify the rendered scale, elevation, viewpoint, identity, and action.
- Regenerate only failed sources. Release only when observed—not declared—camera signatures meet the ledger and adjacent frames visibly contrast unless repetition has an explicit narrative purpose.

That is the first V6 where metadata becomes audience-visible evidence.

### Executor

Build V6 as a hybrid, not another prompt expansion. Evidence: V5.3’s Auditor is explicitly preproduction-only and forbidden from judging renders; Remotion ignores `visual_plan/page_layout/subpanels` and displays one JPG full-screen with `objectFit:"cover"`. Therefore declared camera/layout compliance can diverge completely from pixels. The missing production JSON prevents proving whether these images violated their prompts, but the architecture cannot detect that failure anyway.

Make the Visual Director emit two machine-readable ledgers:

- `page_blueprint`: deterministic template, slot geometry, gutters, crop/focal anchors, and asset ID per slot.
- `shot_ledger`: `sequence_id`, narrative role (`MASTER`, `POV`, `REACTION`, `INSERT`, `IMPACT`, `CONSEQUENCE`), camera signature, subject occupancy/depth, screen direction, and a mandatory `change_reason`.

Generate every source still at 720×1280. Full-bleed pages use one asset; multi-panel pages use two or three independently generated assets, then Remotion crops them into contractual masks. Never ask the image model to draw borders, whitespace, or an entire comic page. This makes panel grammar unmistakable while preserving JSON→Remotion and continuity references.

Keep the three GPTs, but make Auditor Stage 3 two-pass: preflight validates ledger/continuity; post-generation vision QA compares actual pixels against shot role, elevation, viewpoint, focal placement, identity, and slot-safe crop, then outputs only failed asset IDs for selective regeneration. Release requires rendered-pixel PASS, not prompt PASS.

First action: implement one 10-scene V6 pilot containing three full-bleeds, three two-panel pages, one three-panel escalation, and three punctuation pages. Add the minimal Remotion compositor and postflight manifest, then compare its contact sheet blindly against V5.3 before rewriting the full preset.

## Anonimización

- A = Outsider
- B = First Principles
- C = Contrarian
- D = Expansionist
- E = Executor

## Revisiones anónimas

### Revisor 1

1. **Strongest: B.** It best converts the diagnosis into an enforceable system: separate composition assets, motivated shot metadata, continuity fields, pixel-level audit, repair manifests, measurable release gates, and blinded human comparison. It covers both deterministic panel grammar and camera compliance without pretending metadata proves pixels.

2. **Largest blind spot: E.** Its pilot usefully specifies layout counts, but camera variety remains only a `shot_ledger` with `change_reason`; it lacks measurable shot signatures, axis/eyeline rules, repetition constraints, and continuity checks. A page can pass its pixel gate while still feeling mechanically or arbitrarily shot.

3. **What all missed:** none provides a concrete continuity mechanism for separately generated and selectively regenerated cells. V6 needs locked character/location reference packs, wardrobe/prop/state IDs, palette and lighting anchors, reference-conditioned generation, and cross-cell identity checks. Otherwise deterministic Remotion layouts may improve page grammar while multiplying face, costume, spatial, and lighting drift.

### Revisor 2

1. **Strongest: C.** It best separates intent, rendered evidence, and provenance. It also recognizes that deterministic Remotion layouts solve page geometry but not camera compliance, then proposes bounded retries and human escalation.

2. **Largest blind spot: D.** Requiring two camera dimensions to change between shots converts “motivated variety” into quota-driven churn. It could damage continuity and pacing, and it lacks a pilot, calibrated thresholds, or human validation.

3. **All missed:** Separately generated cells create a new continuity failure mode: drifting faces, wardrobe, lighting, spatial state, and action poses. V6 needs a carried continuity packet—approved references, character/location anchors, scene state, and inter-panel transition checks—and a human-labeled benchmark to calibrate the pixel/VLM Auditor so visual QA does not become another unverified metadata layer.

### Revisor 3

1. **Strongest: B.** It turns the diagnosis into an executable contract: beat obligations, explicit composition/camera fields, deterministic Remotion geometry, pixel-level auditing, selective repair, measurable release gates, and blinded human comparison. It also correctly avoids assigning blame without the missing production JSON.

2. **Largest blind spot: E.** Its fixed pilot mix—three full-bleeds, three two-panels, etc.—risks replacing camera quotas with layout quotas. Professional grammar should follow beat purpose and transition logic, not a prescribed distribution. It also lacks concrete camera-signature, axis, continuity, and provenance checks.

3. **What all missed:** Resolution-aware panel economics. At 720×1280, deterministic multi-panel composition can produce tiny faces, unreadable lettering, destructive crops, or inconsistent detail density. V6 needs minimum effective panel dimensions, cell-specific generation aspect ratios, focal/balloon-safe zones, crop-loss limits, and mobile-scale readability tests. Pixel QA should also be calibrated against human-labeled examples from the 43 JPGs so the VLM auditor’s compliance scores are trustworthy.

## Where the Council Agrees

- V5.3 controla intenciones en JSON/prompts, pero no observa el resultado. Su propio Auditor termina en preproducción y `PROMPT_RELEASE`.
- Añadir más vocabulario de cámara no soluciona el problema: V3.2 y V5.3 ya nombraban OTS, perfil, contrapicado, cenital y otras variantes.
- La geometría de página debe dejar de depender del generador. Remotion o un precompositor determinista debe crear bordes, gutters, campos blancos/negros, máscaras y orden de lectura.
- Director necesita separar `shot_ledger` de `page_blueprint`; cada ángulo requiere función narrativa.
- Auditor necesita dos pasadas: preflight contractual y postflight sobre imágenes reales, con regeneración selectiva y hashes de procedencia.
- El JSON productor ausente impide culpar con certeza al Director, al generador o a la ingestión.

## Where the Council Clashes

- El Executor propone una mezcla fija de layouts para el piloto. Dos revisores advierten que una receta fija puede reemplazar un quota gaming por otro. La síntesis conserva un piloto de diez escenas, pero los layouts se eligen por función narrativa y no por cumplir una distribución rígida.
- El Expansionist pide cambiar dos dimensiones entre planos consecutivos. El revisor 2 señala correctamente que eso puede producir cámara nerviosa sin motivo. V6 lo convierte en regla condicional: `CONTRAST` cambia al menos dos dimensiones; `MATCH` puede conservarlas con razón explícita y continuidad comprobada.
- Algunos asesores dejarían al Showrunner intacto; First Principles añade `visual_obligations`. La síntesis adopta solo obligaciones narrativas observables y prohíbe que el Showrunner escoja cámara o layout.

## Blind Spots the Council Caught

- Separar subpaneles aumenta el riesgo de deriva de rostro, vestuario, props, luz y geografía. V6 necesita `continuity_lock`, referencias aprobadas por hash y comprobación cruzada entre celdas.
- A 720×1280, una página de tres celdas puede volver ilegibles caras o acciones. V6 necesita tamaño efectivo mínimo, `focal_point`, límite de pérdida por crop y prueba a escala móvil.
- Un VLM también puede “aprobar” metadatos sin estar calibrado. El postflight debe conservar evidencia, confianza y escalamiento humano; el benchmark debe incluir ejemplos etiquetados de estas 43 imágenes.
- La compatibilidad cámara↔referencia es crítica: una plate o scene ref con encuadre incompatible puede dominar el prompt y clonar la composición. V6 tipa la autoridad de cada referencia y bloquea `FULL_LOCK` durante un corte `CONTRAST`.

## Auditoría numérica del resultado V5.3

Dimensiones y pesos: claridad narrativa 7/10 (20%), identidad/continuidad 6/10 (15%), variedad de cámara 3/10 (20%), gramática de página/panel 3/10 (20%), acabado profesional 5/10 (15%), verificación/procedencia 1/10 (10%). Resultado ponderado: 4.35/10, redondeado a **4.4/10**.

Evidencia: 43 JPG 720×1280; cinco superan 10% de blanco puro (`07`, `31`, `34`, `38`, `40`) y uno supera 20% de negro puro (`12`), de modo que solo 6/43 (14.0%) exhiben un campo de página blanco/negro fuerte con esos umbrales. La contact sheet muestra continuidad básica de personajes/lugar y acción comprensible, pero predominio visual de full-bleed a nivel de ojos/frontal o tres cuartos. No se afirma un conteo exacto de ángulos a partir de esa observación.

Predicción, todavía no evidencia: un compositor determinista debe elevar la gramática de página; el QA postflight debe elevar la obediencia de cámara. Ninguna mejora se considera demostrada hasta renderizar y comparar el piloto.

## The Recommendation

Construir V6 como sistema híbrido de salida verificable. Conservar los tres roles, pero cambiar la condición de éxito: el Showrunner entrega obligaciones visuales narrativas; el Director entrega fuentes separadas, `shot_ledger`, `page_blueprint`, política de referencias y `continuity_lock`; un precompositor externo crea el JPG final sin modificar Remotion; el Auditor valida antes y después de generar. Solo existe `RENDER_RELEASE_V6` cuando cada fuente y página tiene procedencia completa, layout observado correcto, cámara observada compatible, continuidad aprobada y legibilidad móvil.

No se acepta una V6 que solo agregue reglas al prompt. Tampoco se acepta composición determinista sin inspección de cámara, ni inspección automática sin escalamiento humano.

## The One Thing to Do First

Producir un proof slice de diez escenas con los beats y layouts elegidos por función narrativa, ejecutar preflight, generar las celdas, componerlas, auditar los píxeles y compararlo a ciegas contra una muestra V5.3. Solo después de alcanzar 100% de geometría, al menos 90% de coincidencia de firma de cámara y cero fallos críticos de continuidad se debe producir otra Parte completa.

## Restricción posterior del usuario

Después de la deliberación, el usuario prohibió integrar cambios en Remotion. La implementación V6 respeta esa autoridad: no modifica `src/`, tipos ni renderer. La recomendación de composición determinista se adapta a un **precompositor externo al editor** que escribe los mismos JPG finales 720×1280 que el Remotion actual ya consume. El transcript conserva las propuestas originales del Council como registro, pero no autoriza una integración rechazada por el usuario.
