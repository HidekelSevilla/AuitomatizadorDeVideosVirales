# Changelog Manhwa V6.0

## Cambio de arquitectura

- Se conserva Showrunner→Director→Auditor.
- Se separa intención de toma, geometría, procedencia y observación.
- El Auditor deja de terminar necesariamente en preproducción: ahora tiene preflight y postflight.
- `PROMPT_RELEASE_V6` y `RENDER_RELEASE_V6` son estados distintos.
- No hay integración ni cambios en Remotion.

## Cámara

- Nuevo `obligation_map` enlaza cada obligación/átomo con `shot_id` y términos existentes del prompt; no hay fuentes narrativamente huérfanas.
- Nuevo `shot_ledger` por fuente/celda.
- `camera_intent` obligatorio.
- Transición explícita `START`/`MATCH`/`CONTRAST`.
- `CONTRAST` cambia al menos dos dimensiones; `MATCH` exige razón.
- Familias de ángulo y porcentajes se verifican también sobre imágenes reales.
- Repetir enums sin geometría observable ya no pasa.

## Página/panel

- Nuevo `page_blueprint` con geometría 0–1.
- Fuentes separadas por celda; el modelo ya no dibuja la página.
- Precompositor externo genera el JPG final 720×1280.
- Tamaño efectivo, crop, focal point y legibilidad móvil son HARD.
- 25–35% de panels usan página no-full-bleed por función narrativa.

## Referencias y continuidad

- `references_v6` tipa role y `composition_authority`.
- Plate con cámara incompatible falla.
- `FULL_LOCK` prohibido en cortes `CONTRAST`.
- `continuity_lock` conserva momento, estado, identidades, lugar, luz y hashes.
- Fuentes aprobadas se congelan; reparaciones son selectivas.

## Procedencia y QA

- `GENERATION_MANIFEST_V6` registra prompt, modelo, ajustes, referencias, output, hash e intento.
- Cada intento conserva job/ruta/hash/status en `attempt_history`; rutas o hashes duplicados entre tomas bloquean.
- Cada página compuesta encadena proyecto→blueprint→fuentes→JPG mediante `scene_XX.composition.json` y SHA-256.
- `RENDER_AUDIT_V6` registra expected→observed, VLM/humano independientes, confianza y códigos de fallo.
- Máximo tres intentos; después revisión humana.
- Release requiere 100% geometría/procedencia, ≥90% cámara observada, cero continuidad crítica y legibilidad móvil.

## Corrección de la causa raíz V5.3

V5.3 podía comprobar que un prompt decía `LOW` o `WHITE_COMPOSITE_2`, pero no que el JPG lo mostrara. V6 no considera esa intención como evidencia final.
