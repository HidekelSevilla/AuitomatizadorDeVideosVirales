# Manifest Manhwa GPT V6.0

Fecha de build: 2026-07-15  
Estado del paquete: `DOCUMENTATION_READY_V6` + tooling verificado  
Estado visual: **no es `RENDER_RELEASE_V6`** hasta producir y evaluar imágenes reales del piloto.

## Restricción de alcance

Este paquete no modifica ni integra Remotion. No contiene cambios bajo `src/`, `package.json` ni configuración del renderer. `compose_pages_v6.py` es una herramienta externa: lee fuentes y escribe JPG/manifiestos antes de que el editor reciba `images/scene_XX.jpg`.

## Componentes

- tres configuraciones GPT: Showrunner, Director Visual y Auditor;
- contratos compartidos de packet, pipeline, cámara, página, referencias y continuidad;
- auditoría V5.3, calibración reproducible y transcript completo de llm-council;
- piloto parser-ready de 10 escenas, 12 fuentes y 4 páginas compuestas;
- templates de generación y auditoría;
- validador packet/preflight/postflight;
- precompositor determinista externo y generador de contact sheet;
- pruebas positivas y negativas.

## Verificación ejecutada

```text
PACKET_READY_V6 file=STORY_PACKET_PILOT_10_V6.md
PROMPT_RELEASE_V6 mode=PILOT panels=10 sources=12
Ran 23 tests ... OK
JSON_OK
```

Las 23 pruebas cubren: packet vacío/válido; enlace packet→obligación→shot→prompt; locks/hash; cuotas no degradables; geometría/cardinalidad; transiciones; referencias; continuidad; rutas/colisiones; composición y cinco máscaras; fuentes 720×1280; hashes distintos; historial de intentos; manifiesto proyecto→blueprint→fuente→JPG; observadores VLM/humano; A/B 5×10; y fallos deliberados de cámara, procedencia y error crítico.

## Límite de Instructions

| GPT | Caracteres | Límite operativo | Resultado |
|---|---:|---:|---|
| Showrunner | 3,674 | 8,000 | PASS |
| Director Visual | 4,722 | 8,000 | PASS |
| Auditor | 3,925 | 8,000 | PASS |

## Hashes críticos SHA-256

| Archivo | Bytes | SHA-256 |
|---|---:|---|
| `gpt_1_showrunner/00_INSTRUCCIONES_SHOWRUNNER_V6.md` | 3,756 | `ecaffcf28d4d8eb841f85b15fdba66db9e1abeb83e992f1e3248076bf6ff75e1` |
| `gpt_2_director/00_INSTRUCCIONES_DIRECTOR_VISUAL_V6.md` | 4,843 | `4b451e4e286340efc7c36721e539b7bcd74d5e34c300f5c2ce4500f85e828326` |
| `gpt_3_auditor/00_INSTRUCCIONES_AUDITOR_DOBLE_GATE_V6.md` | 3,986 | `fd160c6c6faca72b5fb68aa100044c69a0d6f9d1e0827057c15fbd798b9c35ad` |
| `scripts/validate_v6.py` | 90,832 | `eac5f18a1014c4e51a49e178eb14f338ad3c95427d7c82cc4b923d9d9618b5e7` |
| `scripts/compose_pages_v6.py` | 27,840 | `a95cee0c2031dfa7a76b941206b059736c8669fe0790cb8d17b60d2738d1bafe` |
| `scripts/make_contact_sheet_v6.py` | 5,326 | `991d6c280dda11c143056dde31ae4916a4de8f08ccded7f5869640ff7abb9edb` |
| `examples/STORY_PACKET_PILOT_10_V6.md` | 21,138 | `f7508029f427a11d637e56ab03e8abf600bc5fea62e14f36ebf4d230fb5ee17a` |
| `examples/PILOT_10_SCENES_V6.json` | 45,983 | `d7e0f78e38512e22366710993129e21ab03ae2e99792338ec86d82bd0ab0f6cc` |
| `evidence/V5_3_CONTACT_SHEET_43.jpg` | 956,430 | `e5a65a4f107202a817a512c34e9f584b74ba9c81cb4027764cae690a8cd07cc0` |
| `evidence/V5_3_IMAGE_METRICS_43.json` | 15,884 | `d4d6bf21059fa29ca5ea129f9b9f83b463bfbe5ba2baefe5c8a25de2e0c09257` |
| `evidence/V5_3_CALIBRATION_LABELS_43.json` | 2,384 | `c47b14c277d3d156a04b9148e5cdd0af1d5c4de14d517204cfb077ea4074299b` |
| `council-transcript-20260715-021230.md` | 19,612 | `2940175f79063314cc4e5c447baf9b4f96578590738cc4de7c874f0680644494` |

`MANIFEST_V6.md` no enumera su propio hash para evitar una referencia recursiva. El ZIP se verifica por separado después de empaquetar.
