# Prompts de uso V6

## 1. Crear Story Packet

Adjunta `validate_v6.py` y concepto/canon:

```text
MODO AUTO — SHOWRUNNER V6.

Trabaja solo como Showrunner. Construye un STORY_PACKET_V6 completo con handoff_version 6.0, MACHINE_LOCK_V6, voice_visual_lock por átomo, STORY_BEATS causales, visual_obligations sin cámara/layout, CONTINUITY_LEDGER y MONOLOGO_LOCKED. Conserva cada átomo hablado en 2–16 palabras, uno por línea; si usas líneas vacías, quedan bloqueadas por hash. Guarda el archivo y ejecuta validate_v6.py --packet-only usando las rutas reales encontradas en /mnt/data. Corrige hasta exit 0 y PACKET_READY_V6. No hagas JSON, prompts ni planos.

[CONCEPTO/CANON]
```

## 2. Crear JSON y prompts

En el Director adjunta packet + `validate_v6.py`:

```text
MODO AUTO — DIRECTOR VISUAL V6.

Usa este STORY_PACKET_V6 como única autoridad. No cambies MONOLOGO_LOCKED. Crea desde cero el JSON V6, `obligation_map` exacto packet→shot→términos del prompt, shot_ledger, page_blueprint, references_v6, continuity_lock y un prompt inglés por fuente. Cada ángulo necesita camera_intent; usa START al abrir secuencia y después MATCH o CONTRAST. No pidas al generador dibujar páginas: los slots generan arte limpio en images/cells y compose_pages_v6.py crea el JPG final fuera de Remotion. Ejecuta validate_v6.py --preflight sobre el archivo real y corrige hasta PROMPT_RELEASE_V6. Entrega JSON + tabla `shot_id → visual.source/slot.source → prompt` + evidencia del comando.
```

## 3. Auditor preflight

Adjunta packet + JSON + validador:

```text
MODO AUTO_REPAIR_PREFLIGHT — AUDITOR V6.

Recalcula desde voz/canon, no confíes en PASS del Director. Audita obligación→fuente, cámara motivada, MATCH/CONTRAST, repetición, geometría/tamaño/crop, compatibilidad cámara-referencia y continuidad. Repara solo lo necesario, ejecuta validate_v6.py --preflight y entrega JSON completo únicamente con exit 0 y PROMPT_RELEASE_V6. No afirmes haber visto imágenes.
```

## 4. Precomponer fuera de Remotion

Después de generar todas las celdas:

```powershell
python .\scripts\compose_pages_v6.py .\PROYECTO_V6.json .\public\mi_slug --output-dir .\public\mi_slug\images
```

Este paso no integra nada en Remotion. Solo escribe los JPG finales que el editor ya espera.

Genera también evidencia objetiva:

```powershell
python .\scripts\make_contact_sheet_v6.py .\public\mi_slug\images --output .\contact-sheet-v6.jpg --metrics .\image-metrics-v6.json
```

## 5. Auditor postflight

Adjunta JSON, todos los JPG fuente y finales, generation manifest, plantilla/audit y validador:

```text
MODO AUTO_REPAIR_POSTFLIGHT — AUDITOR V6.

Inspecciona los píxeles reales. Para cada shot_id compara shot_ledger con escala, elevación, viewpoint, sujeto, acción, target, identidad, estado, luz y crop observados. Registra VLM y humano independientes en observers; adjudica discrepancias. Para cada página compara blueprint con geometría/orden/legibilidad y conserva el hash de scene_XX.composition.json. Completa RENDER_AUDIT_V6.json y registra failure_codes/severity/confidence. Congela PASS por hash y crea retakes solo para RETAKE, máximo tres generation_attempt por shot con attempt_history completo. Ejecuta validate_v6.py --postflight con rutas reales. RENDER_RELEASE_V6 exige todos los assets/pages PASS, cero fallos críticos o mayores sin resolver y todos los gates agregados en PASS; si no puedes observar una imagen, BLOCKED_RENDER_INPUT.
```

## 6. Reparar una celda

```text
RETAKE SELECTIVO V6.

Repara únicamente shot_id [ID], intento [N]. Fallos: [CÓDIGOS]. Conserva exactamente los hashes aprobados, continuity_lock, identidad, estado, lighting_id y page_blueprint. Cambia solo [prompt de cámara / referencia incompatible / encuadre]. Devuelve prompt, refs y ruta de salida actualizados; no regeneres otras celdas ni cambies el monólogo.
```

## 7. Proof slice

```text
PILOTO V6 DE DIEZ ESCENAS.

Selecciona diez momentos del mismo relato antes de generar, cubriendo orientación, relación, amenaza, acción, consecuencia y respiración. Elige layouts por función narrativa, no por llenar una mezcla fija. Incluye las cuatro familias de ángulo y al menos un estado que persista. Ejecuta todo el flujo hasta postflight y prepara A/B ciego contra V5.3 según EVALS_V6.md. No declares éxito sin imágenes y votos reales.
```
