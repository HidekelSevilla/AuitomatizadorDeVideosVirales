# Contrato Story Packet V6

## 1. Encabezado

```yaml
STORY_PACKET_V6:
  handoff_version: "6.0"
  packet_status: PACKET_READY_V6
  series_id: slug_estable
  part_number: 1
  approved_voice_id: voz_real
  language: es-MX
  target_runtime_seconds: 95
  runtime_range_seconds: [90, 100]
```

El Showrunner no crea JSON de producción, prompts, cámara, layouts ni rutas de imagen.

## 2. MACHINE_LOCK_V6

Debe contener:

- `monologue_sha256` calculado sobre `MONOLOGO_LOCKED` exacto;
- `character_count`, palabras habladas y runtime esperado;
- una entrada `voice_visual_lock` por átomo;
- tags de voz autorizados;
- eventos/estados que no pueden adelantarse;
- reveal locks, costo, payoff y cliffhanger;
- identidad y dirección causal resueltas.

Cada entrada de `voice_visual_lock`:

```json
{
  "atom_id": "A017",
  "text_exact": "La columna empezó a caer.",
  "kind": "EVENT",
  "claims": [{
    "actor_id": "environment",
    "action": "drops damaged column",
    "receiver_or_target_id": "rescue_zone",
    "source_id": "damaged_column",
    "direction": "above->rescue_zone",
    "result": "the column visibly descends",
    "causal_participants": [],
    "required_visual_tokens": ["damaged column visibly falling", "concrete dust"],
    "resolved_from_atom_id": null
  }],
  "must_show": [],
  "offscreen_policy": {"mode": "FORBIDDEN", "allowed_ids": [], "reason": "literal event"}
}
```

### Hash canónico del monólogo

1. toma solo el payload de `MONOLOGO_LOCKED` (el contenido del bloque fenced, sin las marcas ```);
2. normaliza Unicode a NFC;
3. convierte CRLF/CR a LF;
4. elimina un LF final; el payload canónico no termina en newline;
5. codifica UTF-8 y calcula SHA-256 hexadecimal lowercase.

No apliques `.strip()`: espacios iniciales/finales dentro de líneas son bytes narrativos y deben corregirse antes de bloquear, no desaparecer durante el hash.

## 3. MONOLOGO_LOCKED

- Palabras, signos, tags y orden son inmutables después de `PACKET_READY_V6`.
- Cada átomo ocupa su propia línea; las líneas vacías son opcionales, pero si existen quedan incluidas en el hash canónico.
- Cada átomo hablado tiene 2–16 palabras y cabe en una ventana visual.
- Un cambio de actor, acción causal, target, tiempo o resultado normalmente crea otro átomo.
- Cards y controles se etiquetan para no forzarlos dentro de un panel ilustrado.

## 4. STORY_BEATS

Cada beat declara:

```yaml
- beat_id: B04
  function: DECISION
  atom_ids: [A017, A018, A019]
  question_opened: "¿cruzará la barrera?"
  answer_paid: "la grieta amenaza a las personas"
  state_before: {}
  state_after: {}
  causal_bridge: "el peligro físico obliga la decisión"
  escalation_axis: "riesgo personal"
```

Los beats mínimos de una Parte comercial son `HOOK`, `DETONATOR`, `THREAT`, `DECISION`, `MANIFESTATION`, `PAYOFF`, `COST` y `CLIFFHANGER`, salvo justificación de género explícita.

## 5. visual_obligations

Es el único añadido visual del Showrunner. Expresa información, no cámara.

```json
{
  "obligation_id": "VO_B04_02",
  "beat_id": "B04",
  "atom_ids": ["A019"],
  "must_show": ["seo_jun", "cinta_roja"],
  "required_relationship": "one boot crosses the same stretched warning tape",
  "information_priority": "DECIDE",
  "density": "LOW",
  "must_be_own_source": true,
  "may_share_page": true,
  "continuity_changes": ["seo_jun.zone: outside->inside"],
  "prohibited_substitution": ["reaction only", "tape without crossing contact"]
}
```

Campos HARD:

- `obligation_id`, `beat_id`, `atom_ids`;
- `must_show` y relación física requerida;
- `information_priority`: `ORIENT`, `DISCOVER`, `DECIDE`, `ACT`, `IMPACT`, `REACT`, `CONSEQUENCE`, `BREATHE`;
- `density`: `LOW`, `MEDIUM`, `HIGH`;
- cambio de continuidad;
- sustituciones prohibidas;
- si exige fuente propia y si puede compartir página.

Prohibido aquí: `close-up`, `low angle`, `WHITE_*`, `STACKED_2`, lente, posición de panel, color decorativo o prompt en inglés. Esas son decisiones del Director.

## 6. CONTINUITY_LEDGER

Por entidad recurrente:

- firma visual estable;
- vestuario y variante;
- heridas, poder, marcas y dueño;
- props y estado material;
- ubicación, interior/exterior y contactos;
- luz/hora/clima por tramo;
- causas autorizadas de cada cambio;
- referencias aprobadas de Partes previas.

El siguiente estado inicial debe ser igual al último estado aprobado de la Parte anterior.

## 7. QA_SHOWRUNNER

Antes de entregar:

- monólogo exacto y hash correcto;
- todos los átomos cubiertos por `voice_visual_lock`;
- pronombres y sujetos tácitos resueltos;
- cada beat enlazado por causalidad;
- ninguna revelación/poder/herida adelantada;
- obligaciones visuales completas pero sin cámara/layout;
- runtime dentro del rango;
- `packet_status: PACKET_READY_V6` solo con cero fallos.
