# Referencias y continuidad V6

## 1. Por qué cambia el contrato

Una referencia visual puede conservar identidad y al mismo tiempo destruir el ángulo pedido. V6 declara para qué se adjunta cada imagen y cuánto puede gobernar la salida.

## 2. references_v6

Máximo tres referencias por fuente:

```json
{
  "id": "seo_jun_base",
  "role": "IDENTITY",
  "composition_authority": "IDENTITY_ONLY",
  "source_path": "assets/characters/serie/seo_jun_base.jpg",
  "sha256": "64_hex_reales",
  "camera_signature": null,
  "compatible_views": ["FRONT", "THREE_QUARTER_FRONT", "PROFILE"]
}
```

`role`:

- `IDENTITY`: rostro, cabello, proporciones, vestuario;
- `POSE`: postura/acción compatibles;
- `LOCATION`: arquitectura y geografía;
- `STATE`: herida, prop, criatura o transformación;
- `MOMENT`: posiciones de un instante ya aprobado.

`composition_authority`:

- `IDENTITY_ONLY`: ignora pose, crop, cámara, luz y fondo de la referencia;
- `POSE_ONLY`: conserva pose/anatomía, no crop ni cámara;
- `GEOMETRY_LOCK`: conserva arquitectura/eje con firma de cámara compatible;
- `FULL_LOCK`: conserva instante y posiciones; solo para `MATCH`.

## 3. Compatibilidad de cámara

- `LOCATION + GEOMETRY_LOCK/FULL_LOCK` declara `camera_signature` con elevación y viewpoint.
- Toda referencia declara `source_path` relativo y SHA-256 real; ID sin archivo/hash no prueba procedencia.
- `compatible_views` limita qué vistas puede soportar una referencia de identidad/pose sin improvisación severa.
- Si difiere de `shot_ledger`, el preflight falla.
- En un corte `CONTRAST`, `FULL_LOCK` está prohibido.
- Para un ángulo nuevo se usa una plate compatible o se omite la plate y se ancla el lugar con materiales, elementos fijos, hora y luz.
- Una scene ref de otro momento no conserva identidad por sí sola.
- Nunca adjuntar una plate solo para llenar el límite de referencias.

Frase operativa para `IDENTITY_ONLY`:

```text
Use the provided reference only for the same face, hair, body proportions and outfit.
Create a new pose, crop, camera elevation, viewpoint, composition and background exactly as specified below.
```

No garantiza obediencia: el postflight debe comprobar la cámara real.

## 4. continuity_lock

Cada fuente declara:

```json
{
  "moment_id": "M_B04_CROSSING",
  "state_in": {
    "seo_jun.zone": "outside",
    "cinta_roja.state": "stretched",
    "weather": "rain"
  },
  "state_out": {
    "seo_jun.zone": "inside",
    "cinta_roja.state": "stretched",
    "weather": "rain"
  },
  "identity_ids": ["seo_jun"],
  "location_id": "tunnel_hazard_zone",
  "lighting_id": "rain_amber_violet_block_1",
  "approved_reference_hashes": ["sha256:..."]
}
```

HARD:

- `state_out` alimenta el siguiente `state_in`;
- todo cambio cita acción/claim causal;
- mismo `moment_id` conserva posiciones, dirección, vestuario, lesión, prop, clima y luz;
- otro momento puede cambiar pose, pero no canon persistente;
- referencias aprobadas se congelan por SHA-256;
- una regeneración no sustituye hashes de fuentes aprobadas;
- celdas de la misma página se comparan entre sí, no solo contra assets base.

## 5. Orden de generación

1. Genera y aprueba bases de identidad/estado/localización.
2. Genera primero la celda ancla del momento más informativa.
3. Registra su hash y estado observado.
4. Genera celdas dependientes con referencias tipadas, no con `FULL_LOCK` si cambia cámara.
5. Audita identidad, vestuario, prop, luz y geografía entre celdas.
6. Congela PASS; repara solo FAIL.

## 6. Códigos de fallo

- `F_REFERENCE_CAMERA_CONFLICT`
- `F_REFERENCE_DOMINATED_COMPOSITION`
- `F_IDENTITY_DRIFT`
- `F_WARDROBE_DRIFT`
- `F_PROP_STATE_DRIFT`
- `F_LOCATION_DRIFT`
- `F_LIGHTING_DRIFT`
- `F_MOMENT_POSITION_DRIFT`
- `F_FUTURE_STATE_LEAK`
- `F_APPROVED_HASH_CHANGED`

`generation_attempt` se cuenta por `shot_id`, máximo tres. `composition_revision` se cuenta aparte por `scene_id`; recomponer los mismos hashes no consume un intento de generación. Tres generaciones fallidas de la misma fuente llevan a `HUMAN_REVIEW_V6`; nunca se suaviza el gate para declarar PASS.
