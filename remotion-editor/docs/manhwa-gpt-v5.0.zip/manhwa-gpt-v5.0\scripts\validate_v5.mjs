import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { validateQueueProject } from "../../../../lib/queue-validator.js";

const input = process.argv[2];
if (!input) {
  console.error("Uso: node validate_v5.mjs <proyecto.json>");
  process.exit(2);
}

const absolute = path.resolve(input);
const raw = JSON.parse(fs.readFileSync(absolute, "utf8"));
const contract = validateQueueProject(raw);
const scenes = Array.isArray(raw.scenes) ? raw.scenes : [];
const panels = scenes.filter((s) => s?.type === "panel");
const cards = scenes.filter((s) => s?.type === "narrative_card");

const shotRe = /\b(extreme close-up|close-up|macro|medium(?:-wide|-full)?|full-body|full body|wide(?: establishing)?|extreme-wide|device shot)\b/i;
const angleRe = /\b(eye-level|low(?:-oblique)?(?: angle)?|high(?:-oblique)?(?: angle)?|bird'?s-eye|top-down|over-the-shoulder|OTS|from behind|rear(?: view)?|profile|side(?: angle| view|-profile)?|POV|dutch tilt|worm'?s-eye|knee-level|ground-level)\b/i;
const timeRe = /\b(dawn|sunrise|morning|noon|afternoon|sunset|dusk|evening|night|midnight|pre-dawn|daytime|nighttime)\b/i;
const closeRe = /\b(extreme close-up|close-up|macro)\b/i;
const breathRe = /\b(pure white|white page|manga page layout|white background|solid pure black|sepia-toned|device shot|interface occupies|onomatopoeia|negative space)\b/i;
const compositeRe = /\b(exactly two separate rectangular panels|two separate rectangular panels)\b/i;

const prompts = panels.map((s) => String(s?.visual?.image_prompt || ""));
const missing = {
  shot: panels.filter((s) => !shotRe.test(String(s?.visual?.image_prompt || ""))).map((s) => s.id),
  angle: panels.filter((s) => !angleRe.test(String(s?.visual?.image_prompt || ""))).map((s) => s.id),
  time: panels.filter((s) => !timeRe.test(String(s?.visual?.image_prompt || ""))).map((s) => s.id),
};

const normalized = prompts.map((p) => p.trim().toLowerCase().replace(/\s+/g, " "));
const duplicates = normalized.flatMap((p, i) => p && normalized.indexOf(p) !== i ? [panels[i]?.id] : []);

let closeRun = 0;
let maxCloseRun = 0;
for (const prompt of prompts) {
  closeRun = closeRe.test(prompt) ? closeRun + 1 : 0;
  maxCloseRun = Math.max(maxCloseRun, closeRun);
}

const breaths = panels.filter((s) => breathRe.test(String(s?.visual?.image_prompt || "")));
const composites = panels.filter((s) => compositeRe.test(String(s?.visual?.image_prompt || "")));
const voiceTexts = scenes.map((s) => String(s?.voiceover?.text || "")).filter(Boolean);
const joined = voiceTexts.join("\n");
const fullScript = String(raw?.tts_export?.full_script || "");
const promptWordCounts = prompts.map((p) => p.trim() ? p.trim().split(/\s+/).length : 0);

const report = {
  file: absolute,
  status: contract.ok && joined === fullScript && duplicates.length === 0 ? "CONTRACT_PASS" : "FAIL",
  contract: { ok: contract.ok, errors: contract.errors, warnings: contract.warnings },
  counts: {
    scenes: scenes.length,
    panels: panels.length,
    cards: cards.length,
    full_script_characters: fullScript.length,
    max_references: Math.max(0, ...scenes.map((s) =>
      (s?.references?.characters?.length || 0)
      + (s?.references?.assets?.length || 0)
      + (s?.references?.escenario ? 1 : 0)
      + (s?.references?.scenes?.length || 0))),
  },
  integrity: { full_script_exact: joined === fullScript },
  prompts: {
    missing,
    duplicates,
    max_close_macro_run: maxCloseRun,
    word_count_min: promptWordCounts.length ? Math.min(...promptWordCounts) : 0,
    word_count_max: promptWordCounts.length ? Math.max(...promptWordCounts) : 0,
    word_count_average: promptWordCounts.length ? Number((promptWordCounts.reduce((a, b) => a + b, 0) / promptWordCounts.length).toFixed(1)) : 0,
  },
  rhythm: {
    detected_breath_panels: breaths.map((s) => s.id),
    narrative_cards: cards.map((s) => s.id),
    detected_breath_ratio: panels.length ? Number(((breaths.length + cards.length) / scenes.length).toFixed(3)) : 0,
    white_composites: composites.map((s) => s.id),
  },
  render_dependent: "NOT_RUN",
};

console.log(JSON.stringify(report, null, 2));
process.exit(report.status === "FAIL" ? 1 : 0);
